------
README
------


Distribution
------------
Floppy Image is distributed as freeware.


Brief Description
-----------------
Creates image files of floppy disks and back (for backup, storage or transfer). You can choose to save the image file compressed, uncompressed or as a self-extracting exe file. You can also add descriptions to your image files.


Longer Description
------------------
Go to the homepage that can be found in the About Box under the Help menu.


Installation
------------
Just doubleclick the EXE file.


Version History
---------------
Can be found in the Check For Updates dialog that can be accessed under the Help menu.


System Requirements
-------------------
Windows 98/Me/NT4/2000/XP


Contact Information
-------------------
Can be found in the About Box that can be accessed under the Help menu.
