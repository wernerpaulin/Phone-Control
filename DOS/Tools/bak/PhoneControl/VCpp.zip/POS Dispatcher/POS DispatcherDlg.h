// POS DispatcherDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPOSDispatcherDlg dialog

class CPOSDispatcherDlg : public CDialog
{
// Construction
public:
	CPOSDispatcherDlg(CWnd* pParent = NULL);	// standard constructor

	CPOSDispatcherApp *ThisApp;								//Objekt der Applikationsklasse

  UINT upDateTimerID;	// Timer-ID
	BYTE userUpdate;						//Update von der Dialogbox zur Klasse
	int setResponse;					  //Antwort von Settings-Dialogbox
	BYTE oldPortNr;							//alter Wert der Port-Nummer
  unsigned char oldPOI0Adr;   //alter Wert der POI-Adresse
  unsigned char oldOwnAdr;    //alter Wert der POS-Adresse

	CEdit valPINCtrl;						//Control-Objekt fuer PIN-Editbox
	int sndPUNIdx;							//Index der PUN-Combobox
	CString strHook;						//String fuer Phoneline-Condition
  CString strPOSReset;				//String fuer POS-Reset - Auftrag
  CString strSCO;						  //String fuer Safety Cut Off
  CString strSRU;						  //String fuer Speech Reco Unit
  CString strDevice1;					//String fuer Device Nr. 1
  CString strDevice2;					//String fuer Device Nr. 2
  CString strDevice3;					//String fuer Device Nr. 3
  CString strDevice4;					//String fuer Device Nr. 4

	CComboBox *pSndPUNCtrl;								//Pointer auf PUN-ComboBox


// Dialog Data
	//{{AFX_DATA(CPOSDispatcherDlg)
	enum { IDD = IDD_POSDISPATCHER_DIALOG };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPOSDispatcherDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CPOSDispatcherDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnDestroy();
	afx_msg void OnClearStatistics();
	afx_msg void OnUpdatePIN();
	afx_msg void OnSettings();
	afx_msg void OnPUNDropdown();
	afx_msg void OnManstat();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};
