// POS DispatcherDlg.cpp : implementation file
//

#include "stdafx.h"
#include "POS Dispatcher.h"
#include "POS DispatcherDlg.h"
#include "Settings.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
  //}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()




/////////////////////////////////////////////////////////////////////////////
// CPOSDispatcherDlg dialog

CPOSDispatcherDlg::CPOSDispatcherDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CPOSDispatcherDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CPOSDispatcherDlg)
  
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

/*

*/

void CPOSDispatcherDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPOSDispatcherDlg)
	//}}AFX_DATA_MAP
	DDX_Text( pDX, IDC_EDIT1,  ::WP2ClientInfo.cntNoConn );
	DDX_Text( pDX, IDC_EDIT2,  ::WP2ClientInfo.cntDstNRdy );
	DDX_Text( pDX, IDC_EDIT3,  ::WP2ClientInfo.cntRetFail );
	DDX_Text( pDX, IDC_EDIT4,  ::WP2ClientInfo.cntInvSign );
	DDX_Text( pDX, IDC_EDIT5,  ::WP2ClientInfo.cntUnXRec );
	DDX_Text( pDX, IDC_EDIT6,  ::WP2ClientInfo.cntUnXSign );
	DDX_Text( pDX, IDC_EDIT7,  ::WP2ClientInfo.cntCCancel );
	DDX_Text( pDX, IDC_EDIT8,  ::WP2ClientInfo.cntRetReq );
  DDX_Text( pDX, IDC_EDIT9,  ::WP2ClientInfo.cntUnIdRec );
  DDX_Control( pDX, IDC_EDIT10, valPINCtrl);

	DDX_Text( pDX, IDC_HOOK    , strHook     );
	DDX_Text( pDX, IDC_POSRESET, strPOSReset );
	DDX_Text( pDX, IDC_SCO     , strSCO      );
	DDX_Text( pDX, IDC_SRU     , strSRU      );
	DDX_Text( pDX, IDC_DEVICE1 , strDevice1  );
	DDX_Text( pDX, IDC_DEVICE2 , strDevice2  );
	DDX_Text( pDX, IDC_DEVICE3 , strDevice3  );
	DDX_Text( pDX, IDC_DEVICE4 , strDevice4  );
	
  //nach Aenderung durch User:
  //Transfer von der Dialogbox zur Klasse einleiten
	if (userUpdate == 1)	
		{
	   pDX->m_bSaveAndValidate = TRUE;

     DDX_Text( pDX, IDC_EDIT10, ::WP2ClientInfo.valPIN );

		 DDX_CBIndex( pDX, IDC_COMBO1, sndPUNIdx );	

     //Index auswerten
	   ::WP2ClientInfo.sndPUN = unsigned char(sndPUNIdx) + 1;

		 //pSndPUNCtrl = (CComboBox*)GetDlgItem(IDC_COMBO1) ;
		 //longSndPUN = pSndPUNCtrl->GetItemData(sndPUNIdx);

   }
  //keine Aenderung durch User:
	//Transfer von der Klasse zur Dialogbox einleiten
	else
		{
     DDX_Text( pDX, IDC_EDIT10, ::WP2ClientInfo.valPIN );

     //Index bestimmen
	   sndPUNIdx = int(::WP2ClientInfo.sndPUN) - 1;
		 DDX_CBIndex( pDX, IDC_COMBO1, sndPUNIdx );	
		}
}

BEGIN_MESSAGE_MAP(CPOSDispatcherDlg, CDialog)
	//{{AFX_MSG_MAP(CPOSDispatcherDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_WM_TIMER()
	ON_WM_DESTROY()
	ON_BN_CLICKED(IDC_CLRSTAT, OnClearStatistics)
	ON_EN_UPDATE(IDC_EDIT10, OnUpdatePIN)
	ON_BN_CLICKED(IDSETTINGS, OnSettings)
	ON_CBN_DROPDOWN(IDC_COMBO1, OnPUNDropdown)
	ON_BN_CLICKED(IDMANSTAT, OnManstat)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPOSDispatcherDlg message handlers

BOOL CPOSDispatcherDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	//Editbox-Initialisierungen
	valPINCtrl.LimitText(4);

  //((CComboBox*)GetDlgItem(IDC_COMBO1))->SetItemData(0, 3);
  //longSndPUN = pSndPUNCtrl->GetItemData(sndPUNIdx);
  

	//Timer fuer Fenster-Update setzen
	SetTimer(
           upDateTimerID,		// Timer-Identifier
					 1000,	  			  // time-out value
           NULL							// NULL --> Message WM_Timer wird gerufen
					);

	//zu Beginn keine Richtungsaenderung im Schaufeln, da OnInitDialog()
	//selbststaendig einmal Daten zur Dialogbox schaufelt
	userUpdate = 0;
	
	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	CString strAboutMenu;
	strAboutMenu.LoadString(IDS_ABOUTBOX);
	if (!strAboutMenu.IsEmpty())
	{
		pSysMenu->AppendMenu(MF_SEPARATOR);
		pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	//ShowWindow(SW_MINIMIZE);			//Dispatcher als Icon starten

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CPOSDispatcherDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CPOSDispatcherDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CPOSDispatcherDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CPOSDispatcherDlg::OnTimer(UINT nIDEvent) 
{
	//Erzwungenes Update der Dialogbox	
	ThisApp = (CPOSDispatcherApp*)AfxGetApp();	

	if (::WP2ClientInfo.connected == 1)
		{
		 //Ermittlung der POI-Conditions
		 if (::WP2ClientInfo.hook)			//Phoneline-Condition	
	 		 strHook = "onhook";		      //abgehoben
 		 else
			 strHook = "offhook";	        //aufgelegt
	
		 if (::WP2ClientInfo.posReset)  //POS-Reset Auftrag
		   strPOSReset = "pending";		  //anstehend - schwebend	
		 else
			 strPOSReset = "inactive";		//nicht aktiv

  	 if (::WP2ClientInfo.safetyCO)  //Safety Cut Off - Zustand
			 strSCO = "active";					  //aktiv	
		 else
		   strSCO = "inactive";				  //nicht aktiv

		 if (::WP2ClientInfo.sru)       //Speech Reco Unit
			 strSRU = "running";					//laeuft
		 else
		   strSRU = "stopped";					//gestoppt

 		 if (::WP2ClientInfo.device1)	  //Zustand - Device #1			
		 	 strDevice1 = "switched on";	//eingeschaltet
		 else
			 strDevice1 = "switched off"; //ausgeschaltet

		 if (::WP2ClientInfo.device2)	  //Zustand - Device #2			
			 strDevice2 = "switched on";	//eingeschaltet
		 else
			 strDevice2 = "switched off"; //ausgeschaltet

		 if (::WP2ClientInfo.device3)	  //Zustand - Device #3			
		 	 strDevice3 = "switched on";	//eingeschaltet
		 else
			 strDevice3 = "switched off"; //ausgeschaltet

		 if (::WP2ClientInfo.device4)	  //Zustand - Device #4			
		 	 strDevice4 = "switched on";	//eingeschaltet
		 else
			 strDevice4 = "switched off"; //ausgeschaltet
		}
	else							                //keine Verbindung
	  {
 		 strHook = "unknown";		        //Zustand unbekannt
     strPOSReset = "unknown";		    //Zustand unbekannt	
		 strSCO = "unknown";					  //Zustand unbekannt
		 strSRU = "unknown";					  //Zustand unbekannt
		 strDevice1 = "unknown";	      //Zustand unbekannt
		 strDevice2 = "unknown";	      //Zustand unbekannt
		 strDevice3 = "unknown";	      //Zustand unbekannt
		 strDevice4 = "unknown";	      //Zustand unbekannt
	 	}

	//verliert das Hauptfenster den Eingabe-Fokus werden keine Updates mehr ausgefuehrt
	//Hinweis: bei Bereichsueberschreitung verliert das Hauptfenster ebenfalls
	//         den Fokus an die Messagebox --> dadurch wird eine
	//				 Schutzverletzung durch erneutes Update verhindert
	if ( ThisApp->m_pMainWnd == GetActiveWindow() )
	  UpdateData(FALSE);
	else
		 userUpdate = 0;				//Update erst wieder bei Veraenderung
  
	CDialog::OnTimer(nIDEvent);
}

void CPOSDispatcherDlg::OnDestroy() 
{
	CDialog::OnDestroy();
	
	KillTimer(upDateTimerID);
	// TODO: Add your message handler code here
	
}


void CPOSDispatcherDlg::OnClearStatistics() 
{
 //Statistikzaehler loeschen
 ::WP2ClientInfo.cntNoConn  = 0;
 ::WP2ClientInfo.cntDstNRdy = 0;
 ::WP2ClientInfo.cntRetFail = 0;
 ::WP2ClientInfo.cntInvSign = 0;
 ::WP2ClientInfo.cntUnXRec  = 0;
 ::WP2ClientInfo.cntUnXSign = 0;
 ::WP2ClientInfo.cntCCancel = 0;
 ::WP2ClientInfo.cntRetReq  = 0;
 ::WP2ClientInfo.cntUnIdRec = 0;
}

void CPOSDispatcherDlg::OnUpdatePIN() 
{
  //Transfer von der Dialogbox zur Klasse einleiten
  userUpdate = 1;
}

void CPOSDispatcherDlg::OnSettings() 
{
 oldPortNr  = ::PortNr;									//alte Port-Nummer merken
 oldPOI0Adr = ::WP2ClientInfo.poi0Adr;	//alte POI-Adresse merken
 oldOwnAdr  = ::WP2ClientInfo.ownAdr;	  //alte POS-Adresse merken

 CSettings setDlg;											//Objekt anlegen

 //Werte der Settings-Dialogbox zur Verfuegung stellen
 setDlg.portNr = oldPortNr;
 setDlg.poi0Adr = oldPOI0Adr;
 setDlg.ownAdr = oldOwnAdr;

 setResponse = setDlg.DoModal();
 
 //Werte nach OK uebernehmen
 if (setResponse == IDOK)
   {
		::PortNr = setDlg.portNr;
		::WP2ClientInfo.poi0Adr = setDlg.poi0Adr;
		::WP2ClientInfo.ownAdr = setDlg.ownAdr;
	 }
 else if (setResponse == IDCANCEL)
	 {
	  //do nothing...
	 }

 //Bei Aenderungen Threads neu starten
 if ( (oldPortNr != ::PortNr) || (oldPOI0Adr != ::WP2ClientInfo.poi0Adr) || (oldOwnAdr != ::WP2ClientInfo.ownAdr) ) 
	 {
  	::RestartWP2000 = 1;												//Neustart des Threads
    ::RestartClient = 1;												//Neustart des Threads
	 }	  
	
}


void CPOSDispatcherDlg::OnPUNDropdown() 
{
 //Transfer von der Dialogbox zur Klasse einleiten
 userUpdate = 1;
}

void CPOSDispatcherDlg::OnManstat() 
{
 if (::StatusRequest == 0)
   ::StatusRequest = 1 	;

}
