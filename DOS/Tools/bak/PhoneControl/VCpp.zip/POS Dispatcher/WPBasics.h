// WPBasics.h : header file
//
/////////////////////////////////////////////////////////////////////////////
// CWPBasics
#include <afxmt.h>

class CWPBasics 
{
 public:
	//Construction
	CWPBasics();

	//Prototypen von Methoden und Unterprogrammen

	//EvTxtOpen():
	LONG EvTxtOpen( CString locFileName );

	//EvTxtLog():
	LONG EvTxtLog( CString locFileName, CString evUserText, LONG evValue1, LONG evValue2 );

  //GetIniEntryInt:
  LONG GetIniEntryInt( CString locIniFileName, CString locIniSection, CString locIniKeyword, int locIniDefaultValue );

  //SetIniEntryInt:
  void SetIniEntryInt( CString locIniFileName, CString locIniSection, CString locIniKeyword, long locSetValue );

  //GetIniEntryString:
  DWORD GetIniEntryString( CString locIniFileName, CString locIniSection, CString locIniKeyword, CString locIniDefaultString, char *locIniReturnSring );

  //SetIniEntryString:
  void CWPBasics::SetIniEntryString( CString locIniFileName, CString locIniSection, CString locIniKeyword, CString locSetText );


// Variablen
public:
	long locEvTxtOpenStatus;					    //Open-Status
  long locEvTxtLogStatus;								//Textlog-Status		
	DWORD evLogSizeHigh;									//Event-Log Filegroesse
  DWORD evLogSizeLow;										//Event-Log Filegroesse

  DWORD evBytesWritten;									//Anzahl geschriebener Event-Zeichen
  DWORD evTextLenght;										//Text-Laenge
	CTime evTime;													//aktuelle Zeit
	CString evText;												//vollstaendiger Event-Text
	CString evTempText;										//Text-Objekt
  char pathStr[256];										//Pfad-String
	SYSTEMTIME evSystemTime;							//Systemzeit
	char timeStr;	       									//Time-Zeichen fuer ms-Wandlung
	HANDLE locEvLogHandle;								//Handle fuer File
	char valText[30];											//String der Values
  long locIniValue;                     //ausgelesener Wert aus INI-File
  char locSetString[255];               //zu schreibender Wert in Ini-File in String-Form
  CString locSetText;                   //String-Objekt
  DWORD locNbChar;                      //Anzahl ausgelesener Zeichen bei GetIniEntrySrting()

// Implementation
public:
	virtual ~CWPBasics();

private:
   CCriticalSection csOpen;							//Objekt zur Synchronisation von EvTxtOpen()
   CCriticalSection csLog;            	//Objekt zur Synchronisation von EvTxtLog()
   CCriticalSection csGetInt;          	//Objekt zur Synchronisation von GetIniEntryInt()
   CCriticalSection csSetInt;          	//Objekt zur Synchronisation von SetIniEntryInt()
   CCriticalSection csGetStr;          	//Objekt zur Synchronisation von GetIniEntryStr()
   CCriticalSection csSetStr;          	//Objekt zur Synchronisation von SetIniEntryStr()

	// Generated message map functions
protected:
};