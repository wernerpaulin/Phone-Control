//****************************************************************************//
//   Copyright:  1998  WePa - Entwicklungsabteilung                           //
//****************************************************************************//
//   Kennzeichnung:                                                           //
//       ID-Nr.       030209019677                                            //
//       System       WPBasics                                                //
//       Sub-System   ---                                                     //
//       Funktion     diverse Standart-Funktionen                             //
//										Funktionen																							//
//       Filename     WPBasics.cpp                                            //
//****************************************************************************//
//   History:                                                                 //
//   Version     Datum       Autor           Bemerkung                        //
//   00.01       09.07.98    W. Paulin       Erstellung                       //
//																					 neu EvTxtOpen(), EvTxtLog()      //
//   01.00       11.07.98    W. Paulin       Create-Information im Log-File   //
//																					 lokale Systemzeit fuer ms        //
//																					 Mutex implementiert              //
//   01.01       18.07.98    W. Paulin       File wird nach jedem Schreibvor- //
//																					 wieder geschlossen								//
//																					 Loggen von 2 Werten implementiert//
//   01.02       05.08.98    W. Paulin       CritecalSection implementiert    //
//   01.03       18.10.98    W. Paulin       �bergebene Werte in dezimal. Form//
//                                           GetIniEntryInt() implementiert   //
//                                           SetIniEntryInt() implementiert   //
//   01.04       31.10.98    W. Paulin       SetIniEntryString() implementiert//
//                                           GetIniEntryString() implementiert//
//   01.05       01.11.98    W. Paulin       History nachgef�hrt              //
//****************************************************************************//
// Beschreibung:                                                              //
//	- folgende Methoden werden unterstuetzt:														      //
//				* EvTxtOpen():																											//
//											- Aufgabe: Log-File Erstellung und Initalisierung     //
//											- Eingabeparameter: ...Filename mit Pfad als CString	//
//											- Ausgabeparameter: ...Fehlerstatus										//
//																																						//			
//				* EvTxtLog():	  																										//
//											- Aufgabe: Log-Texte in Log-File schreiben            //
//											- Eingabeparameter: ...Log-Text                     	//
//																					...Detail #1 im Format LONG 			//
//																					...Detail #2 im Format LONG 			//
//											- Ausgabeparameter: ...Fehlerstatus										//
//																																						//
//				* GetIniEntryInt():			  																					//
//											- Aufgabe: Liest Int-Wert aus Ini-File aus            //
//											- Eingabeparameter: ...Filename mit Pfad als CString	//
//																					...Section-Name   								//
//                                          ...Keyword                        //
//                                          ...Default-Wert wenn undefiniert  //
//											- Ausgabeparameter: ...Int-Wert   										//
//																																						//
//				* SetIniEntryInt():			  																					//
//											- Aufgabe: Schreibt Int-Wert in Ini-File              //
//											- Eingabeparameter: ...Filename mit Pfad als CString	//
//																					...Section-Name   								//
//                                          ...Keyword                        //
//                                          ...zu schreibender Int-Wert       //
//											- Ausgabeparameter: ...void       										//
//																																						//
//				* GetIniEntryString():			  																 	  	//
//											- Aufgabe: Liest einen String aus Ini-File aus        //
//											- Eingabeparameter: ...Filename mit Pfad als CString	//
//																					...Section-Name   								//
//                                          ...Keyword                        //
//                                          ...Default-String wenn undefiniert//
//											- Ausgabeparameter: ...String     										//
//                                          ...Anzahl ausgelesener Zeichen    //
//																																						//
//				* SetIniEntryString():			  															  			//
//											- Aufgabe: Schreibt einen Sring in Ini-File           //
//											- Eingabeparameter: ...Filename mit Pfad als CString	//
//																					...Section-Name   								//
//                                          ...Keyword                        //
//                                          ...zu schreibender String         //
//											- Ausgabeparameter: ...void       										//
//																																						//
//	- Fehlerstati:																											      //		
//				* EvTxtOpen():																											//
//										    0... Log-File fehlerfrei initialisiert							//
//										  100... Log-File konnte nicht erstellt werden				  //
//				* EvTxtLog():																							  				//
//										    0... Text-Log konnte	fehlerfrei abgesetzt werden		//
//										  100... Log-File wurde nicht geoeffnet       				  //
//****************************************************************************//

#include "stdafx.h"
#include "POS Dispatcher.h"
#include "WPBasics.h"
#include "iostream.h"
#include "string.h"

/////////////////////////////////////////////////////////////////////////////
// CWPBasics

CWPBasics::CWPBasics()
{
}

CWPBasics::~CWPBasics()
{
}

/////////////////////////////////////////////////////////////////////////////
// Methoden

//EvTxtOpen():
LONG CWPBasics::EvTxtOpen( CString locFileName )
  {
	 CSingleLock cslOpen(&csOpen, TRUE);	 								//entry critical section
	 VERIFY(cslOpen.IsLocked());													//Kontrolle ob Entry erfolgreich war
	 
	 //.................... Logfile oeffnen /Beginn ....................//
   locEvLogHandle = CreateFile(  												
	  											     locFileName,	          //File-Name
															 GENERIC_WRITE,         //nur schreiben
															 0,											//privat reserviert 
															 NULL, 									//von WIN95 ignoriert  
															 OPEN_ALWAYS,						//ggf. Neuerstellung
															 FILE_ATTRIBUTE_NORMAL, //keine Besonderen Attribute
															 NULL 									//von WIN95 nicht unterstuetzt
  													  );	
 
	 locEvTxtOpenStatus = 0;									//Default: kein Fehler
	 	
	 if ( locEvLogHandle == INVALID_HANDLE_VALUE )
		 {
		  locEvTxtOpenStatus = 100;           //File konnte nicht erstellt werden
  	 	return locEvTxtOpenStatus;
		 }
	 //..................... Logfile oeffnen /Ende .....................//



	 //................. File - Initialisierung /Beginn ................//
   evLogSizeLow = GetFileSize(locEvLogHandle, &evLogSizeHigh);
   SetFilePointer(
                  locEvLogHandle,	        // handle of file 
                  LONG(evLogSizeLow),	    // number of bytes to move file pointer 
                  PLONG(&evLogSizeHigh),	// address of high-order word of distance to move  
								  FILE_BEGIN	            // how to move 
						     );   

   //Headlines beim File-Erstellung eintragen
   if (evLogSizeLow == 0)
		 {
  	  evTime = CTime::GetCurrentTime();

		  evTime.GetCurrentTime();
			evText = evTime.Format( "Created %d.%m.%y %H:%M:%S with " );
			
			//aktuellen Pfad bestimmen
			GetCurrentDirectory( 256, pathStr); 
			evText += pathStr;
			evText += "\\";

			//Applikationsname ermitteln
			evTempText = AfxGetAppName();
			evText += evTempText;
			evText += ".exe";

			evTextLenght = evText.GetLength();

	    //Erstellungs-Information
			WriteFile(
			 				  locEvLogHandle,                          //Handle des geoeffneten COM-Ports
	    				  evText,                                  //zu schreibender Text
		    			  evTextLenght,                  	         //Textlaenge
			     		  &evBytesWritten,										     //Anzahl geschriebnene Bytes
				    	  NULL																     //kein Overlapped-Betrieb	
					     );

			//Leerzeile
	    WriteFile(
			 				  locEvLogHandle,                          //Handle des geoeffneten COM-Ports
	    				  "\r\n",                                  //zu schreibender Text
		    			  4,                          	           //Textlaenge
			     		  &evBytesWritten,										     //Anzahl geschriebnene Bytes
				    	  NULL																     //kein Overlapped-Betrieb	
					     );

			//Headline
	    evText = "\r\n  Date   |     Time     || Event-Text";
			evTextLenght = evText.GetLength();

			WriteFile(
			 				  locEvLogHandle,                          //Handle des geoeffneten COM-Ports
	    				  evText,																	 //zu schreibender Text
		    			  evTextLenght,                          	 //Textlaenge
			     		  &evBytesWritten,										     //Anzahl geschriebnene Bytes
				    	  NULL																     //kein Overlapped-Betrieb	
					     );
		 }
	 CloseHandle(locEvLogHandle);																//File schliessen
   //.................. File - Initialisierung /Ende .................//
	 
	 return locEvTxtOpenStatus;
	}


//EvTxtLog():	
LONG CWPBasics::EvTxtLog( CString locFileName, CString evUserText, LONG evValue1, LONG evValue2 )
	{
	 CSingleLock cslLog(&csLog, TRUE);	 								//entry critical section
	 VERIFY(cslLog.IsLocked());													//Kontrolle ob Entry erfolgreich war

	 //.................... Logfile oeffnen /Beginn ....................//
   locEvLogHandle = CreateFile(  												
	  											     locFileName,	          //File-Name
															 GENERIC_WRITE,         //nur schreiben
															 0,											//privat reserviert 
															 NULL, 									//von WIN95 ignoriert  
															 OPEN_EXISTING,	  			//muss bereits existieren
															 FILE_ATTRIBUTE_NORMAL, //keine Besonderen Attribute
															 NULL 									//von WIN95 nicht unterstuetzt
  													  );	
 
	 locEvTxtLogStatus = 0;									//Default: kein Fehler
	 	
	 if ( locEvLogHandle == INVALID_HANDLE_VALUE )
		 {
		  locEvTxtOpenStatus = 100;           //Log-File konnte nicht geoeffnet werden
			return locEvTxtOpenStatus;
		 }
	 
	 //Append vorbereiten: EOF-Position einnehmen
	 evLogSizeLow = GetFileSize(locEvLogHandle, &evLogSizeHigh);
   SetFilePointer(
                  locEvLogHandle,	        // handle of file 
                  LONG(evLogSizeLow),	    // number of bytes to move file pointer 
                  PLONG(&evLogSizeHigh),	// address of high-order word of distance to move  
								  FILE_BEGIN	            // how to move 
						     );   
	 //..................... Logfile oeffnen /Ende .....................//


   //.............. Log-Text mit Zeit ermitteln /Beginn ..............//
	 GetLocalTime( &evSystemTime );	//lokale Systemzeit fuer ms holen

	 evTime = CTime::GetCurrentTime();
  
	 evTime.GetCurrentTime();
	 evText = evTime.Format( "\r\n%d.%m.%y | %H:%M:%S," );

 	 //ASCII-Wandlung der ms
 	 timeStr = (evSystemTime.wMilliseconds / 100) % 10 + '0';	//Integer -> ASCII - Wandlung
	 evText += timeStr;

	 timeStr = (evSystemTime.wMilliseconds /  10) % 10 + '0';	//Integer -> ASCII - Wandlung
	 evText += timeStr;

	 timeStr = (evSystemTime.wMilliseconds /   1) % 10 + '0';	//Integer -> ASCII - Wandlung
	 evText += timeStr;
 
	 evText += "    ";
	 
   evText.SetAt( 25, ' ' );
	 evText.SetAt( 26, '|' );
   evText.SetAt( 27, '|' );
   evText.SetAt( 28, ' ' );

	 evText += evUserText;

   evText += " : ";

	 //uebergebene Werte eintragen
   _ltoa( evValue1, valText, 10 );
   evText += valText;
 
   evText += " / ";
	 
   _ltoa( evValue2, valText, 10 );
   evText += valText;

	 evTextLenght = evText.GetLength();
   //............... Log-Text mit Zeit ermitteln /Ende ................//
 
  
	 //..................... Event absetzen /Beginn ....................//
   locEvTxtLogStatus = WriteFile(
										  					 locEvLogHandle,	   //Handle des geoeffneten COM-Ports
	  														 evText,             //zu schreibender Text
												  			 evTextLenght,       //Textlaenge
			  												 &evBytesWritten,    //Anzahl geschriebnene Bytes
														  	 NULL							   //kein Overlapped-Betrieb	
																);
	 //...................... Event absetzen /Ende .....................//

	 if (locEvTxtLogStatus == TRUE)					//kein Fehler
		 locEvTxtLogStatus = 0;

	 CloseHandle(locEvLogHandle);																//File schliessen

	 return locEvTxtLogStatus;
	}


//GetIniEntryInt()
LONG CWPBasics::GetIniEntryInt( CString locIniFileName, CString locIniSection, CString locIniKeyword, int locIniDefaultValue )
  {
	 CSingleLock cslGetInt(&csGetInt, TRUE);	 								//entry critical section
	 VERIFY(cslGetInt.IsLocked());			  										//Kontrolle ob Entry erfolgreich war
	 
	 //.................... Auslesen der Ini-Sektion /Beginn ....................//
   locIniValue = GetPrivateProfileInt(
                                      locIniSection,	        // address of section name
                                      locIniKeyword,	        // address of key name
                                      locIniDefaultValue,     // return value if key name is not found
                                      locIniFileName 	        // address of initialization filename
                                     );
	 //..................... Auslesen der Ini-Sektion /Ende .....................//

   return locIniValue;
  }


//SetIniEntryInt()
void CWPBasics::SetIniEntryInt( CString locIniFileName, CString locIniSection, CString locIniKeyword, long locSetValue )
  {
	 CSingleLock cslSetInt(&csSetInt, TRUE);	 								//entry critical section
	 VERIFY(cslSetInt.IsLocked());			  										//Kontrolle ob Entry erfolgreich war

   _ltoa( locSetValue, locSetString, 10 );                  //ASCII-Wandlung
   locSetText = locSetString;                               //CString-Konvertierung f�r Funktion
   
   //.................... Beschreiben der Ini-Sektion /Beginn ....................//
   WritePrivateProfileString(
                             locIniSection,	                // address of section name
                             locIniKeyword,	                // address of key name
                             locSetText,                    // String to be written in the Ini-File
                             locIniFileName 	              // address of initialization filename
                            );
 
   //..................... Beschreiben der Ini-Sektion /Ende .....................//
  }

  
 //GetIniEntryString()
 DWORD CWPBasics::GetIniEntryString( CString locIniFileName, CString locIniSection, CString locIniKeyword, CString locIniDefaultString, char *locIniReturnSring )
  {
	 CSingleLock cslGetStr(&csGetStr, TRUE);	 								//entry critical section
	 VERIFY(cslGetStr.IsLocked());			  										//Kontrolle ob Entry erfolgreich war
	 
	 //.................... Auslesen der Ini-Sektion /Beginn ....................//
   locNbChar = GetPrivateProfileString(
                                       locIniSection,	                // address of section name
                                       locIniKeyword,	                // address of key name
                                       locIniDefaultString,           // return value if key name is not found
                                       locIniReturnSring,     	      // points to destination buffer 
                                       256,                         	// size of destination buffer 
                                       locIniFileName 	              // address of initialization filename
                                      );
   //..................... Auslesen der Ini-Sektion /Ende .....................//

   return locNbChar;
  }

//SetIniEntryString()
void CWPBasics::SetIniEntryString( CString locIniFileName, CString locIniSection, CString locIniKeyword, CString locSetText )
  {
	 CSingleLock cslSetStr(&csSetInt, TRUE);	 								//entry critical section
	 VERIFY(cslSetStr.IsLocked());			  										//Kontrolle ob Entry erfolgreich war

   //.................... Beschreiben der Ini-Sektion /Beginn ....................//
   WritePrivateProfileString(
                             locIniSection,	                // address of section name
                             locIniKeyword,	                // address of key name
                             locSetText,                    // String to be written in the Ini-File
                             locIniFileName 	              // address of initialization filename
                            );
 
   //..................... Beschreiben der Ini-Sektion /Ende .....................//
  }
