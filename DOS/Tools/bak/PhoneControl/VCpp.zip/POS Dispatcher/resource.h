//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by POS Dispatcher.rc
//
#define IDSETTINGS                      3
#define IDMANSTAT                       4
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_POSDISPATCHER_DIALOG        102
#define IDP_SOCKETS_INIT_FAILED         103
#define IDR_MAINFRAME                   128
#define IDD_SETTINGS                    131
#define IDI_PHONE07                     133
#define IDI_EXCL                        136
#define IDC_EDIT1                       1013
#define IDC_EDIT2                       1014
#define IDC_EDIT3                       1015
#define IDC_EDIT4                       1016
#define IDC_EDIT5                       1017
#define IDC_EDIT6                       1018
#define IDC_EDIT7                       1019
#define IDC_EDIT8                       1020
#define IDC_EDIT9                       1021
#define IDC_EDIT10                      1022
#define IDC_CLRSTAT                     1023
#define IDC_COMBO1                      1030
#define IDC_HOOK                        1033
#define IDC_POSRESET                    1034
#define IDC_COMPORT                     1034
#define IDC_POIADR                      1035
#define IDC_SCO                         1036
#define IDC_POSADR                      1036
#define IDC_SRU                         1038
#define IDC_DEVICE1                     1039
#define IDC_DEVICE2                     1040
#define IDC_DEVICE3                     1041
#define IDC_DEVICE4                     1043

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        138
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1037
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
