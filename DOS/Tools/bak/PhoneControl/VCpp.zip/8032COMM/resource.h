//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by 8032comm.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_MY8032TYPE                  129
#define IDD_DIALOG1                     130
#define IDD_DIALOG2                     170
#define IDD_DIALOG3                     174
#define IDD_DIALOG4                     184
#define IDD_DIALOG5                     185
#define IDD_DIALOG6                     186
#define IDI_LightOn                     191
#define IDI_LightOff                    192
#define IDI_W95mbx03                    193
#define IDB_PC1                         198
#define IDB_Speech                      199
#define IDC_COMBO1                      1000
#define IDC_EDIT1                       1011
#define IDC_EDIT2                       1012
#define IDC_EDIT3                       1013
#define IDC_RADIO1                      1014
#define IDC_RADIO2                      1015
#define IDC_RADIO3                      1016
#define IDC_RADIO4                      1017
#define IDC_TELLINE                     1019
#define IDC_SECURE                      1020
#define IDC_LASTRECCHAR                 1021
#define IDC_LASTTRACHAR                 1022
#define IDC_SPEECHREC                   1023
#define IDC_SPEECHPROF                  1024
#define ID_HARDWARE_SETTINGS            32772
#define ID_SETTINGS_SOFTWARE            32773
#define ID_SETTINGS_SERIALPORT          32774
#define ID_SYSTEM_MONITOR               32775
#define ID_HELP_SOFTWARE                32778
#define ID_SETTINGS_SAVESETTINGS        32779
#define ID_HELP_TELKEY                  32780
#define ID_SETTINGS_RECALLFACTORY       32781

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        200
#define _APS_NEXT_COMMAND_VALUE         32782
#define _APS_NEXT_CONTROL_VALUE         1024
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
