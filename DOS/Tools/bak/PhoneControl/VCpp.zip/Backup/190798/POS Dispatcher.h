// POS Dispatcher.h : main header file for the POS DISPATCHER application
//

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

struct WP2TgmHdr_s										//Telegramm-Header Struktur
	{
	 unsigned int tgmLen;
	 unsigned long jobNr;
	 unsigned char dstAdr;	
	 unsigned char srcAdr;	
	};

struct Job04Tgm_s											//Job-Telegramm mit 4 + 1 Nutzdaten	
	{
	 WP2TgmHdr_s hdr;
	 int jobId;
	 unsigned char status;
	 unsigned char data[4];
	};

struct Reply04Tgm_s	  						  	//Reply-Telegramm mit 4 + 1 Nutzdaten	
  {
	 WP2TgmHdr_s hdr;
	 int jobId;
	 unsigned char status;
	 unsigned char data[4];
	};

struct MesList_s										//Liste f. den Message-Executor
	{
	 unsigned char mesId;
	 unsigned char mesData[8];
	 int mesStatus;
	};

struct ClientInfo_s
	{
	 unsigned long cntNoConn;
	 unsigned long cntDstNRdy;
	 unsigned long cntRetFail;
	 unsigned long cntInvSign;
	 unsigned long cntUnXRec;
	 unsigned long cntUnXSign;
	 unsigned long cntCCancel;
	 unsigned long cntRetReq;
	 unsigned long cntUnIdRec;
	 unsigned long cntValPIN;
	 unsigned long cntInvPIN;
	 unsigned char poi0Adr;
	 unsigned char ownAdr;
   //WORD valPIN;
   unsigned long valPIN;
	 unsigned char sndPUN;
	 BYTE hook;
	 BYTE posReset;
	 BYTE safetyCO;
	 BYTE sru;
	 BYTE device4;
	 BYTE device3;
	 BYTE device2;
	 BYTE device1;
   BYTE connected;
	};

struct ClientThreadInfo_s											  //Thread-Info - Struktur
	{
   ClientInfo_s *pWP2ClientInfo;								//Client-Infostruktur
	 LPVOID pPOSDispApp;						              //Pointer auf App-Klasse
	 LPVOID pPOSDispDlg;		              				//Pointer auf Dlg-Klasse
	};		  


extern ClientThreadInfo_s ClientThreadInfo; //Thread-Infostruktur fuer Client
extern ClientInfo_s WP2ClientInfo;	        //Client-Infostruktur- externe Deklaration
extern Job04Tgm_s WP2JobTgm;                //Job-Telegramm extern deklariert
extern Reply04Tgm_s WP2ReplyTgm;            //Reply-Telegramm extern deklariert
extern BYTE PortNr;													//Port-Nummer extern deklariert
extern BYTE RestartClient;									//Restart-Auftrag fuer Client
extern BYTE RestartWP2000;									//Restart-Auftrag fuer WP2000-Treiber
extern WORD GDebOn;	  											//globaler DEBUG-Mode
extern HANDLE SioHandle;										//Handle des COM-Ports
extern HANDLE EvLogHandle;									//Handle des Event-Log - Files
extern CString EvFileName;								  //Filename fuer Text-Log					


/////////////////////////////////////////////////////////////////////////////
// CPOSDispatcherApp:

class CPOSDispatcherApp : public CWinApp 
{
public:
  
	CPOSDispatcherApp();									//Konstruktor
	virtual ~ CPOSDispatcherApp();				//Destruktor

  CWinThread *m_pWP2000;								//Pointer fuer WP2000-Thread
  CWinThread *m_pWP2Client;							//Pointer fuer WP2000-Client-Thread

	char pathStr[256];										//Pfad-String

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPOSDispatcherApp)
	public:
	virtual BOOL InitInstance();
	virtual BOOL InitApplication();
	virtual int ExitInstance();
	//}}AFX_VIRTUAL


	//{{AFX_MSG(CPOSDispatcherApp)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()


};

/////////////////////////////////////////////////////////////////////////////

