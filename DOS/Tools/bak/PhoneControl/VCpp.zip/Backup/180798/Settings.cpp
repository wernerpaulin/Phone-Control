// Settings.cpp : implementation file
//

#include "stdafx.h"
#include "pos dispatcher.h"
#include "Settings.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSettings dialog


CSettings::CSettings(CWnd* pParent /*=NULL*/)
	: CDialog(CSettings::IDD, pParent)
{
	//{{AFX_DATA_INIT(CSettings)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CSettings::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CSettings)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP

//	DDX_Text( pDX, IDC_EDIT1, ::WP2ClientInfo.poi0Adr );
//	DDV_MinMaxByte( pDX, ::WP2ClientInfo.poi0Adr, 0, 15 );
	DDX_Text( pDX, IDC_EDIT1, poi0Adr );
	DDV_MinMaxByte( pDX, poi0Adr, 0, 15 );

//	DDX_Text( pDX, IDC_EDIT2, ::WP2ClientInfo.ownAdr );
//  DDV_MinMaxByte( pDX, ::WP2ClientInfo.ownAdr, 0, 15 );
	DDX_Text( pDX, IDC_EDIT2, ownAdr );
  DDV_MinMaxByte( pDX, ownAdr, 0, 15 );

	//Index bestimmen, wenn Daten an die Dialogbox gesendet werden
	if (!pDX->m_bSaveAndValidate)
  	portNrIdx = portNr - 1;
//  	portNrIdx = ::PortNr - 1;
	
	DDX_CBIndex( pDX, IDC_COMBO1, portNrIdx );	
	
	//Index auswerten, wenn Daten von der Dialogbox empfangen werden
	if (pDX->m_bSaveAndValidate)
	   portNr = portNrIdx + 1;
//	   ::PortNr = portNrIdx + 1;
	
}


BEGIN_MESSAGE_MAP(CSettings, CDialog)
	//{{AFX_MSG_MAP(CSettings)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSettings message handlers
