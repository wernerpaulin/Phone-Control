//****************************************************************************//
//   Copyright:  1998  WePa - Entwicklungsabteilung                           //
//****************************************************************************//
//   Kennzeichnung:                                                           //
//       ID-Nr.       030209019677                                            //
//       System       WPBasics                                                //
//       Sub-System   ---                                                     //
//       Funktion     diverse Standart-Funktionen                             //
//										Funktionen																							//
//       Filename     WPBasics.cpp                                            //
//****************************************************************************//
//   History:                                                                 //
//   Version     Datum       Autor           Bemerkung                        //
//   00.01       09.07.98    W. Paulin       Erstellung                       //
//																					 neu EvTxtOpen(), EvTxtLog()      //
//   01.00       11.07.98    W. Paulin       Create-Information im Log-File   //
//																					 lokale Systemzeit fuer ms        //
//																					 Mutex implementiert              //
//****************************************************************************//
// Beschreibung:                                                              //
//	- folgende Methoden werden unterstuetzt:														      //
//				* EvTxtOpen():																											//
//											- Aufgabe: Log-File Erstellung und Initalisierung     //
//											- Eingabeparameter: ...Filename mit Pfad als CString	//
//																																						//
//											- Ausgabeparameter: ...Fehlerstatus										//
//																					...Handle des geoeffneten Files	  //
//																																						//			
//	- Fehlerstati:																											      //		
//				* EvTxtOpen():																											//
//										    0... Log-File fehlerfrei initialisiert							//
//										  100... Log-File konnte nicht geoeffnet werden				  //
//				* EvTxtLog():																							  				//
//										    0... Text-Log konnte	fehlerfrei abgesetzt werden		//
//										  100... Log-File wurde nicht geoeffnet       				  //
//****************************************************************************//

#include "stdafx.h"
#include "POS Dispatcher.h"
#include "WPBasics.h"
#include "iostream.h"
#include "string.h"


/////////////////////////////////////////////////////////////////////////////
// CWPBasics

CWPBasics::CWPBasics()
{
}

CWPBasics::~CWPBasics()
{
}

/////////////////////////////////////////////////////////////////////////////
// Methoden

//EvTxtOpen():
LONG CWPBasics::EvTxtOpen(CString locFileName, HANDLE &locEvLogHandle)
  {
	 //.................... Logfile oeffnen /Beginn ....................//
   locEvLogHandle = CreateFile(  												
	  											     locFileName,	          //File-Name
															 GENERIC_WRITE,         //nur schreiben
															 0,											//privat reserviert 
															 NULL, 									//von WIN95 ignoriert  
															 OPEN_ALWAYS,						//ggf. Neuerstellung
															 FILE_ATTRIBUTE_NORMAL, //keine Besonderen Attribute
															 NULL 									//von WIN95 nicht unterstuetzt
  													  );	
 
	 locEvTxtOpenStatus = 0;									//Default: kein Fehler
	 	
	 if ( locEvLogHandle == INVALID_HANDLE_VALUE )
		 {
		  locEvTxtOpenStatus = 100;           //COM-Port existiert nicht
			return locEvTxtOpenStatus;
		 }
	 //..................... Logfile oeffnen /Ende .....................//



	 //................. File - Initialisierung /Beginn ................//
   evLogSizeLow = GetFileSize(locEvLogHandle, &evLogSizeHigh);
   SetFilePointer(
                  locEvLogHandle,	        // handle of file 
                  LONG(evLogSizeLow),	    // number of bytes to move file pointer 
                  PLONG(&evLogSizeHigh),	// address of high-order word of distance to move  
								  FILE_BEGIN	            // how to move 
						     );   

   //Headlines beim File-Erstellung eintragen
   if (evLogSizeLow == 0)
		 {
  	  evTime = CTime::GetCurrentTime();

		  evTime.GetCurrentTime();
			evText = evTime.Format( "Created %d.%m.%y %H:%M:%S with " );
			
			//aktuellen Pfad bestimmen
			GetCurrentDirectory( 256, pathStr); 
			evText += pathStr;
			evText += "\\";

			//Applikationsname ermitteln
			evTempText = AfxGetAppName();
			evText += evTempText;
			evText += ".exe";

			evTextLenght = evText.GetLength();

	    //Erstellungs-Information
			WriteFile(
			 				  locEvLogHandle,                          //Handle des geoeffneten COM-Ports
	    				  evText,                                  //zu schreibender Text
		    			  evTextLenght,                  	         //Textlaenge
			     		  &evBytesWritten,										     //Anzahl geschriebnene Bytes
				    	  NULL																     //kein Overlapped-Betrieb	
					     );

			//Leerzeile
	    WriteFile(
			 				  locEvLogHandle,                          //Handle des geoeffneten COM-Ports
	    				  "\r\n",                                  //zu schreibender Text
		    			  4,                          	           //Textlaenge
			     		  &evBytesWritten,										     //Anzahl geschriebnene Bytes
				    	  NULL																     //kein Overlapped-Betrieb	
					     );

			//Headline
	    evText = "\r\n  Date   |     Time     || Event-Text";
			evTextLenght = evText.GetLength();

			WriteFile(
			 				  locEvLogHandle,                          //Handle des geoeffneten COM-Ports
	    				  evText,																	 //zu schreibender Text
		    			  evTextLenght,                          	 //Textlaenge
			     		  &evBytesWritten,										     //Anzahl geschriebnene Bytes
				    	  NULL																     //kein Overlapped-Betrieb	
					     );
		 }
	 //.................. File - Initialisierung /Ende .................//

	 return locEvTxtOpenStatus;
	}


//EvTxtLog():	
LONG CWPBasics::EvTxtLog( HANDLE locEvLogHandle, CString evUserText )
	{
   //.............. Log-Text mit Zeit ermitteln /Beginn ..............//
   if (locEvTxtOpenStatus != 0)
		 {
 		  locEvTxtLogStatus = 100;
    	return locEvTxtLogStatus;
		 }

	 GetLocalTime( &evSystemTime );	//lokale Systemzeit fuer ms holen

	 evTime = CTime::GetCurrentTime();
  
	 evTime.GetCurrentTime();
	 evText = evTime.Format( "\r\n%d.%m.%y | %H:%M:%S," );

 	 //ASCII-Wandlung der ms
 	 timeStr = (evSystemTime.wMilliseconds / 100) % 10 + '0';	//Integer -> ASCII - Wandlung
	 evText += timeStr;

	 timeStr = (evSystemTime.wMilliseconds /  10) % 10 + '0';	//Integer -> ASCII - Wandlung
	 evText += timeStr;

	 timeStr = (evSystemTime.wMilliseconds /   1) % 10 + '0';	//Integer -> ASCII - Wandlung
	 evText += timeStr;
 
	 evText += "    ";
	 
   evText.SetAt( 25, ' ' );
	 evText.SetAt( 26, '|' );
   evText.SetAt( 27, '|' );
   evText.SetAt( 28, ' ' );

	 evText += evUserText;
   evTextLenght = evText.GetLength();
   //............... Log-Text mit Zeit ermitteln /Ende ................//
 
  
	 //..................... Event absetzen /Beginn ....................//
   //gleichzeitiges Schreiben verhindern
	 evMutexHndl = ::CreateMutex(NULL,TRUE,NULL);

	 ::WaitForSingleObject(evMutexHndl, INFINITE);
   locEvTxtLogStatus = WriteFile(
										  					 locEvLogHandle,	   //Handle des geoeffneten COM-Ports
	  														 evText,             //zu schreibender Text
												  			 evTextLenght,       //Textlaenge
			  												 &evBytesWritten,    //Anzahl geschriebnene Bytes
														  	 NULL							   //kein Overlapped-Betrieb	
																);
	 ::ReleaseMutex(evMutexHndl);
	 //...................... Event absetzen /Ende .....................//

	 if (locEvTxtLogStatus == TRUE)					//kein Fehler
		 locEvTxtLogStatus = 0;

	 return locEvTxtLogStatus;
	}
