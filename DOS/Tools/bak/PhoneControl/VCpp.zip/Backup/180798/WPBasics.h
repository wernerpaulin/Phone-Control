// WPBasics.h : header file
//
/////////////////////////////////////////////////////////////////////////////
// CWPBasics

class CWPBasics 
{
 public:
	//Construction
	CWPBasics();

	//Prototypen von Methoden und Unterprogrammen

	//EvTxtOpen():
	LONG EvTxtOpen( CString locFileName, HANDLE &locEvLogHandle );

	//EvTxtLog():
	LONG EvTxtLog( HANDLE locEvLogHandle, CString evUserText );

// Variablen
public:
  long locEvTxtOpenStatus;					    //Open-Status
  long locEvTxtLogStatus;								//Textlog-Status		
	DWORD evLogSizeHigh;									//Event-Log Filegroesse
  DWORD evLogSizeLow;										//Event-Log Filegroesse

  DWORD evBytesWritten;									//Anzahl geschriebener Event-Zeichen
  DWORD evTextLenght;										//Text-Laenge
	CTime evTime;													//aktuelle Zeit
	CString evText;												//vollstaendiger Event-Text
	CString evTempText;										//Text-Objekt
  char pathStr[256];										//Pfad-String
	SYSTEMTIME evSystemTime;							//Systemzeit
	char timeStr;	       									//Time-Zeichen fuer ms-Wandlung
	HANDLE evMutexHndl;										//Handle fuer Mutex

// Implementation
public:
	virtual ~CWPBasics();

	// Generated message map functions
protected:
};