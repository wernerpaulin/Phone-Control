// SIO.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CSIO window

// globale Deklaration:
struct SioMode_s										//serial I/O-Mode - Struktur
	{
	 DWORD baudrate;
	 unsigned char parity;
	 DWORD ctsControl;
	 DWORD dsrControl;
	 DWORD dtrControl;
	 DWORD rtsControl;
	 BYTE  nbDataBytes;
	 BYTE  stopBits;
	};


class CSIO 
{
//Strukturen und Variablen
public:

CString strPortNr;									//Port-Nr. im ASCII-Format
CString portName;										//Port-Sring fuer CreateFile()
ULONG locBytesRead;				        	//Anzahl gelesener Bytes
ULONG locBytesWritten;							//Anzahl geschriebener Bytes

LONG locOpenStatus;       					//Fehlerstatus nach dem Oeffnen
LONG locCloseStatus;       				  //Fehlerstatus nach dem Schliessen
LONG locReadStatus;      					  //Fehlerstatus nach dem Lesen
LONG locWriteStatus;	        			//Fehlerstatus nach dem Schreiben

DWORD dwEventMaskValue;							//Eventmaske

OVERLAPPED sioOverlapped;				    //Overlapped-Struktur 
DCB sioDCB;													//Device-Control-Block - Struktur anlegen
COMMTIMEOUTS sioCommTO;							//Communication-Timeout - Struktur anlegen
double sioTimeoutValue;							//Faktor zur Timeoutberechnung

LONG getStatus;											//Status fuer GetOverlappedResult()	
LONG waitStatus;										//Status fuer WaitCommEvent()
LONG waitObjStatus;									//Status fuer WaitForSingleObject()
BYTE cyclicWait;								    //Flag fuer zyklisches Warten
BYTE cyclicGet;	  							    //Flag fuer zyklisches GetLastError beim Lesen
DWORD nbByteTxRx;										//Anzahl empfangener Bytes

// Construction
public:

	//Prototypen von Methoden und Unterprogrammen
	CSIO();
	
	//...SIO_OPEN - Prototyp
	LONG SIO_OPEN( BYTE locPortNr,								//dezimale Prot-Nummer
								 DWORD locRxBufLng,							//Empfangsbuffer-Laenge in Bytes
								 DWORD locTxBufLng,							//Sendebuffer-Laenge in Bytes
								 SioMode_s &locSioMode,					//Modus der seriellen Verbindung
								 HANDLE &locSioHandle );				//Handle des geoeffneten COM-Ports

	//...SIO_CLOSE - Prototyp
	LONG SIO_CLOSE( HANDLE &locSioHandle );				//Handle des geoeffneten COM-Ports

	//...SIO_READ - Prototyp
	LONG SIO_READ( HANDLE &locSioHandle,					//Handle des geoeffneten COM-Ports
		  					 LPVOID locRxBuf,								//Pointer auf Empfangsbuffer
  					     DWORD locRxBufLng );		    		//Empfangsbuffer-Laenge in Bytes

	//...SIO_WRITE - Prototyp
	LONG SIO_WRITE( HANDLE &locSioHandle,					//Handle des geoeffneten COM-Ports
		  					  LPVOID locTxBuf,							//Pointer auf Sendebuffer
  					      DWORD locTxBufLng );    		  //Sendebuffer-Laenge in Bytes


// Operations
public:

// Implementation
public:
	virtual ~CSIO();

	// Generated message map functions
protected:
};

/////////////////////////////////////////////////////////////////////////////
