//****************************************************************************//
//   Copyright:  1997  WePa - Entwicklungsabteilung                           //
//****************************************************************************//
//   Kennzeichnung:                                                           //
//       ID-Nr.       030209019677                                            //
//       System       Phone-Control                                           //
//       Sub-System   Phone-Control Operating System -POS                     //
//       Funktion     Aufbereitung der Daten die das POI vom User aufnimmt;   //
//			              inklusive Steuerung von modular hinzugefuegten Units    //
//                    Alarmverwaltung                                         //
//      					    graphische Darstellung der Information				          //
//       Filename     POS Dispatcher.cpp                                      //
//****************************************************************************//
//   History:                                                                 //
//   Version     Datum       Autor           Bemerkung                        //
//   00.01       20.11.97    W. Paulin       Erstellung                       //
//   00.02       10.07.98    W. Paulin       Implementierung: Text-Logger     //
//   00.03       18.07.98    W. Paulin       Anpassungen an WPBasics V1.01    //
//****************************************************************************//
// Beschreibung :                                                             //
//				  Hauptsteuerung des Dispatcher fuer das POS				                //
//****************************************************************************//

#include "stdafx.h" 
#include "POS Dispatcher.h"
#include "POS DispatcherDlg.h"
#include "memory.h"
#include "time.h"
#include "SIO.h"
#include "iostream.h"
#include "WPBasics.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

CPOSDispatcherApp theApp;	          	// The one and only CPOSDispatcherApp object
CSIO Sio;															//Objekt der CSIO-Klasse


//globale Definitionen
Job04Tgm_s WP2JobTgm;									//Job-Telegramm zu WP2000 - Treiber
Reply04Tgm_s WP2ReplyTgm;							//Reply-Telegramm von WP2000 - Treiber
ClientInfo_s WP2ClientInfo;	          //Client-Infostruktur
ClientThreadInfo_s ClientThreadInfo;  //Threadinfo-Struktur fuer Client
BYTE PortNr;													//verwendete Port-Nummer
HANDLE SioHandle;											//Handle des COM-Ports
BYTE RestartClient;										//Restart-Auftrag fuer Client
BYTE RestartWP2000;									  //Restart-Auftrag fuer WP2000-Treiber
WORD GDebOn;	  											//globaler DEBUG-Mode
HANDLE EvLogHandle;										//Handle des Event-Log - Files
CWPBasics WPBasics;									  //globales Objekt fuer Standartfunktionen
CString EvFileName;							  	  //Filename fuer Text-Log					

//Definition der Thread-Funktionen
UINT WP2000(LPVOID pWP2000);					//Prototyp der Thread-Funktion 
UINT WP2Client(LPVOID pWP2Client);    //Prototyp der Thread-Funktion 

/////////////////////////////////////////////////////////////////////////////
// CPOSDispatcherApp

BEGIN_MESSAGE_MAP(CPOSDispatcherApp, CWinApp)
	//{{AFX_MSG_MAP(CPOSDispatcherApp)
	//}}AFX_MSG_MAP
	ON_COMMAND(ID_HELP, CWinApp::OnHelp)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPOSDispatcherApp construction

CPOSDispatcherApp::CPOSDispatcherApp()
{
	m_pWP2000 = 0;					//Zeiger auf WP2000-Thread null setzen
	m_pWP2Client = 0;				//Zeiger auf WP2Client-Thread null setzen
}


/////////////////////////////////////////////////////////////////////////////
// CPOSDispatcherApp deconstruction

CPOSDispatcherApp::~CPOSDispatcherApp()
{
	delete m_pWP2000; 			//Zeiger-Objekt loeschen
  delete m_pWP2Client; 	  //Zeiger-Objekt loeschen
}


/////////////////////////////////////////////////////////////////////////////
// CPOSDispatcherApp initialization

BOOL CPOSDispatcherApp::InitInstance()
{
	if (!AfxSocketInit())
	{
		AfxMessageBox(IDP_SOCKETS_INIT_FAILED);
		return FALSE;
	}

#ifdef _AFXDLL
	Enable3dControls();			// Call this when using MFC in a shared DLL
#else
	Enable3dControlsStatic();	// Call this when linking to MFC statically
#endif

	CPOSDispatcherDlg dlg;
	m_pMainWnd = &dlg;
	int nResponse = dlg.DoModal();
  if (nResponse == IDCANCEL)
	  {
		 // TODO: Place code here to handle when the dialog is
		 // dismissed with Cancel  
	  }

	return FALSE;

}

int CPOSDispatcherApp::ExitInstance() 
{
  Sio.SIO_CLOSE(::SioHandle);
  //Text-Log:
  WPBasics.EvTxtLog( ::EvFileName, "Application-Class. Instance of POS Dispatcher terminated", 0, 0 );

	return CWinApp::ExitInstance();
}

BOOL CPOSDispatcherApp::InitApplication() 
{
 //vorlaeufige DEBUG - Werte:
 ::WP2ClientInfo.poi0Adr = 0x0A;	 //POI-Adressen (0x0A - 0x0F)
 ::WP2ClientInfo.ownAdr = 0x00;		 //POS-Adressen (0x00 - 0x09)
 ::WP2ClientInfo.valPIN = 1111;		 //gueltiger Zugangscode: 1111
 ::WP2ClientInfo.sndPUN = 2;		 	 //Pick-Up-Number: 1

 ::PortNr = 2;	//default COM-Port - Auswahl
 ::GDebOn = 101;	//Debug-Mode Auswahl:    >0...Debug-Mode aktiv
								  //										 >100...alle Textlogs aktiv	
								  //									 >=1000...RS232-Echo aktiv; Treiber inaktiv

/*
 neue WPBasics-Funktionenn (mit CCriticalSection-Verriegelung)
 GetIniEntyInt(Filename(ohne Pfad), Section, Keyword, Default value) => Rueckgabewert ist Eintrag
 SetIniEntryInt(Filename(ohne Pfad), Section, Keyword, setvalue) => itoa -  Wandlung noetig

 GetIniEntryString()
 SetIniEntryString()


 GetCurrentDirectory( 256, pathStr); 
 EvFileName = pathStr;	
 EvFileName += "\\POS_UTIL\\POS_DP.ini";
 
 
 GDebOn = GetPrivateProfileInt(
                      "GENERAL",	        // address of section name
                      "GDEBON",	          // address of key name
                      0,        	      // return value if key name is not found
                      EvFileName 	      // address of initialization filename
                     );
	if (::GDebOn == 100)
    AfxMessageBox( "GDebOn = 100 !!!", MB_OK | MB_ICONEXCLAMATION, 0 );
	else if (::GDebOn == 0)
    AfxMessageBox( "GDebOn = 0 !!!", MB_OK | MB_ICONEXCLAMATION, 0 );

  WritePrivateProfileString(
                      "GENERAL",	        // address of section name
                      "STRING",	          // address of key name
                      "Hallo Werner",        	      // return value if key name is not found
                      EvFileName 	      // address of initialization filename
   );	
 */


 //Text-Logger initialisieren
 GetCurrentDirectory( 256, pathStr); 
 EvFileName = pathStr;	
 EvFileName += "\\POS_UTIL\\POS_DP.log";

 WPBasics.EvTxtOpen( ::EvFileName );

 //Text-Log:
 WPBasics.EvTxtLog( ::EvFileName, "Application-Class. Create new instance of POS Dispatcher", 0, 0 );
 
 ///////////////////////////////////////////////////////////////////////////////	
 //Initialisierung des WP2000 - Treiber - Threads
 ::RestartWP2000 = 1;												//Initialisierung
	
 ::SioHandle = 0;

 m_pWP2000 = AfxBeginThread(								         //Thread f. WP2000-Treiber starten
              	  				  WP2000, 
														&Sio,										 //Objekt-Pointer uebergeben
			  				            THREAD_PRIORITY_NORMAL,
								            0,
						  	            CREATE_SUSPENDED
													 );
 m_pWP2000->m_bAutoDelete = FALSE;
 m_pWP2000->ResumeThread ();


 ///////////////////////////////////////////////////////////////////////////////	
 //Initialisierung des Clients fuer POI - Kommunikation (Thread) 

 //Info-Struktur vorbereiten
 ClientThreadInfo.pWP2ClientInfo = &WP2ClientInfo;
 ClientThreadInfo.pPOSDispApp = &theApp;
  
 CPOSDispatcherDlg theDlg;
 ClientThreadInfo.pPOSDispDlg = &theDlg;

 ::RestartClient = 1;												//Initialisierung

 m_pWP2Client = AfxBeginThread(								//Thread f. WP2000-Client starten
	 	 	  				               WP2Client, 
									             &ClientThreadInfo,	
			  					             THREAD_PRIORITY_NORMAL,
									             0,
						  		             CREATE_SUSPENDED
															);
 m_pWP2Client->m_bAutoDelete = FALSE;
 m_pWP2Client->ResumeThread ();
		
 return CWinApp::InitApplication();
}



UINT WP2000(LPVOID pWP2000)
//****************************************************************************//
//   Copyright:  1997  WePa - Enwicklung                                      //
//****************************************************************************//
//   Kennzeichnung:                                                           //
//       ID-Nr.    030209019677                                               //
//       System    Phone-Control                                              //
//       Subsystem WP2000 - Treiber                                                     //
//       Funktion  Treiber fuer das WP2000 Protokoll                          //
//                                                                            //
//       Methode   UINT WP200(LPVOID pWP2000)                                 //
//****************************************************************************//   
//   History                                                                  //                                          
//   Version     Datum       Autor           Beschreibung                     //
//   01.00       11.09.97    W. Paulin       Rumpfversion                     //
//   01.01       05.10.97    W. Paulin       Einbau des Treiber-Aufbaus       //
//   01.02       18.10.97    W. Paulin       Verz�gerung zw. RXD-/TXD-Telegr. //
//   01.03       19.01.98    W. Paulin       Korrekturen bei Empf. Timeouts   //
//   01.04       02.07.98    W. Paulin       Auftragsinterpreter: src- und    //
//																					 dest-Adr. lokal umkopiert        //	
//                                           mesJobNr: Auftragsquittung wird  //
//																					 nur einmal pro Job abgesetzt     //
//   01.05       03.07.98    W. Paulin       Retry-Zaehler bei val. CS loesch.//
//                                           Timeout-Handling bei Retries neu //
//                                           erstellt                         //
//                                           ME-Freigabe nur wenn EA inaktiv  //
//                                           und kein TX-Auftrag anstehend    //
//                                           TX-Auftraege autonom zum ME      //
//																					 destAdr-Zuweisung korr. (* / 16) //
//   01.06       06.07.98    W. Paulin       EA aktiv -> Timeout wegen moegl. //
//																					 Deadlock nach RTR zu verhindern  //
//   01.07       09.07.98    W. Paulin       Restart-Eigenschaft implementiert//
//   01.08       10.07.98    W. Paulin       Implementierung: Text-Logger     //
//   01.09       11.07.98    W. Paulin       Fehler-Msg-Box Style geaendert   //
//****************************************************************************//
// Beschreibung :                                                             // 
//               Kommunikation zum POI und Datenaufbereitung fuer die ueber-  //
//	             geornete Applikation                                         //
//****************************************************************************//
//Schnittstellen des WP2000-Treibers zur uebergeordneten Applikation:         //
//uebergebener Pointer: pWP2000																								//
//Struktur:																																		//	
//				         Job04Tgm								  ...Auftrags-Telegramm							//
//                         .hdr.tgmLen      ...Telegramm-Laenge								//							
//                         .hdr.jobNr       ...fortlaufende Job-Nummer				//
//                         .hdr.dstAdr      ...Zieladresse										//
//                         .hdr.srcAdr      ...Quellenadresse									//
//					               .jobId           ...Id des Jobs (Aufgabe)					//
//					  						 .status          ...Status /Kommando (bitkod.)			//
//					               .data            ...zu Uebermittlende Daten				//
//																																						//	
//		           Reply04Tgm                 ...Antwort-Telegramm							//	
//					               .hdr.tgmLen      ...Telegramm-Laenge								//	
//									       .hdr.jobNr       ...fortlaufende Job-Nummer				//	
//								         .hdr.dstAdr      ...Zieladresse										//
//								         .hdr.srcAdr      ...Quellenadresse									//	
//								         .jobId           ...Id des Jobs (Aufgabe)					//
//								         .status          ...Status der Gegenstat. (bitkod.)//
//								         .data            ...Uebermittlete Daten						//
//****************************************************************************//
//Job-IDs /Auftraege:                                                         //
//                 10...PIN-Quittung                                          //
//                 20...PIN-Anfrage ist zu verifizieren                       //
//                                                                            //
//                 11...PUN-Daten-Transfer                                    //
//                 21...PUN-Anfrage                                           //
//																																						//	
//                 12...Status-Daten-Transfer                                 //
//                 22...Status-Anfrage                                        //
//****************************************************************************//
// Job-IDs /Quittungen:                                                       //
//                  0...job faultless done                                    //
//                 -1...no connection                                         //
//                 -2...destination not ready                                 //
//                 -3...retries failed                                        //
//                 -4...invalid sign received                                 //
//                 -5...unexepected receive                                   //
//                 -6...unexpected sign                                       //
//                 -7...communication canceled                                //
//                 -8...retry requested                                       //
//                 -9...unknown ID received                                   //
//****************************************************************************//
{
 //#include "time.h"

 CSIO *pSIO = (CSIO*) pWP2000;            //explizites type casting
 
 ///////////////////////////////////////////////////////////////////////////////
 // Variablen-Deklaration /Beginn
 MesList_s mesList;												//lokale Message Executor-Liste

 //Protokoll-Konstanten
 //Handshake
 const BYTE RTR   = 0x05;												//Request To Receive
 const BYTE ACK   = 0x06;												//ACKnowledge
 const BYTE NACK  = 0x15;												//Not ACKnowledge
 const BYTE RETCO = 0x20;												//RETry COmmunication
 
 //Runtime Checks
 const double replyTO = 1;  			  		//Timeout fuer Antwort-Empfang in !s!
 const BYTE retryMax = 3;						  	//Retry-Anzahl nach korrupter Checksumme

 //ID fuer Kommunikation
 const BYTE ID_PIN_A = 0xA0;										//ID f. PIN - Anfrage
 const BYTE ID_PIN_D = 0xD0;										//ID f. PIN - Daten (Information)
 
 const BYTE ID_PUN_A = 0xA1;										//ID f. PUN - Anfrage
 const BYTE ID_PUN_D = 0xD1;										//ID f. PUN - Daten 
 
 const BYTE ID_STS_A = 0xA2;										//ID f. STS - Anfrage
 const BYTE ID_STS_D = 0xD2;										//ID f. STS - Daten 

 CString tempStatus;														//Objekt zur Stringbildung
 CString tempPortNr;														//Objekt zur Stringbildung
 CString strComPort;														//COM-Port in String-Darstellung
 CString strReadSts;														//Read-Status in String-Darstellung
 CString strWriteSts;														//Write-Status in String-Darstellung
 char rxBuffer[8];															//Empfangsbuffer
 BYTE rxData[8];																//Empfangsbuffer der EA
 SioMode_s sioMode;
 BYTE rxMesBuf[8];															//lokaler Empfangsbuffer

 //Zaehler ruecksetzen
 unsigned long cntRXD;											//ein Zeichen empfangen
 unsigned long cntTXD;											//ein Zeichen gesendet
 unsigned long cntACK;											//allgemein ACK empfangen 
 unsigned long cntNACK;											//allgemein NACK empfangen 
 unsigned long cntRTR;											//allgemein RTR empfangen 
 unsigned long cntRETCO;										//RETCO empfangen
 unsigned long txRetries;										//Sende-Retrys
 unsigned long oldCntRXD;										//letzter Stand beim Zeichen-Empfang	
 unsigned long lastJobNr;										//letzte Job-Nummer
 unsigned long cntMe_ACK;										//ACK f. Message-Executor empfangen
 unsigned long cntMe_NACK;									//NACK f. Message-Executor empfangen
 unsigned long cntMe_RCO;				   					//RETCO f. Message-Executor empfangen
 unsigned long cntMe_USR;				   					//unerwartets Zeichen f. ME empfangen

 //sonstige Variablen
 BYTE frameAdr;															//lokale Frame-Adresse
 BYTE txMesBuf;															//lokaler Sendebuffer
 BYTE sendBuffer;														//Sende - Trigger
 BYTE waitRTR;															//Message-Executor: RTR-Echo ?
 BYTE meWaiting;														//Message-Executor: wartet auf Antwort 
 WORD sWP2_TxHs;									          //TX - State-Machine
 WORD sWP2_RxHs;									          //RX - State-Machine
 WORD lng_Check;														//Laenge f. Checksummen-Berechnung
 BYTE checkSum;															//Wert der Checksumme
 WORD csIdx;																//Index fuer Checksummen-Bildung
 BYTE txdIdx;																//Index der Message-Liste beim Senden
 BYTE replyChar;														//empfangenes Zeichen
 BYTE meTxACK;															//Nachricht an ME: ACK senden
 BYTE meTxNACK;															//Nachricht an ME: NACK senden
 BYTE meTxRETCO;														//Nachricht an ME: RETCO senden
 BYTE	waitTXD;															//Empf. auswertung wartet auf TXD
 BYTE	meReceive;														//empf. Zeichen ist f. ME
 BYTE	valFrame;															//korrekter Frame empfangen
 BYTE csACK;																//ACK fuer Checksumme gesendet
 BYTE	eaReceive;														//empf. Zeichen ist f. EA
 unsigned long rxRetries;										//Anz. der Retries
 unsigned long oldRetVal;										//alte Anz. der Retries
 BYTE rxFrameAdr;														//Zwischenspeicher der Frameadresse
 unsigned char dstAdr;	  									//lokale Zieladresse
 unsigned char srcAdr;											//lokale Quelladresse
 unsigned long mesJobNr;										//Jobnummer fuer Auftragsquittung
 char txBuffer;															//Sendebuffer

 //Timer-Variablen
 clock_t startTimeRep;											//Startzeit des Reply-Timers
 clock_t aktTimeRep;												//aktuelle Zeit des Reply-Timers
 double replyTimer;													//Timer: auf Antwort warten
 
 clock_t eaStartTimeRep;										//Startzeit des Reply-Timers /EA
 clock_t eaAktTimeRep;											//aktuelle Zeit des Reply-Timers /EA
 double eaReplyTimer;												//Timer: auf Antwort warten

 LPVOID pTxBuffer;
 LPVOID pRxBuffer;

 LONG openStatus;											  //Status beim Oeffnen des Ports
 LONG writeStatus;											//Status beim Schreiben auf den Port
 LONG readStatus;											  //Status beim Lesen von dem Port

 ///////////////////////////////////////////////////////////////////////////////
 // Variablen-Deklaration /Ende

  
while (TRUE)
{
 if (::RestartWP2000)												 //Neustart des Threads
	 {
		::RestartWP2000 = 0;

    //Text-Log:
    if (GDebOn >= 20)
      WPBasics.EvTxtLog( ::EvFileName, "WP2000. Restart WP2000() thread", 0, 0 );

    //Zaehler ruecksetzen
		cntRXD = 0;											//ein Zeichen empfangen
    cntTXD = 0;											//ein Zeichen gesendet
	  cntACK = 0;											//allgemein ACK empfangen 
		cntNACK = 0;											//allgemein NACK empfangen 
    cntRTR = 0;											//allgemein RTR empfangen 
    cntRETCO = 0;										//RETCO empfangen
    txRetries = 0;										//Sende-Retrys
    oldCntRXD = 0;										//letzter Stand beim Zeichen-Empfang	
    lastJobNr = 0;										//letzte Job-Nummer
    cntMe_ACK = 0;										//ACK f. Message-Executor empfangen
    cntMe_NACK = 0;									//NACK f. Message-Executor empfangen
    cntMe_RCO = 0;				   					//RETCO f. Message-Executor empfangen
    cntMe_USR = 0;				   					//unerwartets Zeichen f. ME empfangen

    //sonstige Variablen
		frameAdr = 0;															//lokale Frame-Adresse
	  txMesBuf = 0;															//lokaler Sendebuffer
	  sendBuffer = 0;														//Sende - Trigger
	  waitRTR = 0;															//Message-Executor: RTR-Echo ?
	  meWaiting = 0;														//Message-Executor: wartet auf Antwort 
	  sWP2_TxHs = 10;									          //TX - State-Machine
	  sWP2_RxHs = 10;									          //RX - State-Machine
	  lng_Check = 0;														//Laenge f. Checksummen-Berechnung
	  checkSum = 0;															//Wert der Checksumme
	  csIdx = 0;																//Index fuer Checksummen-Bildung
	  txdIdx = 0;																//Index der Message-Liste beim Senden
	  replyChar = 0;														//empfangenes Zeichen
	  meTxACK = 0;															//Nachricht an ME: ACK senden
	  meTxNACK = 0;															//Nachricht an ME: NACK senden
	  meTxRETCO = 0;														//Nachricht an ME: RETCO senden
	 	waitTXD = 0;															//Empf. auswertung wartet auf TXD
	 	meReceive = 0;														//empf. Zeichen ist f. ME
	 	valFrame = 0;															//korrekter Frame empfangen
	  csACK = 0;																//ACK fuer Checksumme gesendet
	 	eaReceive = 0;														//empf. Zeichen ist f. EA
		rxRetries = 0;										//Anz. der Retries
		oldRetVal = 0;										//alte Anz. der Retries
		rxFrameAdr = 0;														//Zwischenspeicher der Frameadresse
		dstAdr = 0;	  									//lokale Zieladresse
		srcAdr = 0;											//lokale Quelladresse
		mesJobNr = 0;										//Jobnummer fuer Auftragsquittung
		txBuffer = 0;															//Sendebuffer

	  //Timer-Variablen
		startTimeRep = 0;											//Startzeit des Reply-Timers
		aktTimeRep = 0;												//aktuelle Zeit des Reply-Timers
		replyTimer = 0;													//Timer: auf Antwort warten
 
	  eaStartTimeRep = 0;										//Startzeit des Reply-Timers /EA
	  eaAktTimeRep = 0;											//aktuelle Zeit des Reply-Timers /EA
	  eaReplyTimer = 0;													//Timer: auf Antwort warten

	  memset( &WP2JobTgm, 0, sizeof(WP2JobTgm) );	  //Job-Telegramm loeschen
		memset( &WP2ReplyTgm, 0, sizeof(WP2ReplyTgm) );//Reply-Telegramm loeschen
 	  memset( &mesList, 0, sizeof(mesList) );	      //Liste loeschen
		memset( &rxMesBuf, 0, sizeof(rxMesBuf) );      //Rx-Message Buffer loeschen
		memset( &rxData, 0, sizeof(rxData) );          //Rx-Daten Buffer loeschen
		memset( &rxBuffer, 0, sizeof(rxBuffer) );      //Empfangsbuffer loeschen

		pTxBuffer = &txBuffer;
		pRxBuffer = &rxBuffer;

		openStatus = 0;											  //Status beim Oeffnen des Ports
		writeStatus = 0;											//Status beim Schreiben auf den Port
		readStatus = 0;											  //Status beim Lesen von dem Port
  
	  sioMode.baudrate = CBR_19200;							 //19200 Baud
		sioMode.parity = NOPARITY;									 //kein Parity-Bit
		sioMode.ctsControl = FALSE;								 //kein CTS-Handshake
		sioMode.dsrControl = FALSE;								 //kein DSR-Handshake
		sioMode.dtrControl = DTR_CONTROL_DISABLE;	 //kein DTR-Handshake
		sioMode.rtsControl = RTS_CONTROL_DISABLE;	 //kein RTS-Handshake
		sioMode.nbDataBytes = 8;										 //8 Datenbytes pro Frame
		sioMode.stopBits = ONESTOPBIT;							 //1 Stopbit
	  
		if (::SioHandle != 0)											 //ein COM-Port wurde bereits geoeffnet
			pSIO->SIO_CLOSE(::SioHandle); 					 //COM-Port schliessen		  

    //Com-Port initialisieren
    openStatus = pSIO->SIO_OPEN( PortNr,				 //dezimale Port-Nummer
								              8,						 //Empfangsbuffer-Laenge in Bytes
								              1,						 //Sendebuffer-Laenge in Bytes
								              sioMode,			 //Modus der seriellen Verbindung
															::SioHandle );   //Handle des geoeffneten COM-Ports

    if (openStatus != 0)
      {
	     //ASCII-Wandlung der Port-Nummer fuer Fehleranzeige
	     strComPort = "   Error open COM-Port #";		
       tempPortNr = (PortNr / 10) % 10 + '0';	//Integer -> ASCII - Wandlung
       if (tempPortNr != '0')									//kein fuehrenden Nuller			
         strComPort += tempPortNr;
  
       tempPortNr = (PortNr /  1) % 10 + '0';	//Integer -> ASCII - Wandlung
       strComPort += tempPortNr;

	     strComPort += "\r\n        Error Status #";		
  		 tempPortNr = (openStatus / 100) % 10 + '0';	//Integer -> ASCII - Wandlung
       strComPort += tempPortNr;
 
       tempPortNr = (openStatus /  10) % 10 + '0';	//Integer -> ASCII - Wandlung
       strComPort += tempPortNr;
 
       tempPortNr = (openStatus /   1) % 10 + '0';	//Integer -> ASCII - Wandlung
       strComPort += tempPortNr;

			 strComPort += "\r\nPlease choose another Port!";
       AfxMessageBox( strComPort, MB_SYSTEMMODAL | MB_OK | MB_ICONSTOP, 0 );

       //Text-Log:
       if (GDebOn >= 20)
         WPBasics.EvTxtLog( ::EvFileName, "WP2000. Error open COM-Port  COM-Port / Status", LONG(PortNr), openStatus );
			}
  }

//################# DEBUG ##########################
//serielles Echo ueber via RS232
if ( (openStatus == 0) && (::GDebOn >= 1000 ) )  //Endlos-Schleife wenn COM-Port Ok
{
 readStatus = pSIO->SIO_READ( ::SioHandle,				  //Handle des geoeffneten COM-Ports
		  					              pRxBuffer,						//Pointer auf Empfangsbuffer
  					                  sizeof(rxBuffer) );	  //Empfangsbuffer-Laenge in Bytes

 
 //Status-Auswertung
 strReadSts = "Read-Status = ";		

 tempStatus = (readStatus / 10) % 10 + '0';						//Integer -> ASCII - Wandlung
 strReadSts += tempStatus;

 tempStatus = (readStatus /  1) % 10 + '0';						//Integer -> ASCII - Wandlung
 strReadSts += tempStatus;

 if (readStatus > 2)
   AfxMessageBox( strReadSts, MB_OK | MB_ICONEXCLAMATION, 0 );

 if (readStatus == 0)
   {
    memcpy( pTxBuffer, pRxBuffer, sizeof(txMesBuf) );

    writeStatus = pSIO->SIO_WRITE( ::SioHandle,		     //Handle des geoeffneten COM-Ports
     													     pTxBuffer,				 //Pointer auf Sendebuffer
  	  													   sizeof(txBuffer) );//Sendebuffer-Laenge in Bytes

    strWriteSts = "Write-Status = ";		

    tempStatus = (writeStatus / 10) % 10 + '0';						//Integer -> ASCII - Wandlung
    strWriteSts += tempStatus;

    tempStatus = (writeStatus /  1) % 10 + '0';						//Integer -> ASCII - Wandlung
    strWriteSts += tempStatus;

    if (writeStatus > 0)
      AfxMessageBox( strWriteSts, MB_OK | MB_ICONEXCLAMATION, 0 );
	 }
}
//################# DEBUG ##########################

if ( (openStatus == 0) && (::GDebOn < 1000) )	 //Endlos-Schleife wenn COM-Port Ok
 {
  //--------------------------------------------------------------------------//  
	// Auftragsinterpreter																											//
  //--------------------------------------------------------------------------//  
  //if ( (WP2JobTgm.hdr.jobNr != lastJobNr) && (mesList.mesStatus <= 0) && (WP2JobTgm.jobId > 0) )
  if ( (WP2JobTgm.hdr.jobNr != lastJobNr) && (mesList.mesStatus <= 0) )
		{
		 lastJobNr = WP2JobTgm.hdr.jobNr;						//neuer Auftrag ist eingegangen
     
		 memset( &mesList, 0, sizeof(mesList) );	  //Liste loeschen
		 mesList.mesId = 10;												//Liste kommt vom Auftragsinterpreter
		 
		 //Frameadresse zusammenstellen
//		 WP2JobTgm.hdr.dstAdr = WP2JobTgm.hdr.dstAdr & 0x0F; //High-Nibble ausmaskieren
//		 WP2JobTgm.hdr.srcAdr = WP2JobTgm.hdr.srcAdr & 0x0F; //High-Nibble ausmaskieren
//		 frameAdr = WP2JobTgm.hdr.dstAdr * 16;   //Dest. Adr. ins High-Nibble schieben
//     frameAdr = frameAdr | WP2JobTgm.hdr.srcAdr;

		 dstAdr = WP2JobTgm.hdr.dstAdr & 0x0F; //High-Nibble ausmaskieren
		 srcAdr = WP2JobTgm.hdr.srcAdr & 0x0F; //High-Nibble ausmaskieren

		 frameAdr = dstAdr * 16;   //Dest. Adr. ins High-Nibble schieben
     frameAdr = frameAdr | srcAdr;

		 //eintragen in die Message-Liste
		 memcpy( &mesList.mesData[1], &frameAdr, sizeof(mesList.mesData[1]) );
		 memcpy( &mesList.mesData[2], &WP2JobTgm.status, sizeof(mesList.mesData[2]) );
		 memcpy( &mesList.mesData[3], &WP2JobTgm.data, sizeof(mesList.mesData)-4 );

		 switch (WP2JobTgm.jobId)
			{
		   case 10: 
    		 memcpy( &mesList.mesData[0], &ID_PIN_D, sizeof(mesList.mesData[0]) );
				 mesList.mesStatus = 1;						//Messageliste abarbeiten
			 break;

			 case 20: 
    		 memcpy( &mesList.mesData[0], &ID_PIN_A, sizeof(mesList.mesData[0]) );
				 mesList.mesStatus = 1;						//Messageliste abarbeiten
			 break;

			 case 11: 
    		 memcpy( &mesList.mesData[0], &ID_PUN_D, sizeof(mesList.mesData[0]) );
				 mesList.mesStatus = 1;						//Messageliste abarbeiten
			 break;

 			 case 21: 
    		 memcpy( &mesList.mesData[0], &ID_PUN_A, sizeof(mesList.mesData[0]) );
				 mesList.mesStatus = 1;						//Messageliste abarbeiten
			 break;

 			 case 12: 
    		 memcpy( &mesList.mesData[0], &ID_STS_D, sizeof(mesList.mesData[0]) );
				 mesList.mesStatus = 1;						//Messageliste abarbeiten
			 break;

 			 case 22: 
    		 memcpy( &mesList.mesData[0], &ID_STS_A, sizeof(mesList.mesData[0]) );
				 mesList.mesStatus = 1;						//Messageliste abarbeiten
     	 break;

			 default:
				 WP2JobTgm.jobId = -9;  				 //ungueltige Id erhalten
			 break;	
		  } 	  //switch (WP2JobTgm.jobId)
		}		//( (WP2JobTgm.hdr.jobNr != lastJobNr) && (mesList.mesStatus <= 0) && (WP2JobTgm.jobId > 0) )

	else if ( (mesList.mesStatus <= 0) && (WP2JobTgm.hdr.jobNr != mesJobNr) )
		{
     mesJobNr = WP2JobTgm.hdr.jobNr;				//alte Jobnummer merken
		 WP2JobTgm.jobId = mesList.mesStatus;		//Auftragsquittung	
		}


  //--------------------------------------------------------------------------//  
	// Message-Executor   																											//
  //--------------------------------------------------------------------------//
  if ( (mesList.mesStatus == 1) && (eaReceive == 0) && (meTxACK == 0) && (meTxNACK == 0) && (meTxRETCO == 0) )	//neue Message-Liste abarbeiten ?
		{
		 switch (sWP2_TxHs)
		 {
		  case 10:													//RTR - Anfrage einleiten
				memcpy( &txMesBuf, &RTR, sizeof(txMesBuf) );
				sendBuffer = 1;									//senden einleiten
				waitRTR = 1;										//Message-Executor wartet auf RTR-Antwort
				meWaiting = 1;									//Message-Executor wartet allg. auf Antwort
				replyTimer = 0;									//Timeout-Zaehler ruecksetzen
	      startTimeRep = clock();  		    //Timer auf akt. Prozessor-Timer-Ticks setzen

				sWP2_TxHs = 40;									//naechster State: auf Antwort warten
		  break;	

			case 20:													//TXD-Initialisierungen
				//...Checksumme berechnen
				lng_Check = sizeof(mesList.mesData) - 1; //Laenge fuer Checksummen-Berechnung
				checkSum = 0;														 //Checksummen-Wert loeschen

			  //Startwert; Bedingung die vor Durchlauf erfuellt sein muss; Zaehler
				for (csIdx = 0; csIdx <= lng_Check - 1; csIdx++) 
				  {
				   checkSum = checkSum + mesList.mesData[csIdx];		//Feld durchscannen
				  }
				
				//...Checksumme umkopieren
				memcpy( &mesList.mesData[7], &checkSum, sizeof(mesList.mesData[7]) );
				txdIdx = 0;																//Index 0 der Message-Liste waehlen

				sWP2_TxHs = 30;									//naechster State: Message-Liste senden									
			break;

			case 30:													//Message-Liste senden
				memcpy( &txMesBuf, &mesList.mesData[txdIdx], sizeof(txMesBuf) );
				sendBuffer = 1;									//Senden einleiten
				txdIdx++;												//auf naechstes Element pointen
				
				if (txdIdx >= 8)
					{
					 waitTXD = 1;									//TXD-State fordert ein Warten auf Antwort an
					 meWaiting = 1;								//Message-Executor wartet auf Antwort
			     startTimeRep = clock();  		//Timer auf akt. Prozessor-Timer-Ticks setzen
			
					 sWP2_TxHs = 40;							//naechster State: auf Antwort warten
					}
			break;

			case 40:													//auf Antwort warten
				if (meReceive == 1)
					{
					 meReceive = 0;								//Empfang zur Kenntnis genommen
					 sWP2_TxHs = 50;							//naechster State: Auswertung
           replyTimer = 0;              //Timeout-Zaehler zuruecksetzen
					}
			  else
				  {
				   aktTimeRep = clock();						//aktuelle Zeit ermitteln
			     replyTimer = (double)(aktTimeRep - startTimeRep) / CLOCKS_PER_SEC;
          }
				
				if (replyTimer >= replyTO)
					{
					 //...Job-Quittung vorbereiten
					 mesList.mesStatus = -1;			//keine Antwort von Gegenstation
      		 sWP2_TxHs = 10;							//naechster State: RTR - Anfrage einleiten
					}
			break;

			case 50:													//Auswertung
				//------------------ Auswertung fuer RTR - Anfrage /Beginn ------------------
				if ( (replyChar == ACK) && (waitRTR == 1) )
					{
					 cntMe_ACK++;									//Statistik: ACK wurde empfangen
					 waitRTR = 0;									
				
					 sWP2_TxHs = 20;							//naechster State: TXD-Initialisierungen
					}
				
				if ( (replyChar == NACK) && (waitRTR == 1) )
					{
					 cntMe_NACK++;								//Statistik: NACK wurde empfangen
					 waitRTR = 0;									
					 //...Job-Quittung vorbereiten
					 mesList.mesStatus = -2	;			//Gegenstation nicht bereit
					 
					 sWP2_TxHs = 10;							//naechster State: RTR - Anfrage einleiten
					}

				if ( (replyChar != ACK) && (replyChar != NACK) && (waitRTR == 1) )
					{
					 cntMe_USR++;						  		//Statistik: NACK wurde empfangen
					 waitRTR = 0;									
					 //...Job-Quittung vorbereiten
					 mesList.mesStatus = -6;			//unerwartetes Zeichen wurde empfangen
					 
					 sWP2_TxHs = 10;							//naechster State: RTR - Anfrage einleiten
					}
				//------------------- Auswertung fuer RTR - Anfrage /Ende -------------------


				//------------- Auswertung fuer Checksummen - Quittung /Beginn --------------
				if ( (replyChar == ACK) && (waitTXD == 1) )
					{
					 cntMe_ACK++;									//Statistik: ACK wurde empfamgen
					 waitTXD = 0;
					 //...Job-Quittung vorbereiten
					 mesList.mesStatus = 0;				//Message-Liste fehlerfrei abgearbeitet

					 sWP2_TxHs = 10;							//naechster State: RTR - Anfrage einleiten
					}

				if ( (replyChar == NACK) && (waitTXD == 1) )
					{
					 cntMe_NACK++;									//Statistik: NACK wurde empfamgen
					 waitTXD = 0;
					 //...Job-Quittung vorbereiten
					 mesList.mesStatus = -7;				//Kommunikation abgebrochen

					 sWP2_TxHs = 10;							//naechster State: RTR - Anfrage einleiten
					}

				if ( (replyChar == RETCO) && (waitTXD == 1) )
					{
					 cntMe_RCO++;									//Statistik: RETCO wurde empfamgen
					 waitTXD = 0;
					 //...Job-Quittung vorbereiten
					 mesList.mesStatus = -8;			//Retry-Anforderung gestellt
					 txRetries++;									//Anzahl der Retries wird erhoeht

					 if (txRetries >= retryMax)
						{
						 txRetries = 0;
  					 //...Job-Quittung vorbereiten
	  				 mesList.mesStatus = -3;			//Retries erfolglos
						}

					 sWP2_TxHs = 10;							//naechster State: RTR - Anfrage einleiten
					}

				if ( (replyChar != ACK) && (replyChar != NACK) && (replyChar != RETCO) && (waitTXD == 1) )
					{
					 cntMe_USR++; 									//Statistik: unerwartetes Zeichen wurde empfamgen
					 waitTXD = 0;
					 //...Job-Quittung vorbereiten
					 mesList.mesStatus = -6;				//unerwartetes Zeichen wurde empfangen

					 sWP2_TxHs = 10;							//naechster State: RTR - Anfrage einleiten
					}
				//-------------- Auswertung fuer Checksummen - Quittung /Ende ---------------
			break;
			default:
      	AfxMessageBox( "Wrong State: sWP2_TxHs", MB_OK | MB_ICONEXCLAMATION, 0 );

		 }		//switch (sWP2_TxHs)
	}		//if (mesList.mesStatus == 1)
	//...Schnittstelle zur Empfangsauswertung
	//...damit diese Handshakesignale absetzen kann
	//else if ( (mesList.mesStatus <= 0) && (meTxACK == 1) )
	else if (meTxACK == 1)
		{
		 memcpy( &txMesBuf, &ACK, sizeof(txMesBuf) );
		 meTxACK = 0;
		 sendBuffer = 1;										//Sendevorgang ausloesen
		 if ( valFrame == 1)
		 	 csACK = 1;												//CS-Bestaetigung	gesendet
		}

	//else if ( (mesList.mesStatus <= 0) && (meTxNACK == 1) )
	else if (meTxNACK == 1)
		{
		 memcpy( &txMesBuf, &NACK, sizeof(txMesBuf) );
		 meTxNACK = 0;
		 sendBuffer = 1;										//Sendevorgang ausloesen
		}

	//else if ( (mesList.mesStatus <= 0) && (meTxRETCO == 1) )
	else if (meTxRETCO == 1)
		{
		 memcpy( &txMesBuf, &RETCO, sizeof(txMesBuf) );
		 meTxRETCO = 0;
		 sendBuffer = 1;										//Sendevorgang ausloesen
		}

  //--------------------------------------------------------------------------//  
	// Frame senden         																										//
  //--------------------------------------------------------------------------//
	if (sendBuffer == 1)	
		{
		 memcpy( &txBuffer, &txMesBuf, sizeof(txMesBuf) );

	   writeStatus = pSIO->SIO_WRITE( ::SioHandle,	     //Handle des geoeffneten COM-Ports
	 															    pTxBuffer,				 //Pointer auf Sendebuffer
  															    sizeof(txBuffer) );//Sendebuffer-Laenge in Bytes

		 if (writeStatus == 0)
		   {
        WPBasics.EvTxtLog( ::EvFileName, "WP2000. Senden =>", LONG(txBuffer), 0 );
				sendBuffer = FALSE;
				cntTXD++;
			 }
		 else
		   {
        //----- Status-Auswertung fuer DEBUG-Zwecke /Beginn -----//
				if (GDebOn >= 100)
					{
	   			 strWriteSts = "Write-Status = ";		

					 tempStatus = (writeStatus / 10) % 10 + '0';						//Integer -> ASCII - Wandlung
					 if (tempStatus != '0')									//kein fuehrenden Nuller			
						 strWriteSts += tempStatus;

	         tempStatus = (writeStatus /  1) % 10 + '0';						//Integer -> ASCII - Wandlung
	         strWriteSts += tempStatus;

	         AfxMessageBox( strWriteSts, MB_OK | MB_ICONEXCLAMATION, 0 );
				  }
	      //------ Status-Auswertung fuer DEBUG-Zwecke /Ende ------//

       //Text-Log:
       if (GDebOn >= 10)
         WPBasics.EvTxtLog( ::EvFileName, "WP2000. Error writing COM-Port => Status", writeStatus, 0 );
			}

   	} 


  //--------------------------------------------------------------------------//  
	// Frame empfangen       																										//
  //--------------------------------------------------------------------------//
  readStatus = pSIO->SIO_READ( ::SioHandle,				  //Handle des geoeffneten COM-Ports
		  					               pRxBuffer,						//Pointer auf Empfangsbuffer
  					                   sizeof(rxBuffer) );	//Empfangsbuffer-Laenge in Bytes

	if (readStatus == 0)
		{
     WPBasics.EvTxtLog( ::EvFileName, "WP2000. Empfang =>", LONG(rxBuffer[0]), LONG(rxBuffer[1]) );
     WPBasics.EvTxtLog( ::EvFileName, "WP2000. Empfang =>", LONG(rxBuffer[2]), LONG(rxBuffer[3]) );
     WPBasics.EvTxtLog( ::EvFileName, "WP2000. Empfang =>", LONG(rxBuffer[4]), LONG(rxBuffer[5]) );
     WPBasics.EvTxtLog( ::EvFileName, "WP2000. Empfang =>", LONG(rxBuffer[6]), LONG(rxBuffer[7]) );
		 
		 memset( &rxMesBuf, 0, sizeof(rxMesBuf) );
		 memcpy( &rxMesBuf, pRxBuffer, sizeof(rxMesBuf) );
		 cntRXD++;
		}
	else if (readStatus > 2)
	  {
     //----- Status-Auswertung fuer DEBUG-Zwecke /Beginn -----//
		 if (GDebOn >= 100)
		   {
	 		  strReadSts = "Read-Status = ";		

	      tempStatus = (readStatus / 10) % 10 + '0'; //Integer -> ASCII - Wandlung
	      if (tempStatus != '0')									   //kein fuehrenden Nuller			
	        strReadSts += tempStatus;

	      tempStatus = (readStatus /  1) % 10 + '0'; //Integer -> ASCII - Wandlung
	      strReadSts += tempStatus;

        AfxMessageBox( strReadSts, MB_OK | MB_ICONEXCLAMATION, 0 );
			 }

     //Text-Log:
     if (GDebOn >= 10)
       WPBasics.EvTxtLog( ::EvFileName, "WP2000. Error reading COM-Port => Status", readStatus, 0 );

     //------ Status-Auswertung fuer DEBUG-Zwecke /Ende ------//
	  }


  //--------------------------------------------------------------------------//  
	// Empfangsauswertung       																								//
  //--------------------------------------------------------------------------//
  if (oldCntRXD != cntRXD)									
		{
		 oldCntRXD = cntRXD;

		 if ( (meWaiting == TRUE) && (eaReceive == FALSE) )//wird nicht gerade empfangen ?
			 {
				meWaiting = FALSE;
				if (rxMesBuf[0] == ACK)												//Statistik
					 cntACK++;
	      else if (rxMesBuf[0] == NACK)
					 cntNACK++;
				else if (rxMesBuf[0] == RTR)
  				 cntRTR++;
				else if (rxMesBuf[0] == RETCO)
					 cntRETCO++;
        
				memcpy( &replyChar, &rxMesBuf[0], sizeof(replyChar) );
        meReceive = 1;										//Empfang fuer Messageexecutor
		   }  //if ( (meWaiting == TRUE) && (eaReceive == FALSE)
		 
		 else if (meWaiting == FALSE)	      //Zeichen ist	fuer Empfangsauswertung
		 	 {
				switch (sWP2_RxHs)
					{
					 case 10:
					   if (rxMesBuf[0] == RTR)		//wurde ein RTR empfangen ?
							 {
							  meTxACK = TRUE;					//an ME: sende ACK !
								eaReceive = TRUE;
         	      eaStartTimeRep = clock(); //Startwert fuer Timeout uebernehmen
								sWP2_RxHs = 20;
 							 }
				   break;

					 case 20:
					   memcpy( &rxData, &rxMesBuf, sizeof(rxMesBuf) );

						 //...Checksumme berechnen
						 lng_Check = sizeof(rxData) - 1;		//Laengenberechnung fuer CS-Bild
						 checkSum = 0;
			  		 
						 //Startwert; Bedingung die vor Durchlauf erfuellt sein muss; Zaehler
						 for (csIdx = 0; csIdx <= lng_Check - 1; csIdx++) 
						   {
						    checkSum = checkSum + rxData[csIdx];		//Feld durchscannen
							 } 

							//...Checksumme kontrollieren
							if (checkSum == rxData[7])	  				//Checksumme korrekt
								{
								 valFrame = TRUE;										//gueltiger Frame
								 meTxACK = TRUE;										//an ME: sende ACK !
								 csACK = FALSE;
								 rxRetries = 0;										  //ev. vorhandene Retries loeschen
								}
							else
								{
								 valFrame = FALSE;
								 
								 rxRetries++;
								 if (rxRetries > retryMax)						//Retries abgelaufen
									 {
									  meTxNACK = TRUE;									//an ME: sende ACK !
										
										rxRetries = 0;										//Retries wieder loeschen
										//...Reply-Id vorbereiten
										WP2ReplyTgm.jobId = -3;
									 }
								 else
	 								 meTxRETCO = TRUE;									//an ME: sende RETCO !
								}
              if (valFrame == FALSE)
								sWP2_RxHs = 10;

							if (valFrame == TRUE)							//Empfang abgeschlossen
								{
								 eaReceive = FALSE;
								 sWP2_RxHs = 10;
								}

				   break;

			     default:
      			 AfxMessageBox( "Wrong State: sWP2_RxHs", MB_OK | MB_ICONEXCLAMATION, 0 );
					}
		 	 } //else if (meWaiting == FALSE)		
		}	//if (oldCntRXD != cntDXD)

  //wenn Empfangsauswertung aktiv --> Timeout aktivieren um Treiber nicht zu blockieren
  //else if ( (eaReceive == TRUE) && (rxRetries > 0) )
  else if (eaReceive == TRUE) 
		{
     if (rxRetries != oldRetVal)      //bei neuem Retry -> Zaehler r�cksetzen
       {
        oldRetVal = rxRetries;        //neuen Wert uebernehmen
	      eaStartTimeRep = clock();  		  //neuen Startwert uebernehmen
			 }

	   eaAktTimeRep = clock();						//aktuelle Zeit ermitteln
		 eaReplyTimer = (double)(eaAktTimeRep - eaStartTimeRep) / CLOCKS_PER_SEC;

 	   if (eaReplyTimer >= replyTO)			//Kommunikations-Timeout ueberwachen
       {
        eaReceive = FALSE;            //Abruch fuer Empfangsauswertung
        eaReplyTimer = 0;             //Timeout-Zaehler zuruecksetzen
  			rxRetries = 0;								//ev. vorhandene Retries loeschen
				sWP2_RxHs = 10;								//wieder in Ausgangsstate

        //Text-Log:
        if (GDebOn > 0)
          WPBasics.EvTxtLog( ::EvFileName, "WP2000. Timeout after retry", 0, 0 );
			 }
		} //else if (eaReceive = TRUE)

  else
    {
		 eaReplyTimer = 0;                   //Timeout-Zaehler zuruecksetzen
     oldRetVal = 0;                    //null Retries zu Beginn
		}

	//--------------------------------------------------------------------------//  
	// Meldungsaufbreitung       																								//
  //--------------------------------------------------------------------------//
	if ( (valFrame == TRUE) && (csACK == TRUE) )
		{
		 csACK = FALSE;
		 valFrame = FALSE;

		 //...Telegramm zerlegen und umkopieren
		 //Job-Id eintragen:
		 if (rxData[0] == ID_PIN_A)
			 WP2ReplyTgm.jobId = 20;
		 
		 else if (rxData[0] == ID_PIN_D)
			 WP2ReplyTgm.jobId = 10;
		
		 else if (rxData[0] == ID_PUN_A)
			 WP2ReplyTgm.jobId = 21;
		
		 else if (rxData[0] == ID_PUN_D)
			 WP2ReplyTgm.jobId = 11;
		
     else if (rxData[0] == ID_STS_A)
			 WP2ReplyTgm.jobId = 22;
		
     else if (rxData[0] == ID_STS_D)
			 WP2ReplyTgm.jobId = 12;

		 else
			 WP2ReplyTgm.jobId = -9;								    //unknown ID received

		 //dest. Adresse eintragen:
		 rxFrameAdr = rxData[1];
		 WP2ReplyTgm.hdr.dstAdr = rxFrameAdr & 0xF0;	//ausmaskieren: xxxx0000 (Byte)
     WP2ReplyTgm.hdr.dstAdr = WP2ReplyTgm.hdr.dstAdr / 16;	//HighByte ins LowByte schieben

		 //src. Adresse eintragen
		 rxFrameAdr = rxData[1];
		 WP2ReplyTgm.hdr.srcAdr = rxFrameAdr & 0x0F;  //ausmaskieren: 0000xxxx (Byte)

		 //Status eintragen:
		 WP2ReplyTgm.status = rxData[2];

		 //Daten eintragen:
		 memcpy( &WP2ReplyTgm.data, &rxData[3], sizeof(WP2ReplyTgm.data) );

		 //Daten bereit fuer uebergeordnete Applikation:
		 WP2ReplyTgm.hdr.jobNr++;
		
		} // if ( (valFrame == TRUE) and (csACK == TRUE) )

 }		//if (openStatus == TRUE)
 }		//while (TRU)
 return 0;
}		//UINT WP2000(LPVOID pWP2000)


UINT WP2Client(LPVOID pWP2Client)
//****************************************************************************//
//   Copyright:  1997  WePa - Enwicklung                                      //
//****************************************************************************//
//   Kennzeichnung:                                                           //
//       ID-Nr.    030209019677                                               //
//       System    Phone-Control                                              //
//       Subsystem WP2Client                                                  //
//       Funktion	 Ueberwacht das POI ueber die serielle Schnittstelle        //
//                                                                            //
//       Methode   UINT WP2Client(LPVOID pWP2Client)													//
//****************************************************************************//   
//   History                                                                  //                                          
//   Version     Datum       Autor           Beschreibung                     //
//   01.00       18.09.97    W. Paulin       Rumpfversion                     //
//   01.01       19.09.97    W. Paulin       Fehlerauswertung korrigiert      //                //
//   01.02       26.10.97    W. Paulin       Statusanfrage verriegelt bei PUN //
//   01.03       02.07.98    W. Paulin       Bit-Test bei Status-Auswertung   //
//																					 mit Maske geloest								//
//   01.04       03.07.98    W. Paulin       Adressen-Kontrolle bei Antwort   //
//																					 Status-Zuweisung bei PIN-Ausw.   //
//																					 korrigiert												//
//																					 stat. Fehlerauswertung korrigiert//		
//   01.05       07.07.98    W. Paulin       neg. Logik bei Statusauswertung  //
//																					 durch positve Logik ersetzt	    //
//   01.06       09.07.98    W. Paulin       Restart-Eigenschaft implementiert//
//   01.07       10.07.98    W. Paulin       Implementierung: Text-Logger     //
//   01.08       11.07.98    W. Paulin       connected-Auswertung verbessert  //
//****************************************************************************//
// Beschreibung :                                                             // 
//               POS - Kommunikation mit dem POI                              //
//****************************************************************************//
// Schnittstellen zum Treiber:                                                //
//                                                                            //
//               ReplyTgm                 ...Antwort-Telegramm des Treibers   //
//                       .hdr.tgmLen      ...Telegramm-L�nge                  //
//                       .hdr.jobNr       ...fortlaufende Job-Nummer          //
//                       .hdr.dstAdr      ...Zieladresse (eigene)             //
//                       .hdr.srcAdr      ...Quellenadresse                   //
//                       .jobId           ...Id des Jobs (Aufgabe)            //
//                       .status          ...Status der Gegenstation (bitkod.)//
//                       .data            ...�bermittlete Daten               //
//                                                                            //
//                 JobTgm                 ...Auftrags-Telegramm an den Treiber//
//                       .hdr.tgmLen      ...Telegramm-L�nge                  //
//                       .hdr.jobNr       ...fortlaufende Job-Nummer          //
//                       .hdr.dstAdr      ...Zieladresse                      //
//                       .hdr.srcAdr      ...Quellenadresse (eigene)          //
//                       .jobId           ...Id des Jobs (Aufgabe)            //
//                       .status          ...eigener Status /Kommando(bitkod.)//
//                       .data            ...zu �bermittlende Daten           //
//****************************************************************************//
// Job-IDs /Auftr�ge:                                                         //
//                 10...PIN-Quittung                                          //
//                 20...PIN-Anfrage ist zu verifizieren                       //
//                                                                            //
//                 11...PUN-Daten-Transfer                                    //
//                 21...PUN-Anfrage                                           //
//                                                                            //
//                 12...Status-Daten-Transfer                                 //
//                 22...Status-Anfrage                                        //
//****************************************************************************//
// Job-IDs /Quittungen:                                                       //
//                  0...job faultless done                                    //
//                 -1...no connection                                         //
//                 -2...destination not ready                                 //
//                 -3...retries failed                                        //
//                 -4...invalid sign received                                 //
//                 -5...unexepected receive                                   //
//                 -6...unexpected sign                                       //
//                 -7...communication canceled                                //
//                 -8...retry requested                                       //
//                 -9...unknown ID received                                   //
//****************************************************************************//
{
 //explizites Type-Casting
 ClientThreadInfo_s *pClientThreadInfo = (ClientThreadInfo_s*) pWP2Client;
 //Info-Struktur fuer Thread vorbereiten
 ClientInfo_s *pClientInfo = pClientThreadInfo->pWP2ClientInfo;
 CPOSDispatcherApp *pTheApp = (CPOSDispatcherApp*) pClientThreadInfo->pPOSDispApp;
 CPOSDispatcherDlg *pDlg = (CPOSDispatcherDlg*) pClientThreadInfo->pPOSDispDlg;

 ///////////////////////////////////////////////////////////////////////////////
 // Variablen-Deklaration /Beginn
 //Timervariablen:
 BYTE timeShot;																//Triggervariable
 clock_t startTime;											      //Startzeit des Timers
 clock_t aktTime;												      //aktuelle Zeit des Timers
 double stsTimer;													    //Status-Timer
 double stsZykl;															//Zyklus der Statusanfrage in Sekunden (z.B.: auch 0.1s moeglich)

 //sonstige Variablen:
 int lastJobId;																//Id des letzten Jobs
 unsigned long oldRTjobNr;										//letzte empfangene Job-Nummer
 WORD recPIN;																	//empfangene PIN
 BYTE locStatus;															//lokal kopierter Status
 BYTE oldHook;																//alter Zustand	
 BYTE oldSru;	  															//alter Zustand	
 BYTE oldDevice1;															//alter Zustand	
 BYTE oldDevice2;															//alter Zustand	
 BYTE oldDevice3;															//alter Zustand	
 BYTE oldDevice4;															//alter Zustand	
 char pathStr[256];										        //Pfad-String
 CString rstFileName;								          //Filename fuer POS Reset
 ///////////////////////////////////////////////////////////////////////////////
 // Variablen-Deklaration /Ende

while (TRUE)																			//endlos Schleife
{ 	
	if (::RestartClient)														//Restart-Auftrag
		{
		 ::RestartClient = 0;	

     //Text-Log:
     if (GDebOn >= 20)
       WPBasics.EvTxtLog( ::EvFileName, "WP2Client. Restart WP2Client() thread", 0, 0 );

		 //Timervariablen:
		 timeShot = 1;																//Triggervariable
		 startTime = 0;											          //Startzeit des Timers
		 aktTime = 0;												          //aktuelle Zeit des Timers
		 stsTimer = 0;													      //Status-Timer
		 stsZykl = 1;															    //Zyklus der Statusanfrage in Sekunden (z.B.: auch 0.1s moeglich)

		 //sonstige Variablen:
		 lastJobId = 0;																//Id des letzten Jobs
		 oldRTjobNr = 0;										          //letzte empfangene Job-Nummer
		 recPIN = 0;																	//empfangene PIN
		 locStatus = 0;															  //lokal kopierter Status
     oldHook = 0;	  															//alter Zustand	
		 oldSru = 0;	  															//alter Zustand	
		 oldDevice1 = 0;															//alter Zustand	
		 oldDevice2 = 0;															//alter Zustand	
		 oldDevice3 = 0;															//alter Zustand	
		 oldDevice4 = 0;															//alter Zustand	
	   pClientInfo->connected = 0;                  //default: connection broken
		}
    //------------------------------------------------------------------------//  
		// statistische Fehlerauswertung																					//
    //------------------------------------------------------------------------//
		if (WP2JobTgm.jobId < 0)											    //Quittung wurde geschickt
			{
			 switch (WP2JobTgm.jobId)
				{
         case -1: 
				   pClientInfo->cntNoConn++;    //no connection
           WP2JobTgm.jobId = 0;					//Fehlerauswertung beendet
    		   pClientInfo->connected = 0;  //connection broken
				 break;
   		   case -2: 
				   pClientInfo->cntDstNRdy++;		//destination not ready
           WP2JobTgm.jobId = 0;					//Fehlerauswertung beendet
         break;
				 case -3: 
				   pClientInfo->cntRetFail++;   //retries failed
           WP2JobTgm.jobId = 0;					//Fehlerauswertung beendet
    		   pClientInfo->connected = 0;  //connection broken
         break;
				 case -4: 
				   pClientInfo->cntInvSign++; 	//invalid sign received
           WP2JobTgm.jobId = 0;					//Fehlerauswertung beendet
    		   pClientInfo->connected = 0;  //connection broken
         break;
				 case -5: 
				   pClientInfo->cntUnXRec++;  	//unexpected receive
           WP2JobTgm.jobId = 0;					//Fehlerauswertung beendet
    		   pClientInfo->connected = 0;  //connection broken
         break;
				 case -6: 
				   pClientInfo->cntUnXSign++;   //unexpected sign
           WP2JobTgm.jobId = 0;					//Fehlerauswertung beendet
    		   pClientInfo->connected = 0;  //connection broken
         break;
				 case -7: 
				   pClientInfo->cntCCancel++;		//communication canceled
           WP2JobTgm.jobId = 0;					//Fehlerauswertung beendet
				 break;
				 case -8: 
					 pClientInfo->cntRetReq;			//retry requested

					 WP2JobTgm.hdr.dstAdr = pClientInfo->poi0Adr; //Zieladresse
					 WP2JobTgm.hdr.srcAdr = pClientInfo->ownAdr;  //eigene Adresse
					 WP2JobTgm.jobId = lastJobId;
					 WP2JobTgm.hdr.jobNr++;				//Wiederholung des letzten Jobs einleiten
				 break;
         case -9: 
				   pClientInfo->cntUnIdRec++;   //unknown Id received
           WP2JobTgm.jobId = 0;					//Fehlerauswertung beendet
    		   pClientInfo->connected = 0;  //connection broken
				 break;
				}
      }

    //------------------------------------------------------------------------//  
		// zyklische Statusanfrage																								//
    //------------------------------------------------------------------------//  
		if (timeShot == 1)
			{
			 timeShot = 0;															//Trigger zuruecksetzen
			 startTime = clock();												//Startzeit ermitteln
			}

		aktTime = clock();						                //aktuelle Zeit ermitteln
	  stsTimer = (double)(aktTime - startTime) / CLOCKS_PER_SEC;

		if ( (stsTimer >= stsZykl) && (WP2JobTgm.jobId == 0) && (WP2ReplyTgm.jobId == 0) )
			{
			 timeShot = 1;															//Trigger erneut ausloesen

			 WP2JobTgm.hdr.dstAdr = pClientInfo->poi0Adr; //Zieladresse
			 WP2JobTgm.hdr.srcAdr = pClientInfo->ownAdr;  //eigene Adresse

			 WP2JobTgm.jobId = 22;												//Job-Id fuer Statusanfrage
			 WP2JobTgm.hdr.jobNr++;												//neue Statusanfrage
			}

    //------------------------------------------------------------------------//  
		// Empfangstelegramm-Auswertung																						//
    //------------------------------------------------------------------------//  
		if ( (WP2ReplyTgm.hdr.jobNr != oldRTjobNr) && (WP2ReplyTgm.hdr.dstAdr == pClientInfo->ownAdr) )
			{
 	     pClientInfo->connected = 1;       //connection established
			 oldRTjobNr = WP2ReplyTgm.hdr.jobNr;
			 switch (WP2ReplyTgm.jobId)
				 {
          //-------------------- PIN - Auswertung /Beginn --------------------//
				  case 20:
						//...empfangene PIN auswerten
						WP2ReplyTgm.jobId = 0;									       //Antwort erhalten
						recPIN = 0;																		 //PIN loeschen
						
						recPIN =          WP2ReplyTgm.data[0] * 1000;	 //recPIN: x000
						recPIN = recPIN + WP2ReplyTgm.data[1] * 100;	 //recPIN: xx00	
						recPIN = recPIN + WP2ReplyTgm.data[2] * 10;	 	 //recPIN: xxx0	
						recPIN = recPIN + WP2ReplyTgm.data[3] * 1;	   //recPIN: xxxx
						
						locStatus = WP2ReplyTgm.status; 	 //Status-Register kopieren

						if (recPIN == pClientInfo->valPIN) // richtiger Code eingegeben
							{
							 WP2JobTgm.status = locStatus & 0x7F; //Bit-Nr.7 null setzen
							 pClientInfo->cntValPIN++;
					
					     //Text-Log:
               WPBasics.EvTxtLog( ::EvFileName, "WP2Client. Login with valid PIN => PIN", LONG(recPIN), 0 );
							}		
						else  //flascher Code --> auflegen !!!
							{
							 WP2JobTgm.status = locStatus | 0x80; //Bit-Nr.7 eins setzen
							 pClientInfo->cntInvPIN++;

					     //Text-Log:
               WPBasics.EvTxtLog( ::EvFileName, "WP2Client. Logout cause of invalid PIN => inv. PIN / val. PIN", LONG(recPIN), LONG(pClientInfo->valPIN) );
							}

 		  		  WP2JobTgm.hdr.dstAdr = pClientInfo->poi0Adr; //Zieladresse
						WP2JobTgm.hdr.srcAdr = pClientInfo->ownAdr;  //eigene Adresse
	
						WP2JobTgm.jobId = 10;												 //Job-Id fuer PIN-Quittung
						lastJobId = WP2JobTgm.jobId;								 //fuer ev. Retries
						WP2JobTgm.hdr.jobNr++;											 //PIN-Quittung schicken
					
					break;
					//--------------------- PIN - Auswertung /Ende ---------------------//

          //-------------------- PUN - Auswertung /Beginn --------------------//
					case 21:																	  //Pick-up-Number - Anfrage
						WP2ReplyTgm.jobId = 0;									     //Antwort erhalten

						WP2JobTgm.data[0] = pClientInfo->sndPUN;     //PUN eintragen

 		  		  WP2JobTgm.hdr.dstAdr = pClientInfo->poi0Adr; //Zieladresse
						WP2JobTgm.hdr.srcAdr = pClientInfo->ownAdr;  //eigene Adresse
	
						WP2JobTgm.jobId = 11;												 //Job-Id fuer PUN-Daten
						lastJobId = WP2JobTgm.jobId;								 //fuer ev. Retries
						WP2JobTgm.hdr.jobNr++;											 //PIN-Quittung schicken

			      //Text-Log:
            WPBasics.EvTxtLog( ::EvFileName, "WP2Client. Pick up number requested => current PUN", LONG(WP2JobTgm.data[0]), 0 );
					
					break;
					//--------------------- PUN - Auswertung /Ende ---------------------//

          //------------------- Status - Auswertung /Beginn ------------------//
					case 12:														 //Status-Informationen
						WP2ReplyTgm.jobId = 0;						 //Antwort erhalten
						
						locStatus = WP2ReplyTgm.status; 	 //Status-Register kopieren
						
						//...Phone-Line-Condition
						if ( (locStatus & 0x80) == 0x80 )  //Bit-Test Nr. 7; 10000000b
							pClientInfo->hook = 0;					 //off hook
						else
							pClientInfo->hook = 1;					 //on hook
 		        
						//Text-Log bei Zustandsanderung:
            if ( (oldHook != pClientInfo->hook) && (pClientInfo->hook == 0) )
              WPBasics.EvTxtLog( ::EvFileName, "WP2Client. recognize off hook", 0, 0 );
            else if ( (oldHook != pClientInfo->hook) && (pClientInfo->hook == 1) )
              WPBasics.EvTxtLog( ::EvFileName, "WP2Client. recognize on hook", 0, 0 );
						
						oldHook = pClientInfo->hook;


						//...POS - Resetauftrag
						if ( (locStatus & 0x40) == 0x40 )	 //Bit-Test Nr. 6; 01000000b
							{
  						 pClientInfo->posReset = 1;			 //Reset von POS ausloesen
				       //Text-Log:
               WPBasics.EvTxtLog( ::EvFileName, "WP2Client. POS reset job queued", 0, 0 );

							 GetCurrentDirectory( 256, pathStr); 
							 rstFileName = pathStr;	
							 rstFileName += "\\POS_UTIL\\Restart.exe";

 			         WinExec (rstFileName,SW_SHOW); //Boot-Sequenz einleiten
							}
						else
							pClientInfo->posReset = 0;			 //keinen POS - Reset ausloesen

		
						//...Sicherheitsabschaltung
						if ( (locStatus & 0x20) == 0x20 )	 //Bit-Test Nr. 5; 00100000b
							{
							 pClientInfo->safetyCO = 1;			 //Safety-Cut-Off eingeleitet
				       //Text-Log:
               WPBasics.EvTxtLog( ::EvFileName, "WP2Client. Safety-Cut-Off job queued", 0, 0 );
	  					}
						else
							pClientInfo->safetyCO = 0;			 //Safety-Cut-Off inaktiv


						//...Spracherkennungs-Einheit
						if ( (locStatus & 0x10) == 0x10 )	 //Bit-Test Nr. 4; 00010000b
							{
							 pClientInfo->sru = 1;					   //Speech-Recognition aktivieren
    			     AfxMessageBox( "Speech Reco Unit active", MB_OK | MB_ICONEXCLAMATION, 0 );
							}
						else
							pClientInfo->sru = 0;					   //Speech-Recognition deaktivieren

						//Text-Log bei Zustandsanderung:
            if ( (oldSru != pClientInfo->sru) && (pClientInfo->sru == 0) )
              WPBasics.EvTxtLog( ::EvFileName, "WP2Client. Speech Reco Unit deactivated by user", 0, 0 );
            else if ( (oldSru != pClientInfo->sru) && (pClientInfo->sru == 1) )
              WPBasics.EvTxtLog( ::EvFileName, "WP2Client. Speech Reco Unit activated by user", 0, 0 );
						
						oldSru = pClientInfo->sru;


						//...Device Nr.4
						if ( (locStatus & 0x08) == 0x08 )  //Bit-Test Nr. 3; 00001000b
							pClientInfo->device4 = 0;				 //Device Nr.4 ist eingeschaltet
						else
							 pClientInfo->device4 = 1;				 //Device Nr.4 ist ausgeschaltet

						//Text-Log bei Zustandsanderung:
            if ( (oldDevice4 != pClientInfo->device4) && (pClientInfo->device4 == 0) )
              WPBasics.EvTxtLog( ::EvFileName, "WP2Client. User switched off device #4", 0, 0 );
            else if ( (oldDevice4 != pClientInfo->device4) && (pClientInfo->device4 == 1) )
              WPBasics.EvTxtLog( ::EvFileName, "WP2Client. User switched on device #4", 0, 0 );
						
						oldDevice4 = pClientInfo->device4;


						//...Device Nr.3
						if ( (locStatus & 0x04) == 0x04 )	 //Bit-Test Nr. 2; 00000100b
							pClientInfo->device3 = 0;				 //Device Nr.3 ist eingeschaltet
						else
							 pClientInfo->device3 = 1;				 //Device Nr.3 ist ausgeschaltet

						//Text-Log bei Zustandsanderung:
            if ( (oldDevice3 != pClientInfo->device3) && (pClientInfo->device3 == 0) )
              WPBasics.EvTxtLog( ::EvFileName, "WP2Client. User switched off device #3", 0, 0 );
            else if ( (oldDevice3 != pClientInfo->device3) && (pClientInfo->device3 == 1) )
              WPBasics.EvTxtLog( ::EvFileName, "WP2Client. User switched on device #3", 0, 0 );
						
						oldDevice3 = pClientInfo->device3;


						//...Device Nr.2
						if ( (locStatus & 0x02) == 0x02 )	 //Bit-Test Nr. 1; 00000010b
							pClientInfo->device2 = 0;				 //Device Nr.2 ist eingeschaltet
						else
							 pClientInfo->device2 = 1;				 //Device Nr.2 ist ausgeschaltet

						//Text-Log bei Zustandsanderung:
            if ( (oldDevice2 != pClientInfo->device2) && (pClientInfo->device2 == 0) )
              WPBasics.EvTxtLog( ::EvFileName, "WP2Client. User switched off device #2", 0, 0 );
            else if ( (oldDevice2 != pClientInfo->device2) && (pClientInfo->device2 == 1) )
              WPBasics.EvTxtLog( ::EvFileName, "WP2Client. User switched on device #2", 0, 0 );
						
						oldDevice2 = pClientInfo->device2;


						//...Device Nr.1
						if ( (locStatus & 0x01) == 0x01 )  //Bit-Test Nr. 0; 00000001b
							pClientInfo->device1 = 0;				 //Device Nr.1 ist eingeschaltet
						else
							 pClientInfo->device1 = 1;				 //Device Nr.1 ist ausgeschaltet

						//Text-Log bei Zustandsanderung:
            if ( (oldDevice1 != pClientInfo->device1) && (pClientInfo->device1 == 0) )
              WPBasics.EvTxtLog( ::EvFileName, "WP2Client. User switched off device #1", 0, 0 );
            else if ( (oldDevice1 != pClientInfo->device1) && (pClientInfo->device1 == 1) )
              WPBasics.EvTxtLog( ::EvFileName, "WP2Client. User switched on device #1", 0, 0 );
						
						oldDevice1 = pClientInfo->device1;

					
					break;
          //-------------------- Status - Auswertung /Ende -------------------//

				 } //switch (WP2ReplyTgm.jobId)

			} //if ( (WP2ReplyTgm.hdr.jobNr != oldRTjobNr) && (WP2ReplyTgm.hdr.srcAdr == pClientInfo->ownAdr) )
	
 }//while (TRUE)

 return 0;
} //UNIT WP2Client(LPVOID pWP2Client)
