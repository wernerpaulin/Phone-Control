//****************************************************************************//
//   Copyright:  1997  WePa - Entwicklungsabteilung                           //
//****************************************************************************//
//   Kennzeichnung:                                                           //
//       ID-Nr.       030209019677                                            //
//       System       SIO                                                     //
//       Sub-System   ---                                                     //
//       Funktion     Ansteuerung einer seriellen Schnittstelle durch spez.   //
//										Funktionen																							//	
//       Filename     SIO.cpp                                                 //
//****************************************************************************//
//   History:                                                                 //
//   Version     Datum       Autor           Bemerkung                        //
//   00.01       07.12.97    W. Paulin       Erstellung                       //
//   00.02       13.06.98    W. Paulin       Implementierung: Overlapped-IO   //
//   00.03       01.07.98    W. Paulin       div. Korrekturen f. Overlapped-IO//
//   00.04       03.07.98    W. Paulin       String-Bau f. COM-Port verbessert//
//****************************************************************************//
// Beschreibung :                                                             //
//				  Steuerung der seriellen Kommunikation ueber COM-Ports             //
//					folgende Methoden werden unterstuetzt:														//
//						* SIO_OPEN:																											//
//											- Aufgabe: den COM-Port zu oeffen und zu parametrieren//
//											- Eingabeparameter: ...COM-Port - Nummer  						//
//																					...Empfangsbuffer - Laenge				//
//																					...Sendebuffer - Laenge						//
//																					...SIO-Mode - Struktur:						//
//																																						//
//											- Ausgabeparameter: ...Fehlerstatus										//
//																					...Handle des geoeffneten Ports	  //
//			    Fehlerstati:																											//		
//										  0... Empfang/Schreiben abgeschlossen				      		//
//										  1... to be defined         														//
//										  2... Empfangsbuffer leer														  //
//										 31... unbekannter Fehler beim Lesen/Schreiben			  	//
//										 32... unbekannter Fehler beim Lesen/Schreiben					//
//										 33... unbekannter Fehler beim Lesen/Schreiben					//
//										  4... falschen Event erkannt														//
//										  5... unbekannter erweiterter Fehler										//
//                      6... Fehler beim warten auf Event											//
//****************************************************************************//

#include "stdafx.h"
#include "POS Dispatcher.h"
#include "SIO.h"
#include "iostream.h"
#include "string.h"


/////////////////////////////////////////////////////////////////////////////
// CSIO

CSIO::CSIO()
{
}

CSIO::~CSIO()
{
}


/////////////////////////////////////////////////////////////////////////////
// SIO_OPEN
LONG CSIO::SIO_OPEN(
										BYTE locPortNr,	  					//dezimale Port-Nummer
							      DWORD locRxBufLng,		  		//Empfangsbuffer-Laenge in Bytes
							      DWORD locTxBufLng,					//Sendebuffer-Laenge in Bytes
							      SioMode_s &locSioMode,		 	//Modus der seriellen Verbindung
							      HANDLE &locSioHandle			  //Handle des geoeffneten COM-Ports
									 )
	{
	 //...... Zusammensetzung des COM-Port-Strings /Beginn ......//
   portName = "\\\\.\\COM";	    					  //Port-Name vorbereiten

   strPortNr = (locPortNr / 10) % 10 + '0';	//Integer -> ASCII - Wandlung
   if (strPortNr != '0')										//keine fuehrenden Nuller					
		 portName += strPortNr;
 
   strPortNr = (locPortNr /  1) % 10 + '0';	//Integer -> ASCII - Wandlung
   portName += strPortNr;
	 //....... Zusammensetzung des COM-Port-Strings /Ende .......//

	 //.................... COM-Port oeffnen /Beginn ....................//
	 locSioHandle = CreateFile(  														 //Port oeffnen
													   portName,	                   //Port-Name
														 GENERIC_READ | GENERIC_WRITE, //schreiben und lesen
														 0,														 //Port privat reserviert 
														 NULL, 												 //von WIN95 ignoriert  
														 OPEN_EXISTING,								 //speziell f. COM-Ports 
														 FILE_FLAG_OVERLAPPED,         //vollduplex-Zugriff auf RS232
														 NULL 												 //speziell f. COM-Ports   
													  );
	 //..................... COM-Port oeffnen /Ende .....................//
	 
	 
	 //............... Events fuer Port definieren /Beginn ...............//
 	 locOpenStatus = 0;										 			  //Status ruecksetzen

	 if ( locSioHandle == INVALID_HANDLE_VALUE )
		 {
		  locOpenStatus = GetLastError();           //COM-Port existiert nicht
			return locOpenStatus;
		 }
   locOpenStatus = SetCommMask(locSioHandle, EV_RXCHAR);		 //Maske definieren
	 //................ Events fuer Port definieren /Ende ...............//
	 
	 
	 //.................... Buffer allokieren /Beginn ..................//
	 if (locOpenStatus == FALSE)																
		 {
		  locOpenStatus = GetLastError();									//Fehler beim Maskenbilden
			return locOpenStatus;
		 }
	 locOpenStatus = SetupComm(locSioHandle, locRxBufLng, locTxBufLng);		
	 //..................... Buffer allokieren /Ende ...................//


	 PurgeComm(locSioHandle, PURGE_TXCLEAR | PURGE_RXCLEAR);  //Buffer loeschen

	 DCB sioDCB;													//Device-Control-Block - Struktur anlegen

	 sioDCB.DCBlength = sizeof(DCB);												//size of DCB-structure

	 GetCommState(locSioHandle, &sioDCB);										  //Default-Werte des Ports

	 
	 
	 //................ COM-Port Einstellungen laden /Beginn ................//
	 if (locOpenStatus == FALSE)																
		 {
		  locOpenStatus = GetLastError();									//extended error information
			return locOpenStatus;
		 }

	 sioDCB.BaudRate = locSioMode.baudrate;            // current baud rate 
   sioDCB.fBinary = TRUE ;                           // binary mode, no EOF check 
      
   if (locSioMode.parity != NOPARITY)
		 {
		  sioDCB.fParity = TRUE;							           //enable parity checking 
		  sioDCB.Parity = locSioMode.parity;             // 0-4=no,odd,even,mark,space 
		 }
	 else
	   {
		  sioDCB.fParity = FALSE;						//disable parity checking 
		  sioDCB.Parity = 0;     // 0-4=no,odd,even,mark,space 
		 }

	 sioDCB.fErrorChar = FALSE;       // enable error replacement 
				
   sioDCB.fOutxCtsFlow = locSioMode.ctsControl;      // CTS output flow control 
   sioDCB.fOutxDsrFlow = locSioMode.dsrControl;      // DSR output flow control 
   sioDCB.fDsrSensitivity = locSioMode.dsrControl;   // DSR sensitivity 
   sioDCB.fDtrControl = locSioMode.dtrControl;;      // DTR flow control type 
   sioDCB.fRtsControl = locSioMode.rtsControl;       // RTS flow control 
   sioDCB.ByteSize = locSioMode.nbDataBytes;         // number of bits/byte, 4-8 
   sioDCB.StopBits = locSioMode.stopBits;            // 0,1,2 = 1, 1.5, 2 
      
	 sioDCB.fTXContinueOnXoff = TRUE; // XOFF continues Tx 
   sioDCB.fOutX = FALSE;            // XON/XOFF out flow control 
   sioDCB.fInX = FALSE;             // XON/XOFF in flow control 
   //sioDCB.XonLim = 0;               // transmit XON threshold 
   //sioDCB.XoffLim = (unsigned short) locRxBufLng;              // transmit XOFF threshold 
   //sioDCB.XonChar = 0x11;              // Tx and Rx XON character 
   //sioDCB.XoffChar = 0x13 ;             // Tx and Rx XOFF character 
      
   sioDCB.fNull = TRUE;            // enable null stripping 
   sioDCB.fAbortOnError = FALSE;     // abort reads/writes on error 
   //sioDCB.ErrorChar = 0x14;            // error replacement character 
   //sioDCB.EofChar = 0x10;              // end of input character 
   sioDCB.EvtChar = 0x31;              // received event character 

   sioDCB.wReserved = 0;            // not currently used 
   //sioDCB.fDummy = ??;          // reserved 
   //sioDCB.wReserved1;           // reserved; do not use 

	 locOpenStatus = SetCommState(locSioHandle, &sioDCB);
	 //................. COM-Port Einstellungen laden /Ende .................//
	
	 //.............. Overlapped-Struktur initalisieren /Begin ................//
	 
	 
	 //sioOverlapped.Internal = ??;      //Reserved for operating system use
   //sioOverlapped.InternalHigh = ??;  //Reserved for operating system use
   sioOverlapped.Offset = NULL;				 //irrelevant for COM-Devices		
   sioOverlapped.OffsetHigh = NULL;    //irrelevant for COM-Devices		
   sioOverlapped.hEvent = CreateEvent(
																			NULL,	  // pointer to security attributes  
																			TRUE,	  // flag for manual-reset event 
																			FALSE,	// flag for initial state 
																			NULL 	  // pointer to event-object name  
																		 ); 
	 //............... Overlapped-Struktur initalisieren /Ende .................//
	 
	 //bei Fehler: COM-Port deinitialisieren
	 if (locOpenStatus == FALSE)
		 {
      locOpenStatus = GetLastError();												    //extended Error-Info
			SetCommMask( locSioHandle,0 );												    //Maske loeschen
		  PurgeComm( locSioHandle, PURGE_TXCLEAR | PURGE_RXCLEAR |
															  PURGE_TXABORT | PURGE_RXABORT );//Buffer loeschen
			CloseHandle(locSioHandle);
		  locOpenStatus = GetLastError();									//extended error information
			return locOpenStatus;
		 }

   //Communication-Timeouts festlegen...		
	
	 //Intervall zw. 2 empfangenen Bytes: Baud = Bits/s -> /8000 => Bytes/ms
	 //Zeiteinheit pro Byte + Sicherheitsfaktor (2ms)
	 sioCommTO.ReadIntervalTimeout =  (8000 / sioDCB.BaudRate) + 2; 
	 sioCommTO.ReadTotalTimeoutMultiplier = sioCommTO.ReadIntervalTimeout; 
	 sioCommTO.ReadTotalTimeoutConstant = 0; 
	 sioCommTO.WriteTotalTimeoutMultiplier = (8000 / sioDCB.BaudRate) + 2; 
	 sioCommTO.WriteTotalTimeoutConstant = 0; 

	 SetCommTimeouts(locSioHandle, &sioCommTO);

   cyclicWait = 0;						//Lesen vorbereiten

 	 return locOpenStatus;
	} //void CSIO::SIO_OPEN() 


/////////////////////////////////////////////////////////////////////////////
// SIO_CLOSE
LONG CSIO::SIO_CLOSE( HANDLE &locSioHandle )	//Handle des geoeffneten COM-Ports
	{
 	 SetCommMask(locSioHandle,0);												     //Maske loeschen
   PurgeComm( locSioHandle, PURGE_TXCLEAR | PURGE_RXCLEAR |
							 					    PURGE_TXABORT | PURGE_RXABORT );//Buffer loeschen
	 locCloseStatus = CloseHandle(locSioHandle);
	 if (locCloseStatus == FALSE)
		 {
		  locCloseStatus = GetLastError();									//extended error information
			return locCloseStatus;
		 }

 	 return locCloseStatus;
	} //void CSIO::SIO_CLOSE()

/////////////////////////////////////////////////////////////////////////////
// SIO_READ
//initialWait
LONG CSIO::SIO_READ( HANDLE &locSioHandle,		//Handle des geoeffneten COM-Ports
		  					     LPVOID locRxBuf,					//Pointer auf Empfangsbuffer
  							     DWORD locRxBufLng        //Empfangsbuffer-Laenge in Bytes
									 )
	{
   if (cyclicWait == 0) 			//nur einmal pro empfangens Zeichen !
	 	 {	
      cyclicWait = 1;
	    dwEventMaskValue = 0;
      waitStatus = WaitCommEvent(locSioHandle,&dwEventMaskValue,&sioOverlapped);
		 }
	 //Auswertungen und Plausibiltaetskontrolle
	 //Zeichen wurde empfangen
	 if ( (waitStatus == TRUE) && ((dwEventMaskValue & EV_RXCHAR) == EV_RXCHAR) )
		 {
//      AfxMessageBox( "direkter Empfang", MB_OK | MB_ICONEXCLAMATION, 0 );
      locReadStatus = ReadFile( locSioHandle,	   //Handle des geoeffneten COM-Ports
 		   		                      locRxBuf,	  		 //Empfangsbuffer
				                        locRxBufLng,		   //Empfangsbuffer - Laenge
					                      &locBytesRead,	   //Anzahl gelesener Bytes
					                      &sioOverlapped);  //Overlapp-Struktur
   	  if (locReadStatus == TRUE)
		    {
		     locReadStatus = 0;					//Lesevorgang abgeschlossen			
         cyclicWait = 0;						//wieder neu auf Event warten	
	       return locReadStatus;
		    }
      else
		    {
         locReadStatus = GetLastError();
    		 if ( locReadStatus == ERROR_IO_PENDING )
				   {
            waitObjStatus = WaitForSingleObject(
				                                        sioOverlapped.hEvent,  //Handle des Event-Objekts
					   						            					  INFINITE
													                     );
            if (waitObjStatus == WAIT_OBJECT_0)
              {		
//               AfxMessageBox( "ReadFile - Lesen abgeschlossen", MB_OK | MB_ICONEXCLAMATION, 0 );
      		     locReadStatus = 0;					//Lesevorgang abgeschlossen			
               cyclicWait = 0;						//wieder neu auf Event warten	
 	             return locReadStatus;
						  }
				   }					
				 else
				   {
  		      locReadStatus = 31;				  //unbekannter Fehler beim Lesen
            //Fehlerhandling
            PurgeComm( locSioHandle, PURGE_RXCLEAR | PURGE_RXABORT );//Buffer loeschen
						cyclicWait = 0;						//wieder neu auf Event warten	

	          return locReadStatus;
				   }
		    }
 		 }
	 
	 //Warten auf Event noch nicht abgeschlossen
	 else if (waitStatus == FALSE)
	 	 {
		  getStatus = GetLastError();
		  if ( getStatus == ERROR_IO_PENDING )
			  {
				 //warten auf Event-Signalisierung
//			   AfxMessageBox( "WaitForSingleObject()", MB_OK | MB_ICONEXCLAMATION, 0 );
     		 waitObjStatus = WaitForSingleObject(
				                                     sioOverlapped.hEvent,  //Handle des Event-Objekts
														                 sioCommTO.ReadTotalTimeoutMultiplier * locRxBufLng //Verzoegerung in ms	
													                  );
         if (waitObjStatus == WAIT_OBJECT_0)
					 {		
//    			  AfxMessageBox( "GetOverlappedResult()", MB_OK | MB_ICONEXCLAMATION, 0 );
					  getStatus = GetOverlappedResult(locSioHandle,   //Handle des geoeffneten COM-Ports
						        										    &sioOverlapped, //Pointer auf Overlapped-Struktur 
										        							  &nbByteTxRx,    //Anzahl transferierter Bytes
														         			  TRUE 					  //Warten auf empf. Zeichen
																	         );
            //...Lesevorgang beendet
	          if ( (getStatus == TRUE) && ((dwEventMaskValue & EV_RXCHAR) == EV_RXCHAR) )
	            {
               locReadStatus = ReadFile( locSioHandle,	   //Handle des geoeffneten COM-Ports
			  		                             locRxBuf,	  		 //Empfangsbuffer
					                               locRxBufLng,		  //Empfangsbuffer - Laenge
						                             &locBytesRead,	  //Anzahl gelesener Bytes
						                             &sioOverlapped); //keine Overlapp-Struktur
            	 if (locReadStatus == TRUE)
		             {
		              locReadStatus = 0;					//Lesevorgang abgeschlossen			
                  cyclicWait = 0;						//wieder neu auf Event warten	
                  return locReadStatus;
		             }
               else
          	     {
  		            locReadStatus = GetLastError();
								  if ( locReadStatus == ERROR_IO_PENDING )
									  {
                		 waitObjStatus = WaitForSingleObject(
				                                                 sioOverlapped.hEvent,  //Handle des Event-Objekts
																            						 INFINITE
													                              );
                     if (waitObjStatus == WAIT_OBJECT_0)
					             {		
//            			      AfxMessageBox( "ReadFile - Lesen abgeschlossen", MB_OK | MB_ICONEXCLAMATION, 0 );
      		              locReadStatus = 0;					//Lesevorgang abgeschlossen			
                        cyclicWait = 0;						//wieder neu auf Event warten	
 	                      return locReadStatus;
											 }
									  }					
								  else
								    {
    		             locReadStatus = 32;				  //unbekannter Fehler beim Lesen
				             //Fehlerhandling
								     PurgeComm( locSioHandle, PURGE_RXCLEAR | PURGE_RXABORT );//Buffer loeschen
						         cyclicWait = 0;						//wieder neu auf Event warten	

    	               return locReadStatus;
									  }
     				
			            return locReadStatus;
		             }
	 	          }

            //...Lesevorgang noch nicht beendet
        	  else
	 	          {
		           getStatus = GetLastError();
			         if ( (getStatus == ERROR_IO_INCOMPLETE) || (getStatus == ERROR_IO_PENDING) )
			           {
			            locReadStatus = 2;		//Lesen noch nicht abgeschlossen
    	            return locReadStatus;
			           }
			         else
			           {
			            locReadStatus = 33;		//unbekannter Fehler beim Schreiben
			            //Fehlerhandling
						      PurgeComm( locSioHandle, PURGE_RXCLEAR | PURGE_RXABORT );//Buffer loeschen
									cyclicWait = 0;						//wieder neu auf Event warten	

    	            return locReadStatus;
				         }
			 	
		          }
	

           }
				 else if (waitObjStatus == WAIT_TIMEOUT)
					 {
			      locReadStatus = 2;		//Lesen noch nicht abgeschlossen
    	      return locReadStatus;
					 }
				 else
   			   {
            locReadStatus = 6;				  //Fehler beim warten auf Event
            //Fehlerhandling
            PurgeComm( locSioHandle, PURGE_RXCLEAR | PURGE_RXABORT );//Buffer loeschen
						cyclicWait = 0;						//wieder neu auf Event warten	

            return locReadStatus;
			     }				
					
			  }	  
		  else
			  {
         locReadStatus = 5;				  //unbekannter erweiteter Fehler beim Lesen
         //Fehlerhandling
         PurgeComm( locSioHandle, PURGE_RXCLEAR | PURGE_RXABORT );//Buffer loeschen
 				 cyclicWait = 0;						//wieder neu auf Event warten	

         return locReadStatus;
			  }				

		 }

	 //falschen Event erkannt
	 else
		 {
      locReadStatus = 4;				  
      //Fehlerhandling
      PurgeComm( locSioHandle, PURGE_RXCLEAR | PURGE_RXABORT );//Buffer loeschen
			cyclicWait = 0;						//wieder neu auf Event warten	

      return locReadStatus;
		 }

   return locReadStatus;
	}


/////////////////////////////////////////////////////////////////////////////
// SIO_WRITE
LONG CSIO::SIO_WRITE( HANDLE &locSioHandle,		 //Handle des geoeffneten COM-Ports
		  					      LPVOID locTxBuf,				 //Pointer auf Sendebuffer
  							      DWORD locTxBufLng		   	 //Sendebuffer-Laenge in Bytes
										)
	{
	 locWriteStatus = WriteFile( locSioHandle,	   //Handle des geoeffneten COM-Ports
															 locTxBuf,	       //Sendebuffer
															 locTxBufLng,	     //Sendebuffer-Laenge
															 &locBytesWritten, //Anzahl geschriebnene Bytes
															 &sioOverlapped);  //Overlapp-Struktur
   
   
	 if (locWriteStatus == TRUE )
		 {
		  locWriteStatus = 0;	              				 //Schreibvorgang erfolgreich abgeschlossen
			return locWriteStatus;
		 }
   else
	   {
      locWriteStatus = GetLastError();
      if ( locWriteStatus == ERROR_IO_PENDING )
			  {
         waitObjStatus = WaitForSingleObject(
			                                       sioOverlapped.hEvent,  //Handle des Event-Objekts
			    						            					 INFINITE
													                  );
         if (waitObjStatus == WAIT_OBJECT_0)
           {		
      	    locWriteStatus = 0;					//Schreibvorgang abgeschlossen			
 	          return locWriteStatus;
				   }
				}					
			else
			  {
  		   locWriteStatus = 31;				  //unbekannter Fehler beim Schreiben
         //Fehlerhandling
         PurgeComm( locSioHandle, PURGE_TXCLEAR | PURGE_TXABORT );//Buffer loeschen

	       return locWriteStatus;
			  }
		 }

	 return locWriteStatus;
	}


