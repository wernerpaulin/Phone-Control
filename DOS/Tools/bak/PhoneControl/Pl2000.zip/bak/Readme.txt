Filename	  	Version  Datum      Kommentar
WP2000_V112_281198.zip  V1.12    28.11.98   Portierung auf PG V2.39, neue Frametreiber-Library
					    und neue Burtrap-Library
WP2000_V113_281198.zip  V1.13    28.11.98   FRM_xope() implementiert


