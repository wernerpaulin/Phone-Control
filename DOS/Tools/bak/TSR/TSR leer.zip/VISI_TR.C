/******************************************************************************\
***  /---------\							     ***
*** | VISI_TR.C	|							     ***
***  \---------/							     ***
***									     ***
*** User-Modul f�r erweiterten VisiPro-Treiber				     ***
*** ------------------------------------------				     ***
***									     ***
*** Die	zur �bergabe ben�tigte Auftragsstruktur	hat folgenden Aufbau:	     ***
***									     ***
*** typedef struct {							     ***
***	int	nAll;	     //	 Nummer	des Treibers oder R/W/K/1	     ***
***	int	nWords;	     //	 Anzahl	zu �bermittelner Datenw�rter	     ***
***	int	far *lpData; //	 Zeiger	auf Datenziel- bzw. quelle	     ***
***	char	szAdr[12];   //	 ASCII SPS-Adresse			     ***
***	int	nOff;	     //	 Offset	auf SPS-Adresse			     ***
***	int	nBit;	     //	 Bitnummer (-1 bei Worten)		     ***
***	char	szXAdr[100]; //	 erweiterter Adre�string (wenn @ bei szAdr)  ***
*** } DEV_COM, far *LP_DEV_COM;						     ***
***									     ***
\******************************************************************************/

#include <stdlib.h>
#include <stdio.h>
#include "visi_trx.h"
#include <string.h>
#include <memory.h>
#include <ctype.h>
#include <time.h>




LP_EXT_DEV  hpData[MAX_SEGMENTS];           // globaler Datenzeiger der vom Kern kommt
static int  nDataCount;                     // Bekannt fuer alle Funktionen in diesem File
 char  ReadBuf[160];
static char  ReadRespBuf[160];
static char  WriteBuf[160];
static char  WriteRespBuf[160];
static char  nCommand[3];
static char  nTyp;								//Datentyp, falls Longvariable
static block_typ Block;

//int	 send_len = 0,
int  rec_len = 0;                 //L�nge in W�rtern des Empfansstrings (darf nicht > L�nge des VWD-Objektes sein)
volatile int	 byte_send_len = 0;
int  byte_rec_len = 0, byte_send_len_loc=0;		//L�nge des E17 Protokollstringes in Byte
static station_typ st;
static int	 E17_state;

static ERRSTRUCT_typ err;
//static time_t VPltime, VPltimeold;
//static int VPcyccnt;

char BlockMode = 0, TextBlockMode = 0;

extern PTR send_buffer;                        /* Sendepuffer */
unsigned short outbuflng;                        /* Groesse des Sendepuffers */
extern PTR recv_buffer;                        /* Empfangspuffer */
unsigned short inbuflng;                         /* Groesse des Empfangspuffers */
char txtbuffer[100];


DEV_COM ComOld;
char RunningJob = 0;
volatile int byteSNDCount=0;
extern int nPort;

/*=====================================================================*\
|																		|
|   GRUNDFUNKTIONEN (ausreichend f�r einfache Treiber)					|
|																		|
\*=====================================================================*/

/***********************************************************************\
***  VPRead							      ***
***	  Leseauftrag im Zyklus					      ***
***								      ***
***	  lpCom:    �bergabestruktur				      ***
***		    in ->nAll steht Treibertyp			      ***
***								      ***
\***********************************************************************/
int VPRead (LP_DEV_COM lpCom)
{

	int ind=0;
	int bufind=0;
	char BCC = 0, terminate=0, timeout = 0;

    #ifdef TOLOG
    add_log("*** VPRead function called ***");
	sprintf(txtbuffer,"Aufruf_adresse: %d",lpCom->lpData);
	add_log(txtbuffer);
	#endif

    return(0);
}

/***********************************************************************\
***  VPWrite							      ***
***	  Schreibauftrag im Zyklus				      ***
***								      ***
***	  lpCom:    �bergabestruktur				      ***
***		    in ->nAll steht Treibertyp			      ***
***								      ***
\***********************************************************************/
int VPWrite (LP_DEV_COM	lpCom)
{
	int ind=0;


    #ifdef TOLOG
    add_log("*** VPWRITE function called ***");

    printf("nAll:   %d\n", lpCom->nAll);
    printf("nWords: %d\n", lpCom->nWords);
    printf("lpData: %lx\n", (long) lpCom->lpData);
    printf("szAdr:  %Fs\n", lpCom->szAdr);
    printf("nOff:   %d\n", lpCom->nOff);
    printf("nBit:   %d\n", lpCom->nBit);
    printf("szXAdr: %Fs\n", lpCom->szXAdr);

    #endif


    return(0);
}


/*=====================================================================*\
|									|
|   ERWEITERTE FUNKTIONEN						|
|									|
\*=====================================================================*/

/***********************************************************************\
***  DrvInit							      ***
***	  Wird beim Starten des	TSR's gerufen                         ***
***								      ***
***	  -ret:	    frei					      ***
***								      ***
\***********************************************************************/
int DrvInit (void)
{

    printf("DrvInit\n");

    //sprintf(szHelp, "SA=%d/RC=%d/TT=%d/TE=%d/TQ=%d", nSA, nRC, nTT, nTE, nTQ);

	memset(ReadBuf,0,sizeof(ReadBuf));

    return(0);
}

/***********************************************************************\
***  DrvExit							      ***
***	  Wird beim Beenden des	TSR's gerufen                         ***
***								      ***
\***********************************************************************/
void DrvExit (void)
{
    printf("DrvExit\n");
    #ifdef TOLOG
    add_log("DrvExit function called");
    #endif
}

/***********************************************************************\
***  VPInit							      ***
***	  Wird beim Initialisieren von VisiPro gerufen		      ***
***								      ***
\***********************************************************************/
void VPInit (void)
{
    printf("VPInit\n");
    #ifdef TOLOG
    add_log("VPInit function called");
    #endif
}

/***********************************************************************\
***  VPStart							      ***
***	  Wird vor dem 1. Zyklus von VisiPro gerufen		      ***
***								      ***
\***********************************************************************/
void VPStart (void)
{
    printf("VPStart\n");
    #ifdef TOLOG
    add_log("VPStart function called");
    #endif

}

/***********************************************************************\
***  VPExit							      ***
***	  Wird beim Beenden von	VisiPro	gerufen			      ***
***								      ***
\***********************************************************************/
void VPExit (void)
{
    printf("VPExit\n");
    #ifdef TOLOG
    add_log("VPExit function called");
    #endif
}

/***********************************************************************\
***  VPDevCount							      ***
***	  VisiPro meldet die Anzahl aller angelegten		      ***
***	  Kommunikationsobjekte, falls der Treiber danach Speicher    ***
***	  von VisiPro anfordern	will, kann als R�ckgabe	die Gr��e     ***
***	  des anzufordernden Speicher in KByte angegeben werden.      ***
***	  Den Zeiger auf den angelegten	Speicher erh�lt	man durch     ***
***	  'VPAlloc'						      ***
***								      ***
***	  nCount:   Anzahl Kommunikationsobjekte		      ***
***								      ***
***	  -ret:	    0: es wird kein Speicher von VP ben�tigt	      ***
***		    n: es werden n-KBytes Speicher in VP angelegt     ***
***								      ***
\***********************************************************************/
int VPDevCount (int nCount)
{
    int nKByte;


    // 5 K mehr zur Sicherheit, weil Jens nicht wei� was er tut
    nKByte = (int) (((long) nCount * (long) sizeof(EXT_DEV)) / 1024L + 5L);
	#ifdef TOLOG
    sprintf(txtbuffer, "VPDevCount will %d KByte f�r %d Objekte\n", nKByte,nCount);
    add_log(txtbuffer);
    #endif

    return(nKByte);
}

/***********************************************************************\
***  VPAlloc							      ***
***	  Wird mit 'VPDevCount'	Speicher von VisiPro angefordert,     ***
***	  erh�lt man den Zeiger	darauf.				      ***
***	  Achtung: Zeiger wird nach 'VPExit' ung�ltig!		      ***
***								      ***
***	  lpDrvMem: NULL - kein	Speicher vorhanden		      ***
***		    sonst - Zeiger auf VP Speicher		      ***
***								      ***
\***********************************************************************/
//  Wird mehrfach aufgerufen wenn mehr als 64 K gebraucht werden!
void VPAlloc (char huge	*lpDrvMem)
{
    printf("VPAlloc: \n");
    printf("lpDrvMem: %lx\n", (long) lpDrvMem);
    #ifdef TOLOG
    add_log("VPAlloc function called");
    #endif

    hpData[nDataCount] = (LP_EXT_DEV) lpDrvMem;


    if (hpData[nDataCount] == NULL)
    {
    	// kein Speicher f�r Treiber
		#ifdef TOLOG
		add_log("kein Speicher mehr in weiteren 64 KB Segmenten");
		#endif
		// --> hier Fehler ausgeben!
    }
	// Die folgende Variable wei� wie viele Speicherbl�cke zu 64 k ich habe (Achtung die letzten 14 Byte sind nix)
    nDataCount++;		//n�chster Block wurde von VWD angelegt


}

/***********************************************************************\
***  VPNextDrv							      ***
***	  Vor Beginn des VisiPro-Zyklus	erh�lt man nacheinander	      ***
***	  alle in VisiPro angelegten Kommunikationsobjekte	      ***
***								      ***
***	  lpCom:    �bergabestruktur				      ***
***		    in ->nAll steht Attribut (0: Lesen .. 3:1xLesen)  ***
***								      ***
\***********************************************************************/
void VPNextDev (LP_DEV_COM lpCom)
{
	int nDevice = 0, ind=0;


    printf("VPNextDev: \n");
    printf("nAll:   %d\n", lpCom->nAll);
    printf("nWords: %d\n", lpCom->nWords);
    printf("lpData: %lx\n", (long) lpCom->lpData);
    printf("szAdr:  %Fs\n", lpCom->szAdr);
    printf("nOff:   %d\n", lpCom->nOff);
    printf("nBit:   %d\n", lpCom->nBit);
    printf("szXAdr: %Fs\n", lpCom->szXAdr);

    //add_log("VPNextDev function called");

}

/***********************************************************************\
***  VPCycle							      ***
***	  nach jedem VisiPro-Zyklus wird diese Funktion	gerufen	      ***
***								      ***
\***********************************************************************/
void VPCycle (void)
{
	#ifdef AutoConnect
	int nd, ind;
	#endif

     printf("VPCycle\n");

}

/***********************************************************************\
***  VPPicture							      ***
***	  bei jedem Bildwechsel	wird diese Funktion gerufen	      ***
***								      ***
\***********************************************************************/
void VPPicture (void)
{
    printf("VPPicture\n");
    #ifdef TOLOG
    add_log("VPPicture function called");
    #endif

}

/***********************************************************************
* EIGENE FUNKTIONEN
***********************************************************************/


/***********************************************************************\
***  add_log					      ***
***	  Macht Protokolleintr�ge	      ***
***								      ***
\***********************************************************************/

void add_log (char *txt)
{
    FILE    *stream;

    if ((stream = fopen("drtest.log", "ab")) == 0)
    {
		printf("******************Cannot open file **************************");
        return;
    }

    fwrite(txt, sizeof(char), _fstrlen(txt), stream);
    fwrite("\r\n", sizeof(char), 2, stream);

    fclose(stream);
}


