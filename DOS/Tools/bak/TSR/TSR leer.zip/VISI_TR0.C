/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    - datum	   : 22.10.1990
    - programm	   : visipro treiberschnittstelle
    - modulname	   : /
    - autor	   : p.tanneberg
    - version	   : 1.0;
    - revision	   : /
    - flussplan	   : /
    - beschreibung :
    - routinen	   : /
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
#include <time.h>
#include <dos.h>
#include <bios.h>
#include <stdlib.h>
#include <stdio.h>
#include <conio.h>
#include <ctype.h>
#include <stdlib.h>
#include <math.h>
#include <malloc.h>
#include <string.h>
#include "visi_trx.h"

/***	Achtung, hier Compiler aussuchen    ***/
#define	MSC_BOR	      0	    /*	  (0: Microsoft, 1: Borland)  */

#define	begin	{
#define	end	}

/*----------------------------------------------------------------------*/


#define	HEAP_FREI 6144		   /* 4	KByte auf dem Heap Platz lassen	*/

#define	TRUE  1			    /* Konstanten zur Arbeit mit BOOL */
#define	FALSE 0

#define	NO_END_FKT ((void (*)(void)) -1)  /* keine Endefunktion	aufr. */


/*-------------------------- Globale Variablen ----------------------------*/



/*== Typedefs ========================================================*/

typedef	unsigned char BYTE;		  /* wir basteln uns ein Byte */
typedef	unsigned int WORD;
typedef	BYTE BOOL;			     /*	wie BOOLEAN in Pascal */

/*== Makros ==========================================================*/

#ifndef	MK_FP			 /* wurde MK_FP	noch nicht definiert? */
#define	MK_FP(seg, ofs)	((void far *) ((unsigned long) (seg)<<16|(ofs)))
#endif

/*== Einbindung	der Funktionen aus dem Assembler-Modul ===============*/

char id_string[20] = "VisiTrx";


extern int is_inst(char	*, int);
extern void uninst(void	(*)(void), int);
extern void tsr_init(int, int (*)(), int, int, char *, int);
int far tsr(int, int, int, int);
int ems_inst(void);
void fl2string (float val, char **newstring);
char string2val (char *txt, float *val);
void int2string	(int val, char **newstring);

int nLog, nIrq, nPort, CallCnt;
int nTOut;
long lBaudRate;
long v24inc;
volatile long lRTSoffTime=0;
unsigned int v24t_start;
long testcount;

/****************************************************************************
   - datum	       :      7.1.91
   - name	       :      tsr_interrupt()
   - funktion	       :
   - programmierer     :      p.tanneberg
   - eingangsparameter :      \
   - ausgangsparameter :      \
*****************************************************************************/
int far tsr(ax_reg,	bx_reg,	cx_reg,	dx_reg)
int ax_reg, bx_reg, cx_reg, dx_reg;
{
    char    far	*lpC;

    lpC	= MK_FP(bx_reg,	cx_reg);

	//Simmler Test 1C Interrupt:
	if (CallCnt > nPort)
	{
		
		for (testcount=0; testcount>100000; testcount++)
			CallCnt = 0;  	
		//printf("T\n"); 
		
	}          
	else
		CallCnt++;
	
    return(ax_reg);




    //	was will VP
    switch (ax_reg) {
	case 2:	    //	Lesen von Daten
	    ax_reg = VPRead((LP_DEV_COM) lpC);
	    break;

	case 3:	    //	Schreiben von Daten
	    ax_reg = VPWrite((LP_DEV_COM) lpC);
	    break;

	case 5:	    //	der Treiber ist	am Ende
	    DrvExit();
	    ax_reg = 0;
	    break;

	case 6:	    //	VisiPro	ist noch ganz am Anfang
	    VPInit();
	    ax_reg = 0;
	    break;

	case 7:	    //	VisiPro	Zyklus
	    VPCycle();
	    ax_reg = 0;
	    break;

	case 8:	    //	VisiPro	Auftragsnummer
        ax_reg = VPDevCount(bx_reg);
	    break;

	case 9:	    //	VisiPro	Speicher
				//  Wird mehrfach aufgerufen wenn mehr als 64 K gebraucht werden
	    VPAlloc((char huge *) lpC);
	    ax_reg = 0;
	    break;

	case 10:    //	VisiPro	Auftragseingang
	    VPNextDev((LP_DEV_COM) lpC);
	    ax_reg = 0;
	    break;

	case 11:    //	VisiPro	ist am Ende
	    VPExit();
	    ax_reg = 0;
	    break;

	case 12:    //	Bildwechsel
	    VPPicture();
	    ax_reg = 0;
	    break;

	case 13:    //	Start Zyklus
	    VPStart();
	    ax_reg = 0;
	    break;

	default:    //	???
	    ax_reg = 0;
    }

    return(ax_reg);
}


#ifdef TEST_CYC


/*=====================================================================*\
|																		|
|   T E S T  A L S  Z Y K L I S C H E S   P R O G R A M M 			    |
|																		|
\*=====================================================================*/
void main(argc,	argv)
int	argc;
char	*argv[];
{
    int nRet;
    float i;
    int i2;
    long int i3;
    int huge *hp;
    DEV_COM sDevCom;
    int w0,w1,w2, w0x[16];
    char *newstring2, fl, txt2[10];
    newstring2 = &(txt2[0]);

	//�bergabeparameter auswerten
	if (argc >= 3)
		nPort = atoi(argv[2]);
	else
		nPort = 1;
	if (argc >= 4)
		nIrq = atoi(argv[3]);
	else
		nIrq = 4;
	if (argc >= 5)
		lBaudRate = atol(argv[4]);
	else
		lBaudRate = 9600L;
    if (argc >= 6)
        nTOut = atoi(argv[5]);  //in 1/18 tel sec
    else
        nTOut = 9;


    nRet = DrvInit();

    nRet = VPDevCount(3);   /*VWD sagt wieviele Objekte es hat, dann berechne ich den Speicher dazu*/

    /*VWD allokiert selbst*/
    hp = (int huge *)_fmalloc(nRet * 1024);		/*Faustformel: Je Objekt 1 kByte*/
    printf("Es soll %d KByte allokiert werden\n",nRet);

    VPAlloc((char huge *)hp);

	/* Jedes Objekt ein mal bearbeiten: was soll ich tun? lesen, GetOV,???, Fragen ob es �berhaupt gibt?? */

    sDevCom.nAll = 2;               //  Nummer des Treibers oder R/W/K/1
    sDevCom.nWords = 1;             //  Anzahl zu �bermittelner Datenw�rter
    sDevCom.lpData = (int far *)&w0;        //  Zeiger auf Datenziel- bzw. quelle
    sDevCom.szAdr[0] = '@';         //  ASCII SPS-Adresse
    sDevCom.nOff = 0;               //  Offset auf SPS-Adresse
    sDevCom.nBit = 0;               //  Bitnummer (-1 bei Worten)
    _fstrcpy(sDevCom.szXAdr,"010000SA");	//ADD=01; 1 Kanal; SA = Solltemperatur
    VPNextDev(&sDevCom);

    sDevCom.nAll = 2;               //  Nummer des Treibers oder R/W/K/1
    sDevCom.nWords = 1;             //  Anzahl zu �bermittelner Datenw�rter
    sDevCom.lpData = (int far *)&w1;        //  Zeiger auf Datenziel- bzw. quelle
    sDevCom.szAdr[0] = '@';         //  ASCII SPS-Adresse
    sDevCom.nOff = 0;               //  Offset auf SPS-Adresse
    sDevCom.nBit = 0;               //  Bitnummer (-1 bei Worten)
    _fstrcpy(sDevCom.szXAdr,"010000CO");	//ADD=01; 1 Kanal, CO = Controller output
    VPNextDev(&sDevCom);

    sDevCom.nAll = 2;               //  Nummer des Treibers oder R/W/K/1
    sDevCom.nWords = 1;             //  Anzahl zu �bermittelner Datenw�rter
    sDevCom.lpData = (int far *)&w2;        //  Zeiger auf Datenziel- bzw. quelle
    sDevCom.szAdr[0] = '@';         //  ASCII SPS-Adresse
    sDevCom.nOff = 0;               //  Offset auf SPS-Adresse
    sDevCom.nBit = 0;               //  Bitnummer (-1 bei Worten)
    _fstrcpy(sDevCom.szXAdr,"010000PY");		//ADD=01; 1 Kanal; PV=Istwert
    VPNextDev(&sDevCom);


    VPStart();  					// Jetzt startet VisiPro

    /*Ein Leseauftrag: */
    sDevCom.nAll = 2;               //  Nummer des Treibers oder R/W/K/1
    sDevCom.nWords = 18;             //  Anzahl zu �bermittelner Datenw�rter
    sDevCom.lpData = (int far *)&w0x;        //  Zeiger auf Datenziel- bzw. quelle
    sDevCom.szAdr[0] = '@';         //  ASCII SPS-Adresse
    sDevCom.nOff = 0;               //  Offset auf SPS-Adresse
    sDevCom.nBit = 0;               //  Bitnummer (-1 bei Worten)
    _fstrcpy(sDevCom.szXAdr,"010000SA");

    VPRead(&sDevCom);
    printf("w0 ist: %Fd\n",w0);

	/*Ein Schreibauftrag:*/
    w0 = 32767;
    sDevCom.nAll = 2;               //  Nummer des Treibers oder R/W/K/1
    sDevCom.nWords = 1;             //  Anzahl zu �bermittelner Datenw�rter
    sDevCom.lpData = (int far *)&w0;        //  Zeiger auf Datenziel- bzw. quelle
    sDevCom.szAdr[0] = '@';         //  ASCII SPS-Adresse
    sDevCom.nOff = 0;               //  Offset auf SPS-Adresse
    sDevCom.nBit = 0;               //  Bitnummer (-1 bei Worten)
    _fstrcpy(sDevCom.szXAdr,"010000PV");

    //VPWrite(&sDevCom);
	//printf("w0 ist: %Fd\n",w0);

    //VPRead(&sDevCom);
	//printf("w0 ist: %Fd\n",w0);

    VPCycle();

    DrvExit();

    _ffree(hp);

    printf(" ...Programm wurde als normales exe ausgefuehrt.\n ");


}




#else


/*=====================================================================*\
|																		|
|   A L S  T S R    P R O G R A M M 			    					|
|																		|
\*=====================================================================*/
/*============================================================================

		MM   MM	   AAA	  II	NN   N
		M M M M	  A   A	  II	N N  N
		M  M  m	  AAAAA	  II	N  N N
		M     M	  A   A	  II	N   NN

============================================================================*/
void main(argc,	argv)
int	argc;
char	*argv[];
{
	int	nr, i_vek, status;
	union REGS i_regs, o_regs;
	int testvar=1;

	printf("*******************************************\n");
	printf("* Resident Driver for IRQ Test            *\n");
	printf("*  V 0.0 by  B&R                          *\n");
	printf("* A-5142 Eggelsberg 120                   *\n");
	printf("* Tel.: 07748 - 6586                      *\n");
	printf("*******************************************\n");


	if (argc >= 2) {
		/***	Hilfe?	***/
		if ((argv[1][0]	== '?')	|| (argv[1][1] == '?'))	 {
			printf("* DRIVER-CALL:                            *\n");
			printf("*  DRTEST [a b c d e f]                   *\n");
			printf("*                                         *\n");
			printf("*  a: (1 - 5) - VisiPro(c) Drivertype     *\n");
			printf("*  b: COM Port (1)					      *\n");
			printf("*  c: IRQ (4)						      *\n");
			printf("*  c: Baudrate (default 9600)		      *\n");
			printf("*  d: Serial Timeout 1/18 sec		      *\n");
			printf("*******************************************\n");
			return;
		}

		//i_vek =	0x65 + atoi(argv[1]);
		i_vek =	0x1c;

		/***	Konflikt mit EMS?	***/
		if ((i_vek == 0x67) && ems_inst()) {
			printf("* Use of Universal 2 and EMS-manager      *\n");
			printf("* at the same time not allowed            *\n");
			printf("* DRIVER not installed!                   *\n");
			printf("* Use Universal 3 to 5!                   *\n");
			printf("*******************************************\n");
			return;
		}

		//if ((i_vek < 0x66) || (i_vek > 0x6a))
		//	i_vek =	0x66;
	}
	else {
		//i_vek =	0x66;
		i_vek =	0x1c;
	}

    //Check input arguments:
	if (argc >= 3)
		nPort = atoi(argv[2]);
	else
		nPort = 1;
	if (argc >= 4)
		nIrq = atoi(argv[3]);
	else
		nIrq = 4;
	if (argc >= 5)
		lBaudRate = atol(argv[4]);
	else
		lBaudRate = 9600L;
    if (argc >= 6)
        nTOut = atoi(argv[5]);	//in 1/18 tel sec
    else
        nTOut = 9;
	if (argc >= 7)           	//Logfile
		nLog = atoi(argv[5]);
	else
		nLog = 0;

	if (is_inst(id_string, i_vek)) {
		/***	Im Speicherresidenten Programm Exit aufrufen	***/
		i_regs.x.ax  = 5;
		int86(i_vek, &i_regs, &o_regs);

		printf("* DRIVER is deinstalled                   *\n");
		printf("*******************************************\n");
		uninst(NO_END_FKT, i_vek);
		return;
	}

	if ((status = DrvInit()) < 0) {
		printf("* DRIVER not installed, Error!            *\n");
		printf("*******************************************\n");
		return;
	}

	printf("* DRIVER is installed as UNIVERSAL %d!*\n", i_vek-0x65);
	printf("*******************************************\n");
	tsr_init(MSC_BOR, tsr, nr, HEAP_FREI, id_string, i_vek);
}                


int ems_inst(void)
{
	static char emm_name[] = { 'E',	'M', 'M', 'X', 'X', 'X', 'X', '0' };
	union REGS regs;	/* Prozessorregister f�r den Interruptaufruf */
	struct SREGS sregs;	/* Segmentregister f�r den Interrupt-Aufruf */
	int	i;		/* Schleifenz�hler */
	char	far *emm_inspect; /* Pointer auf den Namen im Interrupt-Handler	*/

	/*-- Pointer auf Namen im Kopf eines Ger�te-Treibers aufbauen ------*/
	regs.x.ax = 0x3567;	     /*	Fkt.nr.: Interruptvektor 0x67 holen */
	intdosx(&regs, &regs, &sregs);	 /* den	DOS-Interrupt 0x21 aufrufen */
	emm_inspect = (char far	*) MK_FP(sregs.es, 10);	    /* Pointer aufbauen	*/

	/*-- nach dem Namen des	EMS-Treibers suchen ------------------------*/
	for(i =	0; i < sizeof(emm_name)	&& (*(emm_inspect++) ==	emm_name[i++]);	)
		;
	return(i == sizeof(emm_name));	       /* TRUE,	wenn Name gefunden */
}

#endif
