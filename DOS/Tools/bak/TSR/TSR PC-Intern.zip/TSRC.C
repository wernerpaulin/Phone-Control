/**********************************************************************/
/*                               T S R C                              */
/*--------------------------------------------------------------------*/
/*    Aufgabe        : C-Modul, das mit Hilfe eines Assembler-Moduls  */
/*                     in ein TSR-Programm verwandelt wird            */
/*--------------------------------------------------------------------*/
/*    Autor          : MICHAEL TISCHER                                */
/*    entwickelt am  : 15.08.1988                                     */
/*    letztes Update : 19.11.1991                                     */
/*--------------------------------------------------------------------*/
/*    Speichermodell : SMALL                                          */
/**********************************************************************/


/*== Include-Dateien einbinden =======================================*/

#include <stdlib.h>
#include <stdio.h>

#include <dos.h>
#include <conio.h>
#include <string.h>
    
    
/*== Typedefs ========================================================*/
                                                                        
typedef unsigned char BYTE;               /* wir basteln uns ein Byte */
typedef unsigned int WORD;
typedef BYTE BOOL;                           /* wie BOOLEAN in Pascal */

typedef void (*OAFP)(void);    /* Zeiger auf Funktion  ohne Argumente */
typedef void (*SHKFP)( WORD KeyMask, BYTE ScCode );   /* TsrSetHotkey */



/*== Einbindung der Funktionen aus dem Assembler-Modul ===============*/

extern void TsrInit( BOOL tc, void (*fkt)(void), unsigned heap );

extern BOOL TsrIsInst( BYTE i2F_fktnr );
extern void TsrUnInst( void );
extern OAFP TsrSetPtr( void far *fkt );
extern BOOL TsrCanUnInst( void );
extern void TsrCall( void );
extern void far TsrSetHotkey( WORD keymask, BYTE sccode );

/*== Konstanten und Makros ===========================================*/
                                                                        
#ifdef __TURBOC__                     /* wird mit TURBO-C compiliert? */
  #include <alloc.h>
  #define TC TRUE                                               /* Ja */
#else                           /* es wird mit Microsoft C gearbeitet */
  #include <malloc.h>
  #define TC FALSE
#endif

                                                                        
#define I2F_CODE   0xC4                     /* Funktionsnummer INT 2F */
#define I2F_FKT_0  0xAA                /* Code f�r INT 2F, Funktion 0 */
#define I2F_FKT_1  0xBB                /* Code f�r INT 2F, Funktion 1 */

                                                                        
#define HEAP_FREI 1024           /* 1 KByte auf dem Heap Platz lassen */
                                                                        
#define TRUE  ( 0 == 0 )            /* Konstanten zur Arbeit mit BOOL */
#define FALSE ( 0 == 1 )

/*== globale Variablen ===============================================*/
                                                                        


/* WePa-Testvariablen */
int TsrScanTime=1000,
    TsrTimer=0,
    TsrDelayTime=0;   

    
unsigned long alive=0;

                                                                        
/***********************************************************************
*  Funktion         : E N D F K T                                      *
**--------------------------------------------------------------------**
*  Aufgabe          : Wird bei der Reinstallation des TSR-Programms    *
*                     aufgerufen.                                      *
*  Eingabe-Parameter: keiner                                           *
*  Return-Wert      : keiner                                           *
*  Info             : Dieser Prozedur mu� FAR sein, damit sie in der   *
*                     bereits installierten Kopie des TSR-Programms    *
*                     aufgerufen werden kann.                          *
***********************************************************************/
                                                                        
void far endfkt( void )
{
 /*-- die allokierten Puffer wieder freigeben ------------------------*/
                                                                       
 printf("Das TSR-Programm wurde %u mal aktiviert.\n", alive);
}
                                                                        
/***********************************************************************
*  Funktion         : T S R                                            *
**--------------------------------------------------------------------**
*  Aufgabe          : nur zum testen                                   *
*  Eingabe-Parameter: keiner                                           *
*  Return-Wert      : keiner                                           *
***********************************************************************/
                                                                        
void tsr(void)
{
 if ( (TsrTimer+=55) >= (TsrScanTime+TsrDelayTime) )    /* 55ms = int08-cycle time in dos */
   { 
    alive++;
    TsrTimer -= (TsrScanTime+TsrDelayTime);      /* reset timer */
	TsrDelayTime = 0; 
    
    printf("%u Hi, I am still alive !!! \n", alive);
   }                     

  //that's all
}
                                                                        
/**********************************************************************/
/* GetHeapEnd: Ermittelt das aktuelle Ende des Heps in Abh�ngigkeit   */
/*             des Compilers                                          */
/* Eingabe : keine                                                    */
/* Ausgabe : Zeiger auf das erste Byte hinter dem Ende des belegten   */
/*           Heaps                                                    */
/**********************************************************************/

void far *GetHeapEnd( void )
{
 #ifdef __TURBOC__                                        /* TurboC ? */
   return (void far *) sbrk(0);
 #else                                                   /* Nein, MSC */
   struct _heapinfo hi; /* Stuktur mit Informatioen �ber Heap-Eintrag */
   unsigned heapstatus;                     /* Status von _heapwalk() */
   void far *letzter;            /* Zeiger auf letzten belegten Block */

   hi._pentry = NULL;                       /* am Heap-Start anfangen */

   /*-- Heap bis zum letzten Block durchlaufen -----------------------*/

   while( (heapstatus = _heapwalk( &hi )) != _HEAPEND )
    if ( hi._useflag == _USEDENTRY )                 /* Block belegt? */
     letzter = (void far *) ((BYTE far *) hi._pentry + hi._size + 1);

   return letzter;
 #endif
}



/**********************************************************************/
/**                           HAUPTPROGRAMM                          **/
/**********************************************************************/
void main( int argc, char *argv[] )
{
 printf("MKey-Test TSR by PAULIN Werner \n");

 /*-- Kommandozeilen-Parameter waren o.k. ----------------------------*/

 if ( !TsrIsInst( I2F_CODE ))        /* Programm bereits installiert? */
  {                                                           /* Nein */
   printf( "Das TSR-Programm wurde installiert.\n" );

   TsrInit( TC, tsr, HEAP_FREI );        /* das Programm installieren */
  }
 else                             /* Programm war bereits installiert */
  {                                                             /* JA */
   if ( TsrCanUnInst() )
    {
     (*(OAFP) TsrSetPtr(endfkt))();
     TsrUnInst();
     printf( "Das Programm wurde erfolgreich reinstalliert.\n" );
    }
   else
     printf( "Das Programm kann nicht reinstalliert werden.\n" );
  }
}
