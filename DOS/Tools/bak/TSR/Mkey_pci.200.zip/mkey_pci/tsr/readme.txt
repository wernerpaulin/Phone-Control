********************** Backup-Stufen von tsrca.asm **********************

tsrca01.zip ...TSR h�ngt am Interrupt 0x08 (0x1C weiterhin eingeh�ngt, aber ohne Funktion
               (nur alter H�ndler))
