/////////////
// Include BLKCPY.H

//////////////
//	Defines
#define ESC				0x1b
#define INT_OFFS        0xE0008L
#define IRQ4_OFFS       0xE000EL
#define INTEN_OFFS		0xE0000L
#define INT_IRQ4_LEN	2L
#define PRINT_VERSION() cprintf("BLOCKCOPY Version 1.00 (Sept 30 1997) (C) B&R 1997 (NW)\n\r")

///////////////////////////
// Funktionsdeklarationen
//extern void	_interrupt My_IntHandler(void);

extern ILONG LS251_open(void);
extern void LS251_close (void);
extern int LS251_write (PTR pBuffer, unsigned int *BufferLen);
extern int LS251_read (PTR pBuffer, unsigned int *BufferLen);
extern int LS251_matrix (void);

// LS251 communication error codes
// LS251 communication base code
#define ERR_LS251		4800

#define ERR_LS251_OUTOF_MEMORY		ERR_LS251 + 1
#define ERR_LS251_NOT_FOUND1		ERR_LS251 + 2
#define ERR_LS251_NOT_FOUND2		ERR_LS251 + 3
#define ERR_LS251_INV_TXLEN			ERR_LS251 + 4
#define ERR_LS251_INV_COMMMEM		ERR_LS251 + 5
#define ERR_LS251_ILL_SETUP			ERR_LS251 + 6
#define ERR_LS251_SEND				ERR_LS251 + 7
#define ERR_LS251_INV_REGMEM		ERR_LS251 + 8
