/*
*$doc$b***********************************************************************
*                                                                            *
*	 COPYRIGHT    BERNECKER + RAINER Industrie-Elektronik Ges.m.b.H          *
*                                                                            *
******************************************************************************
*                                                                            *
*      Projekt :  DSF		                                                 *
*  Teilprojekt :  DEFS	                                                     *
*        Modul :  types.h													 *
*                                                                            *
*     Revision :  01.00                                                      *
*        Datum :  94/07/04                                                   *
*        Autor :  Thomas Spiessberger / SpT                                  *
*                                                                            *
*----------------------------------------------------------------------------*
*                                                                            *
*     Funktion :  Allgemeine Definitionen fuer das B&R Netzwerk NET2000.	 *
*                                                                            *
*                                                                            *
*                                                                            *
******************************************************************************
*                                                                            *
*  Revision Report :                                                         *
*                                                                            *
*  Rev.   Datum     Name  Kommentar                                          *
*  --------------------------------------------------------------------------*
*                                                                            *
*                                                                            *
***********************************************************************$doc$e*
*/

/**************************** CONSTANTS *************************************/


/********************** STRUCTURE DEFINITIONS *******************************/

typedef char int8;
typedef int int16;
typedef long int32;
typedef unsigned char u_int8;
typedef unsigned int u_int16;
typedef unsigned long u_int32;


/*********** VARIABLES ( sequence : extern, global, local ) *****************/


/************************* GLOBAL FUNCTIONS *********************************/
