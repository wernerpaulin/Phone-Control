/*****************************************************************************/
/*   Copyright:  1999  B&R Austria - Perfection in Automation                */
/*---------------------------------------------------------------------------*/
/*     THIS SOFTWARE IS THE PROPERTY OF B&R AUSTRIA: ALL RIGHTS RESERVED.    */
/*     NO PART OF THIS SOFTWARE MAY BE USED OR COPIED IN ANY WAY WITHOUT     */
/*              THE PRIOR WRITTEN PERMISSION OF B&R AUSTRIA.                 */
/*---------------------------------------------------------------------------*/
/*   Identification:                                                         */
/*       ID-Nr.    xxxxxxx                                                   */
/*       System    xxxxxxx                                                   */
/*       PCC       xxxx                                                      */
/*       Purpose   TSR to call the LS251-Key-Manager cyclic                  */
/*       Filename  mkey_pci.c                                                */
/*---------------------------------------------------------------------------*/
/*   History                                                                 */
/*   Version     Datum       Autor                                           */
/*   02.00       26.07.99    W. Paulin		adapted from Tischer Michael	 */
/*                                          (PC-Intern - Demo 19.11.91)	     */
/*   02.01       27.07.99    W. Paulin		merged with TSR from Enzinger Th.*/
/*   02.02       30.07.99    W. Paulin		connection to NET2000-driver     */
/*																			 */
/*---------------------------------------------------------------------------*/
/*   Discription:                                                            */
/*               This TSR hook on the interrupt 0x1C in order to supervise   */ 
/*               the NET2000-driver (alive-IRQ). If the NET2000-driver is    */
/*               blocked for some reason (no refresh of VisiEinDos database) */
/*               this driver will wake up the NET2000-driver in order to     */
/*               do just the LS251_matrix()-function, which reads and writes */
/*               Date to the DPR.   										 */
/*---------------------------------------------------------------------------*/
/* 	 Interfaces:                                                             */
/*              Interrupt 0x1C (Be AWARE that this INTERRUPT is hard coded in*/
/*              the assembler programm)			    						 */
/*              configurable Universal-Interface to NET2000-driver           */
/*****************************************************************************/


/*== Include-Dateien einbinden =======================================*/

#include <stdlib.h>
#include <stdio.h>

#include <dos.h>
#include <conio.h>
#include <string.h>
    
    
/*== Typedefs ========================================================*/
                                                                        
typedef unsigned char BYTE;               /* wir basteln uns ein Byte */
typedef unsigned int WORD;

typedef BYTE BOOL;                           /* wie BOOLEAN in Pascal */

typedef void (*OAFP)(void);    /* Zeiger auf Funktion  ohne Argumente */
typedef void (*SHKFP)( WORD KeyMask, BYTE ScCode );   /* TsrSetHotkey */



/*== Einbindung der Funktionen aus dem Assembler-Modul ===============*/

extern void TsrInit( BOOL tc, void (*)(int, int, int, int), unsigned heap );
extern BOOL TsrIsInst( BYTE i2F_fktnr );
extern void TsrUnInst( void );
extern OAFP TsrSetPtr( void far *fkt );
extern BOOL TsrCanUnInst( void );
extern void TsrCall( void );
extern void far TsrSetHotkey( WORD keymask, BYTE sccode );

/*== Konstanten und Makros ===========================================*/
                                                                        
#ifdef __TURBOC__                     /* wird mit TURBO-C compiliert? */
  #include <alloc.h>
  #define TC TRUE                                               /* Ja */
#else                           /* es wird mit Microsoft C gearbeitet */
  #include <malloc.h>
  #define TC FALSE
#endif

                                                                        
#define I2F_CODE   0xC4                     /* Funktionsnummer INT 2F */
#define I2F_FKT_0  0xAA                /* Code f�r INT 2F, Funktion 0 */
#define I2F_FKT_1  0xBB                /* Code f�r INT 2F, Funktion 1 */
#define I2F_FKT_2  0xCC                /* Code f�r INT 2F, Funktion 2 (Timer-Reset ausgel�st druch NET2000-TSR) */

                                                                        
#define HEAP_FREI 1024           /* 1 KByte auf dem Heap Platz lassen */

#ifndef TRUE                                                                        
#define TRUE  ( 0 == 0 )            /* Konstanten zur Arbeit mit BOOL */
#endif

#ifndef FALSE
#define FALSE ( 0 == 1 )
#endif
        
        
/* MKey_PCI-TSR only */        

#define MIN_SCAN_TIME       200
#define MAX_SCAN_TIME      2000
#define DEF_SCAN_TIME       500
#define DEF_ACTIVATE_DELAY 0 

#define DEF_UNIVERSAL_TYP_NET2000    1               /* default: Universal 1 als VisiWinDos-Treibertyp         */
#define BASE_IVEK_NET2000         0x65               /* Basis-Interrupt-Vektor f�r NET2000:                    */
													 /*	iVekN2 = BASE_IVEK_NET2000 + DEF_UNIVERSAL_TYP_NET2000 */ 
													 
#define RESET_TIMER_FLAG	0xCC    				 /* Wert der in ax und bx gesetzt werden muss um Reset des Timers auszul�sen */


/*== globale Variablen ===============================================*/
int TsrScanTime=DEF_SCAN_TIME,
    TsrTimer=0,
    TsrEnable=0,
    TsrDelayTime=0,
    ActivateDelay=DEF_ACTIVATE_DELAY,
    UnivTypNet2000=DEF_UNIVERSAL_TYP_NET2000,
    iVekN2=0;
                                                                        
            
/* Debug-Variablen */            
int alive=0;

                                                                        
/***********************************************************************
*  Funktion         : E N D F K T                                      *
**--------------------------------------------------------------------**
*  Aufgabe          : Wird bei der Reinstallation des TSR-Programms    *
*                     aufgerufen.                                      *
*  Eingabe-Parameter: keiner                                           *
*  Return-Wert      : keiner                                           *
*  Info             : Dieser Prozedur mu� FAR sein, damit sie in der   *
*                     bereits installierten Kopie des TSR-Programms    *
*                     aufgerufen werden kann.                          *
***********************************************************************/
                                                                        
void far endfkt( void )
{
 /*-- die allokierten Puffer wieder freigeben ------------------------*/

 printf("           All done bye, bye \n"
        "   The MKEY-PCI-Driver is now removed !\n");
 printf("        I was %d times activated\n", alive);

}
                                                                        
/***********************************************************************
*  Funktion         : MKEY_PCI - TSR                                   *
**--------------------------------------------------------------------**
*  Aufgabe          : aktiviert LS251_matrix()-Funktion im NET2000-TSR *
*  Eingabe-Parameter: ax, bx, cx, dx                                   *
*  Return-Wert      : keiner (void)                                    *
***********************************************************************/
                                                                        
void tsr(int ax_reg, int bx_reg, int cx_reg, int dx_reg)
{
 union REGS iRegs, oRegs;	/* register-types to call the timer interrupt to reset the timer tsr */

 if ( ax_reg==RESET_TIMER_FLAG && bx_reg==RESET_TIMER_FLAG )     
   {
 	TsrEnable    = 1;
	TsrTimer     = 0;
	TsrDelayTime = ActivateDelay;
   }

 if (!TsrEnable) return;


 if ( (TsrTimer+=55) >= (TsrScanTime+TsrDelayTime) )   /* 55ms = int08-cycle time in dos */
   { 
    alive++;

    TsrTimer -= (TsrScanTime+TsrDelayTime);      /* reset timer */
	TsrDelayTime = 0; 
    
    iRegs.x.ax  = 'n';
    iRegs.x.bx  = '2';
    
    iVekN2 = BASE_IVEK_NET2000 + UnivTypNet2000;  
      
    //printf("MKEY_PCI: about to wake up NET2000-TSR on IRQ %d...\n", iVekN2);
	int86( iVekN2 , &iRegs, &oRegs);            /* NET2000-Treiber aufrufen um LS251_matrix() auszuf�hren */
   }                     

  //that's all
}
                                                                        
/**********************************************************************/
/* GetHeapEnd: Ermittelt das aktuelle Ende des Heaps in Abh�ngigkeit  */
/*             des Compilers                                          */
/* Eingabe : keine                                                    */
/* Ausgabe : Zeiger auf das erste Byte hinter dem Ende des belegten   */
/*           Heaps                                                    */
/**********************************************************************/

void far *GetHeapEnd( void )
{
 #ifdef __TURBOC__                                        /* TurboC ? */
   return (void far *) sbrk(0);
 #else                                                   /* Nein, MSC */
   struct _heapinfo hi; /* Stuktur mit Informatioen �ber Heap-Eintrag */
   unsigned heapstatus;                     /* Status von _heapwalk() */
   void far *letzter;            /* Zeiger auf letzten belegten Block */

   hi._pentry = NULL;                       /* am Heap-Start anfangen */

   /*-- Heap bis zum letzten Block durchlaufen -----------------------*/

   while( (heapstatus = _heapwalk( &hi )) != _HEAPEND )
    if ( hi._useflag == _USEDENTRY )                 /* Block belegt? */
     letzter = (void far *) ((BYTE far *) hi._pentry + hi._size + 1);

   return letzter;

 #endif
}



/**********************************************************************/
/**                           HAUPTPROGRAMM                          **/
/**********************************************************************/
void main( int argc, char *argv[] )
{
 int i;
 char uninstall=0, unknown_argument=0 , invalid_argument=0;

 TsrScanTime    = DEF_SCAN_TIME;              /* default scan time when no parameter is set at the program start */
 UnivTypNet2000 = DEF_UNIVERSAL_TYP_NET2000;  /* default drivertyp for NET200 - Wake up feature (universal 1)    */
  
 printf("\n");
 printf("*******************************************\n");
 printf("* B&R MKEY-PCI-Driver                     *\n");
 printf("* V 2.02                                  *\n");
 printf("*******************************************\n\n");
 

 /* arguments available ? */
 if (argc > 1)
   {
   	/* loop through all arguments */
  	for (i=1 ; i < argc ; i++)
      {   
   	   if (argv[i][0] != '/')
   	     {
   		  printf("Sorry, but this argument is unknown: %s\n", &argv[i][0] );
   		  unknown_argument = 1;
   		 }
   	   else if (toupper(argv[i][1])=='R' && argv[i][2]==0)  /*   [/R]   */
   	  	 uninstall=1;
   	   else if (toupper(argv[i][1])=='S')  /*   [/S]   */
	   	 TsrScanTime = atoi( &argv[i][2] );
   	   else if (toupper(argv[i][1])=='D')  /*   [/D]   */
	     ActivateDelay = atoi( &argv[i][2] );
	   else if (toupper(argv[i][1])=='E')  /*   [/E]   */
	     TsrEnable = 1;
	   else if (toupper(argv[i][1])=='U')  /*   [/U]   */
	     UnivTypNet2000 = atoi( &argv[i][2] ); 

   	   else
   	  	 {
   		  printf("Sorry, but this argument is unknown: %s\n", &argv[i][0] );
   		  unknown_argument = 1;
   		 }
   	  }
   }    


 /*-- Uninstall TSR ----------------------------*/
 if (uninstall)
  {
   if ( !TsrIsInst( I2F_CODE ))        /* TSR already installed ? */
     {                                 /* NO */
  	  printf("Sorry - removing is not the right way, because it's not installed ! \n");
     }
   else
     {  
   	  if ( TsrCanUnInst() )
    	{
     	 (*(OAFP) TsrSetPtr(endfkt))();
     	 TsrUnInst();

 	 	 //look at end function... printf("All done bye, bye - the MKEY-PCI-Driver is now removed !\n");
		}
   	  else
  	 	printf("Sorry - Memory resident driver can not be removed (reboot system...) \n");
     }

   return; /* main() */
  }


 
 /*-- Check for missing arguments ----------------------------*/
 if ( TsrScanTime < MIN_SCAN_TIME || TsrScanTime > MAX_SCAN_TIME )
  {
   printf("Sorry - the Scantime has to be in a certain range: /S%d../S%d\n",MIN_SCAN_TIME, MAX_SCAN_TIME );
   invalid_argument = 1;
  }


 /*-- Show the user how to do it ----------------------------*/
 if (invalid_argument)
   {
 	printf("\n The valid range is: \n\n"
	       "  /Sxxxx  Scantime [ms] (/S%d../S%d), and by default = 500\n"
	       "\n",MIN_SCAN_TIME, MAX_SCAN_TIME);
		       
	return; /* main() */
   }	
 else if (unknown_argument)
   {
 	printf("\n Use one of the following arguments: \n\n"
	       "  /R      Remove memory resident driver\n"
	       "  /Sxxxx  Scantime [ms] (/S%d../S%d), default: 500\n"
	       "  /E      Enable driver immediately\n"
	       "  /U      (1 - 5) - VisiPro(c) driver typ, default: Universal 1 \n"
         /*"  /D      Activate-Delay, default = 2000\n"*/
	       "\n",MIN_SCAN_TIME, MAX_SCAN_TIME);
		       
	return; /* main() */
   }	

 
 /*-- It seems all is OK, let's install the driver  ----------------------------*/
 
 if ( !TsrIsInst( I2F_CODE ))        /* TSR already installed ? */
   {                                 /* NO */
    printf("The MKEY-PCI-Driver is now installed !\n"
	       "  - Scantime = %d ms\n" , TsrScanTime);
	printf("  - NET2000-driver expected on UNIVERSAL %d \n", UnivTypNet2000);

    TsrInit( TC, tsr, HEAP_FREI );        /* das Programm installieren */
   }
 else
   printf("Driver is already installed !\n");
 
}
