#ifndef PCIDOS_H
#define PCIDOS_H

/////////////
// Includes
#include "pmi.h"
#include "types.h"
#include "ls251pc.h"

/////////////
// Defines //
/////////////
#define MAXDEVCOUNT				0x08		// Maximum number of devices in registry
/////////////////////////////////////////////////////////////////////////////
#define PCI_BIOS_INT			0x1a		// The interrupt number
#define PCI_FUNCTION_ID			0xb100		// Always in AH
// Sub-functions in AL
#define PCI_BIOS_PRESENT		0x01
#define FIND_PCI_DEVICE			0x02
#define FIND_PCI_CLASS_CODE		0x03
#define GENERATE_SPECIAL_CYCLE	0x06
#define READ_CONFIG_BYTE		0x08
#define READ_CONFIG_WORD		0x09
#define READ_CONFIG_DWORD		0x0a
#define WRITE_CONFIG_BYTE		0x0b
#define WRITE_CONFIG_WORD		0x0c
#define WRITE_CONFIG_DWORD		0x0d
#define GET_IRQ_ROUTING_OPTIONS	0x0e
#define SET_PCI_IRQ				0x0f		// NOT FOR APPLICATION'S USE
// Results returned from PCI BIOS
#define SUCCESSFUL				0x00
#define FUNC_NOT_SUPPORTED		0x81
#define BAD_VENDOR_ID			0x83
#define DEVICE_NOT_FOUND		0x86
#define BAD_REGISTER_NUMBER		0x87
#define SET_FAILED				0x88
#define BUFFER_TOO_SMALL		0x89
/////////////////////////////////////////////////////////////////////////////
#define DWORD_PROBLEM 			TRUE		// TRUE: Problem with DWORD accesses
#define KBYTE_32                0x8000		// 32	kByte
#define ERSTESMEGABYTE			0x100000	// 1	MegaByte
#ifndef LONG
	#define LONG	unsigned long
#endif

/////////////////////////////////////////////////////////////////
// Beschreibung der verwendeten Speicherbereiche der PLX-Karte:
typedef struct PCI_DEV_typ {
    PCI_SITE      site;             // PCI site
	unsigned int  devicetyp;        // Devicetyp
    unsigned long pByteBase;        // Zeiger in den Bytebereich
	unsigned long pRamBase;         // Zeiger in den Rambereich
	unsigned long pComBase;         // Kommunikationsbereich
	unsigned long pRegBase;         // Not used yet
	unsigned char intline;          // Interuptpin - welcher Hardwarepin verwendet wird
	unsigned char intpin;	        // Controller-Line (Umrechnung per Software (Betriebssystem))
	unsigned char intnr;            // Umrechnung auf richtige Werte ((0-7 -> 8-F), (8-A ->60-68))
	unsigned long LenByteBase;      // L�nge des Bytebereichs
	unsigned long LenRamBase;       // L�nge des Rambereichs
	unsigned long LenComBase;       // L�nge des Combereichs
	unsigned long LenRegBase;       // L�nge des Registerbereichs
} PCI_DEV_typ;

//////////////////////////////
// Funktionsdeklarationen	//
//////////////////////////////
// PCI-Busfunktionen
void PCI_intenable (PCI_SITE site);
void PCI_intdisable(PCI_SITE site);
void PCI_intack(PCI_SITE site,BYTE intline);
int  PCI_Search_LS251(int nr,PCI_DEV_typ *pDev);
int  PCI_write(void _far* pbase,void _far* pbuffer,unsigned long bytecnt);
int  PCI_read(void _far* pbase,void _far* pbuffer,unsigned long bytecnt);

//////////////////////////
// PCI Errormeldungen
enum PCI_ERRROR {
	ERR_OKAY,
	ERR_INITPCIBIOS				= 0x1000,
	ERR_PCIDEVICEREGISTRATION,
	ERR_TOMANYPCIDEVICES,
	ERR_NOBURPCIDEVICE,
	ERR_RAMPARITY,
	ERR_OTHEREXCEPTION,
	ERR_GATEFAILURE,
	ERR_INVALIDREQUEST,
	ERR_OUTOFMEMCLASS,
	ERR_DEVNROUTOFRANGE,
	ERR_DEVNOTAVAILABLE,
	ERR_OUTOFMEMAREA,
	ERR_BYTEOFFSETISODD,
	ERR_BYTECNTISODD
};

//////////////////////////
// Memory-klassen
enum MEM_CLASS {
	BYTEMEMORY,
	RAMMEMORY,
	COMMEMORY,
	REGMEMORY,
};

#endif
