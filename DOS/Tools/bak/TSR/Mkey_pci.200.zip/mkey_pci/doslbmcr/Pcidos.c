/****************************************************************************
*                                                                           *
*  Name     : pcidos.c                                                      *
*  Titel    : pci dos                           							*
*  Version  : T 1.0                                                         *
*                                                                           *
******************************COPYRIGHT (C)**********************************
*     THIS SOFTWARE IS THE PROPERTY OF B&R AUSTRIA: ALL RIGHTS RESERVED.    *
*     NO PART OF THIS SOFTWARE MAY BE USED OR COPIED IN ANY WAY WITHOUT     *
*              THE PRIOR WRITTEN PERMISSION OF B&R AUSTRIA.                 *
*****************************************************************************
*                                                                           *
*  Projekt  : B&R                                                           *
*  Datum    : 18.01.1998                                                    *
*  Author   : Mandl Christian, Seidl G�nter                                 *
*                                                                           *
*****************************************************************************
*                                                                           *
*  AeNDERUNGEN:                                                             *
*  -----------                                                              *
*                                                                           *
*  Version  Datum       Aenderungsbeschreibung und Markierung               *
*                                                                           *
****************************************************************************/
/////////////
// Includes
#include <stdio.h>
#include <string.h>
#include <dos.h>
#include <conio.h>

////////////////////
// Includedateien //
////////////////////
#include "types.h"
#include "plx.h"
#include "pmi.h"
#include "vm_ext.h"
#ifndef extern
 #define extern
 #include "Ls251pc.h"
 #include "blkcpy.h"
 #include "pcidos.h"    
#endif               
               

// PCI-funktionen
void	pciBiosPresent		(void);
BOOL 	pciWriteConfigDword	(PCI_SITE site, UINT reg, DWORD val);
BOOL 	pciWriteConfigWord	(PCI_SITE site, UINT reg, WORD val);
BOOL 	pciWriteConfigByte	(PCI_SITE site, UINT reg, BYTE val);
DWORD   pciReadConfigDword	(PCI_SITE site, UINT reg);
WORD	pciReadConfigWord	(PCI_SITE site, UINT reg);
BYTE	pciReadConfigByte	(PCI_SITE site, UINT reg);

// Runtimeregister beschreiben
void    devWriteRtrDword(PCI_SITE site, UINT reg, DWORD val);

// Longausgabe
void    Outl(unsigned short port, unsigned long value);

#undef   FP_SEG
#undef   FP_OFF

#define FP_SEG(fp)     ((unsigned)(((unsigned long)(fp))>>16))
#define FP_OFF(fp)     ((unsigned)(fp))	 

//////////////////////
// Globale Variable //
//////////////////////
static	BOOL	havebios = FALSE;	// Biosroutinen vorhanden
static	UINT	lastbus = 0;

/*$B*************************************************************************
*                                                                           *
*  Name     : pciReadBase                                                   *
*  Titel    : pci read baseadr                                              *
*                                                                           *
*                                                                           *
*  BESCHREIBUNG:                                                            *
*  -------------                                                            *
*  liest eine Basisadresse, und korrigiert sie, falls < ERSTESMEGABYTE      *
*                                                                           *
*  In       :   PCI_SITE       site        PC Site                          *
*               UINT           reg         zu lesendes Register             *
*  Return   :   unsigned long  base        Baseaddress                      *
*                                                                           *
**$E************************************************************************/
unsigned long pciReadBase(PCI_SITE site, UINT reg)
{
    unsigned long base;

	base = (unsigned long)pciReadConfigDword(site,reg);
	if (base <= ERSTESMEGABYTE)
		base  = base - 2L;
    return base;
}


/*$B*************************************************************************
*                                                                           *
*  Name     : pciReadLen                                                    *
*  Titel    : pci read length                                               *
*                                                                           *
*                                                                           *
*  BESCHREIBUNG:                                                            *
*  -------------                                                            *
*  liest eine L�nge, und korrigiert sie                                     *
*                                                                           *
*  In       :   PCI_SITE       site        PC Site                          *
*               UINT           reg         zu lesendes Register             *
*  Return   :   unsigend long  len         laenge                           *
*                                                                           *
**$E************************************************************************/
unsigned long pciReadLen(PCI_SITE site, UINT reg)
{
    unsigned long searchlen;
    int           i;

    searchlen = pciReadConfigDword(site,reg) & 0xFFFFFFF8L; // Modulo 8
	for (i=0; i<32; i++) {
		if (searchlen & (1L<<i)) {
			return (1L<<i);  
		} // end if
	} // end for ByteBase
    return 0;
}


/*$B*************************************************************************
*                                                                           *
*  Name     : PCI_Search_LS251                                              *
*  Titel    : PCI Search LS251                                              *
*                                                                           *
*  BESCHREIBUNG:                                                            *
*  -------------                                                            *
*  Sucht die nr.te LS251 Karte am PCI Bus und bestimmt alle wesentlichen    *
*  Daten                                                                    *
*                                                                           *
*  In       :   int            nr          0=1.LS251, 1=2.LS251 usw         *
*  Inout    :   PCI_DEV_typ   *pDev        Diese Struktur wird entsprechend *
*                                          ausgef�llt                       *
*  Return   :   int            status      0=OK, sonst Fehler               *
*                                                                           *
**$E************************************************************************/
int PCI_Search_LS251(int nr,PCI_DEV_typ *pDev)
{
	WORD        subId  = 0;
    int         devnr  = 0;
	PCI_SITE    site;
    
	// Initialisierung der statischen datentypen
	havebios	 = FALSE;

	// One-time PCI BIOS Initialization; find and select a device
	pciBiosPresent();
	if (!havebios)
	{
    	// Problem initializing the PCI BIOS or No BIOS
		return ERR_INITPCIBIOS;
	}

	for (site.bus = 0; site.bus <= lastbus; site.bus++)
	{
        // Scan all PCI buses...
		for (site.dev = 0; site.dev < 0x100; site.dev += 8) {
        	// Scan for devices on a PCI bus (Ignore multi-func devices)
			if (pciReadConfigDword(site, 0x00) != 0xFFFFFFFFL)	{	
                // Found a device - check for LS251
            	if (pciReadConfigWord(site, 0x2C) == VENID_PLX) {
				    // Ein Plx-Device liegt vor
                    subId = pciReadConfigWord(site,0x2E);
					if ((subId==LS_251) || (subId==LS_151))	{
                        if (devnr != nr) { // check for n.th LS251
                            devnr++;
                            continue;
                        }
                        // now we have the n.th LS251                     
                        pDev->site      = site;	
						pDev->devicetyp	= pciReadConfigWord(site,0x2E); // Device-ID
                        pDev->pByteBase = pciReadBase(site,0x18);       // Bytebereich
						pDev->pRamBase  = pciReadBase(site,0x1c); 	    // Rambereich
						pDev->pComBase  = pciReadBase(site,0x20);  	    // Com-bereich (Memorybereich richtig stellen)
						pDev->pRegBase 	= pciReadBase(site,0x24);  	    // Registerbereich
						pDev->intline   = pciReadConfigByte(site,0x3C);	// Interruptline 0-F
						pDev->intpin	= pciReadConfigByte(site,0x3D);	// Hardwarepin   0-4
						// Umrechnung in eine Interruptnummer
						if (pDev->intline <= 7)	pDev->intnr = pDev->intline+0x08; // f�r Interruptroutine
						else					pDev->intnr = pDev->intline+0x68; // f�r Interruptroutine
						// Datenl�ngen bestimmen und eintragen
						pciWriteConfigDword(site,0x18,0xFFFFFFFFL);	    // L�nge ByteBase
						pciWriteConfigDword(site,0x1c,0xFFFFFFFFL);	    // L�nge der RamBase
						pciWriteConfigDword(site,0x20,0xFFFFFFFFL);     // L�nge der ComBase
						pciWriteConfigDword(site,0x24,0xFFFFFFFFL);     // L�nge der Reserve
						pDev->LenByteBase = pciReadLen(site,0x18);
						pDev->LenRamBase  = pciReadLen(site,0x1c);
						pDev->LenComBase  = pciReadLen(site,0x20);
						pDev->LenRegBase  = pciReadLen(site,0x24);
						// Daten wieder in den Baustein zur�ckschreiben ->
						// ansonsten stehen falsche Werte in den Registern
						pciWriteConfigDword(site,0x18,(DWORD)pDev->pByteBase); // Bytebereich
						pciWriteConfigDword(site,0x1c,(DWORD)pDev->pRamBase);  // Rambereich
						pciWriteConfigDword(site,0x20,(DWORD)pDev->pComBase);  // Combereich
						pciWriteConfigDword(site,0x24,(DWORD)pDev->pRegBase);  // Registerbereich
                        return 0;
					} // BRDevice
				}	// PLX-Device
			}
		}
	}
	return ERR_NOBURPCIDEVICE;
}


/*$B*************************************************************************
*                                                                           *
*  Name     : PCI_write                                                     *
*  Titel    : PCI write                                                     *
*                                                                           *
*  BESCHREIBUNG:                                                            *
*  -------------                                                            *
*  Schreibe Daten auf den PCI Bus                                           *
*                                                                           *
*  In       :   unsigned long  pbase       pci Bus Adresse                  *
*               unsigend char *pbuffer     source puffer                    *
*               unsigned long  bytecnt     Anzahl Bytes                     *
*  Return   :   int            status      0=OK, sonst Fehler               *
*                                                                           *
**$E************************************************************************/
int PCI_write(void _far* px,void _far* pbuffer,unsigned long bytecnt) 
{
	static int					PCIwr_status    = 0;
	static unsigned int			PCIwr_counter   = 0;
	static unsigned int   		PCIwr_rest      = 0;
	static unsigned int   		PCIwr_cnt       = 0;
	static unsigned long 		PCIwr_dest_adr_lin = 0;
	static unsigned long  		PCIwr_wordcnt   = 0;
//	static unsigned int   		Segment		    = 0;
//	static unsigned int 		Offset		    = 0;
	static unsigned char _far*	PCIwr_pDest     = 0;
    static unsigned long		PCIwr_pbase;

    PCIwr_pbase           = (unsigned long)px;
	// Speichergrenze von 1MB orten
	if (PCIwr_pbase >= ERSTESMEGABYTE) {
		if (bytecnt & 1L) return ERR_BYTECNTISODD;
		if (PCIwr_pbase   & 1L) return ERR_BYTEOFFSETISODD;

		// Wortdaten liegen vor
		PCIwr_wordcnt = bytecnt >> 1;
		// Bufferpointer in die lineare Adresse umrechnen
		PCIwr_dest_adr_lin = ((unsigned long)FP_SEG(pbuffer) << 4) + 
						(unsigned long)FP_OFF(pbuffer);
		// Durchlaeufe bestimmen
		PCIwr_rest = (unsigned int) (PCIwr_wordcnt % KBYTE_32);
		PCIwr_cnt  = (unsigned int) (PCIwr_wordcnt / KBYTE_32);
		// Daten behandeln
		for (PCIwr_counter=0; PCIwr_counter<PCIwr_cnt; PCIwr_counter++) {
			PCIwr_status     = XEXT_MemCopy(PCIwr_pbase,PCIwr_dest_adr_lin,KBYTE_32);
            PCIwr_pbase           += (unsigned long)KBYTE_32*2;
            PCIwr_dest_adr_lin    += (unsigned long)KBYTE_32*2;
			if (PCIwr_status) break;
		}	// end for
		if (!PCIwr_status) PCIwr_status = XEXT_MemCopy(PCIwr_pbase,PCIwr_dest_adr_lin,PCIwr_rest);
	} // end if erstesmegabyte
	else {
		// Far-Pointer ausrechnen
//		Segment = (unsigned int)((unsigned long)PCIwr_pbase >> 4);
//		Offset  = (unsigned int)((unsigned long)PCIwr_pbase & 0xF);
//		PCIwr_pDest 	 = MK_FP(Segment, Offset);
		 PCIwr_pDest = (unsigned char _far*)(((unsigned long)PCIwr_pbase & ~0x0000000f) << 12);
		 PCIwr_pDest = PCIwr_pDest + ((unsigned long)PCIwr_pbase & 0xF);
		// Memory kopieren
		_fmemcpy(PCIwr_pDest, pbuffer, (unsigned int)bytecnt);
	}	// end else erstesmegabyte
	return  PCIwr_status;
} // end PCI_write


/*$B*************************************************************************
*                                                                           *
*  Name     : PCI_read                                                      *
*  Titel    : PCI read                                                      *
*                                                                           *
*  BESCHREIBUNG:                                                            *
*  -------------                                                            *
*  Lese Daten vom PCI Bus                                                   *
*                                                                           *
*  In       :   unsigned long  pbase       pci Bus Adresse                  *
*               unsigend char *pbuffer     dest puffer                      * 
*               unsigned long  bytecnt     Anzahl Bytes                     *
*  Return   :   int            status      0=OK, sonst Fehler               *
*                                                                           *
**$E************************************************************************/
int PCI_read(void _far* px,void _far* pbuffer,unsigned long bytecnt) 
{
	static int					PCIrd_status    = 0;
	static unsigned int			PCIrd_counter   = 0;
	static unsigned int   		PCIrd_rest      = 0;
	static unsigned int   		PCIrd_cnt       = 0;
	static unsigned long 		PCIrd_dest_adr_lin = 0;
	static unsigned long  		PCIrd_wordcnt   = 0;
//	static unsigned int   		Segment		    = 0;
//	static unsigned int 		Offset		    = 0;
	static unsigned char _far*	PCIrd_pDest     = 0;
    static unsigned long		PCIrd_pbase;
                                            
    PCIrd_pbase           = (unsigned long)px;
	 // Speichergrenze von 1MB orten
	 if (PCIrd_pbase >= ERSTESMEGABYTE) {
		 if (bytecnt    & 1L) 	return ERR_BYTECNTISODD;
		 if (PCIrd_pbase      & 1L)   return ERR_BYTEOFFSETISODD;

		 // Wortdaten liegen vor
		 PCIrd_wordcnt = bytecnt >> 1;
		 // Bufferpointer in die lineare Adresse umrechnen
		 PCIrd_dest_adr_lin = ((unsigned long)FP_SEG(pbuffer) << 4) + 
						 (unsigned long)FP_OFF(pbuffer);
		 // Durchlaeufe bestimmen
		 PCIrd_rest = (unsigned int) (PCIrd_wordcnt % KBYTE_32);
		 PCIrd_cnt  = (unsigned int) (PCIrd_wordcnt / KBYTE_32);
		 // Daten behandeln
		 for (PCIrd_counter=0; PCIrd_counter<PCIrd_cnt; PCIrd_counter++) {
		 	PCIrd_status           = XEXT_MemCopy(PCIrd_dest_adr_lin,PCIrd_pbase,KBYTE_32);
            PCIrd_pbase           += (unsigned long)KBYTE_32*2;
            PCIrd_dest_adr_lin    += (unsigned long)KBYTE_32*2;
		 	if (PCIrd_status) break;
		 }	// end for
		 if (!PCIrd_status) PCIrd_status = XEXT_MemCopy(PCIrd_dest_adr_lin,PCIrd_pbase,PCIrd_rest);
	 } // end if erstesmegabyte
	 else {
		 // Far-Pointer ausrechnen
//		 Segment = (unsigned int)((unsigned long)PCIrd_pbase >> 4);
//		 Offset  = (unsigned int)((unsigned long)PCIrd_pbase & 0xF);
//		 PCIrd_pDest 	 = MK_FP(Segment, Offset);
		 PCIrd_pDest = (unsigned char _far*)(((unsigned long)PCIrd_pbase & ~0x0000000f) << 12);
		 PCIrd_pDest = PCIrd_pDest + ((unsigned long)PCIrd_pbase & 0xF);
		 // Memory kopieren
		 _fmemcpy(pbuffer, PCIrd_pDest, (unsigned int)bytecnt);
	 }	// end else erstesmegabyte
	 return  PCIrd_status;
} // end PCI_read


/*$B*************************************************************************
*                                                                           *
*  Name     : PCI_intenable, PCI_intdisable, PCI_intack                     *
*  Titel    : Interrupt things                                              *
*                                                                           *
*  BESCHREIBUNG:                                                            *
*  -------------                                                            *
*                                                                           *
**$E************************************************************************/
void PCI_intenable(PCI_SITE site) {
	// Interrupt freigeben
	devWriteRtrDword(site, 0x4C, 0x43);
}

void PCI_intdisable(PCI_SITE site) {
	// Interrupt sperren
	devWriteRtrDword(site, 0x4C, 0x03);
}

void PCI_intack(PCI_SITE site,BYTE intline)
{
	// Interrupt freigeben - PLX
	devWriteRtrDword(site, 0x4C, 0x43);
	// EOI an beide Controller sebdeb
	if (intline<=7) {
		outp(0x20, 0x20);
	}
	else {
		outp(0xA0, 0x20);
		outp(0x20, 0x20);
	} // end else
}


/////////////////////////////////////////////////////////////////////////////
void pciBiosPresent(void)
{	// Find PCI BIOS; if found, return BIOS identification information
	PMIREGS32 regs32;
	// Gehe BIOS suchen
	havebios = FALSE;			// Assume we have no BIOS
	regs32.eax = (long)(PCI_FUNCTION_ID | PCI_BIOS_PRESENT);
	pmiInt32(PCI_BIOS_INT, &regs32);
	if ((!(regs32.flags & CarryFlag))		// No carry flag
		/*&& (regs32.edx == 0x20494350)*/	// "PCI " in EDX
		&& ((WORD)regs32.edx == 0x4350)		// "PC" in DX
		&& ((BYTE)(regs32.eax >> 8) == SUCCESSFUL))// Return code is OK
	{	// PCI BIOS present!
		havebios = TRUE;
		lastbus = (UINT)regs32.ecx & 0xff;
	}
	return;
}

/////////////////////////////////////////////////////////////////////////////
BOOL pciFindDevice(PCI_SITE * site, UINT devid, UINT venid, UINT index)
{	// Find PCI device
	// Fill in site information if device found
	PMIREGS32 regs32;
	if (!havebios)		return FALSE;	// No BIOS
	regs32.eax = (long)(PCI_FUNCTION_ID | FIND_PCI_DEVICE);
	regs32.edx = (DWORD)venid;
	regs32.ecx = (DWORD)devid;
	regs32.esi = (DWORD)index;
	pmiInt32		 (PCI_BIOS_INT, &regs32);
	if ((regs32.flags & CarryFlag) || (((regs32.eax >> 8) & 0xff) != SUCCESSFUL))
	{	// Something went wrong
		return FALSE;
	}
	site->bus = ((UINT)regs32.ebx >> 8) & 0xff;
	site->dev = (UINT)regs32.ebx & 0xff;
	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
BYTE	pciReadConfigByte(PCI_SITE site, UINT reg)
{	// Return a PCI configuration register (BYTE)
	// Parameters are not value checked!
	PMIREGS32 regs32;
	if (!havebios)		return (BYTE)-1;
	regs32.eax = (DWORD)(PCI_FUNCTION_ID | READ_CONFIG_BYTE);
	regs32.ebx = (DWORD)site.dev | (DWORD)(site.bus << 8);
	regs32.edi = (DWORD)reg;
	pmiInt32(PCI_BIOS_INT, &regs32);
	if ((!(regs32.flags & CarryFlag))					// No carry flag; good
		&& ((BYTE)(regs32.eax >> 8) == SUCCESSFUL))	// Return code is good
	{
		return ((BYTE)regs32.ecx);
	}
	return (BYTE)-1;
}

/////////////////////////////////////////////////////////////////////////////
WORD  pciReadConfigWord(PCI_SITE site, UINT reg)
{	// Return a PCI configuration register (WORD)
	// Parameters are not value checked!
	static PMIREGS32 PCIrd_regs32;
	if (!havebios)		return (WORD)-1;
	PCIrd_regs32.eax = (DWORD)(PCI_FUNCTION_ID | READ_CONFIG_WORD);
	PCIrd_regs32.ebx = (DWORD)site.dev | (DWORD)(site.bus << 8);
	PCIrd_regs32.edi = (DWORD)reg;
	pmiInt32(PCI_BIOS_INT, &PCIrd_regs32);
	if ((!(PCIrd_regs32.flags & CarryFlag))					// No carry flag; good
		&& ((BYTE)(PCIrd_regs32.eax >> 8) == SUCCESSFUL))	// Return code is good
	{
		return ((WORD)PCIrd_regs32.ecx);
	}
	return (WORD)-1;
}

/////////////////////////////////////////////////////////////////////////////
DWORD pciReadConfigDword(PCI_SITE site, UINT reg)
{	// Return a PCI configuration register (DWORD)
	// Parameters are not value checked!
#if DWORD_PROBLEM
	// (Ryan 960529) Patch to fix problems reading all 32 bits (RatSys?)
		return (DWORD)pciReadConfigWord(site, reg) |
				 ((DWORD)pciReadConfigWord(site, (UINT)(reg+2))<<16);
#else
	PMIREGS32 regs32;
	if (!havebios)		return (DWORD)-1;
	regs32.eax = (DWORD)(PCI_FUNCTION_ID | READ_CONFIG_DWORD);
	regs32.ebx = (DWORD)site.dev | (DWORD)(site.bus << 8);
	regs32.edi = (DWORD)reg;
	pmiSignalRMInterrupt(PCI_BIOS_INT, &regs32);
	if ((!(regs32.flags & CarryFlag))					// No carry flag; good
		&& ((BYTE)(regs32.eax >> 8) == SUCCESSFUL))	// Return code is good
	{
		return ((DWORD)regs32.ecx);
	}
	return (DWORD)-1;
#endif
}

/////////////////////////////////////////////////////////////////////////////
BOOL  pciWriteConfigByte(PCI_SITE site, UINT reg, BYTE val)
{
	PMIREGS32 regs32;
	if (!havebios)		return FALSE;
	regs32.eax = (DWORD)(PCI_FUNCTION_ID | WRITE_CONFIG_BYTE);
	regs32.ebx = (DWORD)site.dev | (DWORD)(site.bus << 8);
	regs32.edi = (DWORD)reg;
	regs32.ecx = (DWORD)val;
	pmiInt32(PCI_BIOS_INT, &regs32);
	return ((!(regs32.flags & CarryFlag))				// No carry flag; good
		&& ((BYTE)(regs32.eax >> 8) == SUCCESSFUL))?	// Return code is good
		TRUE: FALSE;
}

/////////////////////////////////////////////////////////////////////////////
BOOL	pciWriteConfigWord(PCI_SITE site, UINT reg, WORD val)
{
	PMIREGS32 regs32;
	if (!havebios)		return FALSE;
	regs32.eax = (DWORD)(PCI_FUNCTION_ID | WRITE_CONFIG_WORD);
	regs32.ebx = (DWORD)site.dev | (DWORD)(site.bus << 8);
	regs32.edi = (DWORD)reg;
	regs32.ecx = (DWORD)val;
	pmiInt32(PCI_BIOS_INT, &regs32);
	return ((!(regs32.flags & CarryFlag))				// No carry flag; good
		&& ((BYTE)(regs32.eax >> 8) == SUCCESSFUL))?	// Return code is good
		TRUE: FALSE;
}

/////////////////////////////////////////////////////////////////////////////
BOOL	pciWriteConfigDword(PCI_SITE site, UINT reg, DWORD val)
{
#if DWORD_PROBLEM
	// (Ryan 960529) Patch to fix problems writing all 32 bits (RatSys?)
	if (pciWriteConfigWord(site, reg, (WORD)val))
		return pciWriteConfigWord(site, reg+2, (WORD)(val>>16));
	return FALSE;	// Something went wrong with first write
#else
	PMIREGS32 regs32;
	if (!havebios)		return FALSE;
	regs32.eax = (DWORD)(PCI_FUNCTION_ID | WRITE_CONFIG_DWORD);
	regs32.ebx = (DWORD)site.dev | (DWORD)(site.bus << 8);
	regs32.edi = (DWORD)reg;
	regs32.ecx = (DWORD)val;
	//	pmiSignalRMInterrupt(PCI_BIOS_INT, &regs32);
	pmiInt32(PCI_BIOS_INT, &regs32);
	return ((!(regs32.flags & CarryFlag))						// No carry flag; good
		&& ((BYTE)(regs32.eax >> 8) == SUCCESSFUL))?	// Return code is good
		TRUE: FALSE;
#endif
}

////////////////////////////////////////////////////////////////////////////////
// WriteRtrDword(...)
void devWriteRtrDword(PCI_SITE site, UINT reg, DWORD val)
{	// Write a DWORD to a runtime register
	// (Includes Local Configuration and Shared Runtime Registers)
	Outl((pciReadConfigWord(site, 0x14) & ~3) + reg, val);
	return;
}

#define cwde __asm __emit 0x66 __asm __emit 0xEF

void Outl(unsigned short port, unsigned long value)
{
// Ausgabe eines Longwertes auf einen Board
//	_DX 	= port;
//	_EAX 	= value;
//	__emit__ (0x66,0xEF);
    _asm push dx
	_asm _emit ( 0x66 )	
	_asm push ax
	_asm mov dx,port	 	
	_asm  _emit (0x66)
	_asm  mov ax,word ptr value
	_asm _emit ( 0x66 )
	_asm _emit ( 0xEF )
	_asm _emit ( 0x66 )	
	_asm pop ax		
	_asm pop dx	
}
