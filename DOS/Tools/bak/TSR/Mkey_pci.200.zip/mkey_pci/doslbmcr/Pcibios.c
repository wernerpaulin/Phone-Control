/****************************************************************************
PCIBIOS.C
PCI BIOS functions
Copyright PLX Technology, 1996
Changes
000000	Reid	Genesis - PCI BIOS functions
960521	Ryan	Added pciFindDevice()
****************************************************************************/
/////////////////////////////////////////////////////////////////////////////
#include "pmi.h"
#include "types.h"
#include "pcibios.h"
/////////////////////////////////////////////////////////////////////////////
#define PCI_BIOS_INT					0x1a		// The interrupt number
#define PCI_FUNCTION_ID				0xb100	// Always in AH
// Sub-functions in AL
#define PCI_BIOS_PRESENT			0x01
#define FIND_PCI_DEVICE				0x02
#define FIND_PCI_CLASS_CODE		0x03
#define GENERATE_SPECIAL_CYCLE	0x06
#define READ_CONFIG_BYTE			0x08
#define READ_CONFIG_WORD			0x09
#define READ_CONFIG_DWORD			0x0a
#define WRITE_CONFIG_BYTE			0x0b
#define WRITE_CONFIG_WORD			0x0c
#define WRITE_CONFIG_DWORD			0x0d
#define GET_IRQ_ROUTING_OPTIONS	0x0e
#define SET_PCI_IRQ					0x0f		// NOT FOR APPLICATION'S USE
// Results returned from PCI BIOS
#define SUCCESSFUL					0x00
#define FUNC_NOT_SUPPORTED			0x81
#define BAD_VENDOR_ID				0x83
#define DEVICE_NOT_FOUND			0x86
#define BAD_REGISTER_NUMBER		0x87
#define SET_FAILED					0x88
#define BUFFER_TOO_SMALL			0x89
/////////////////////////////////////////////////////////////////////////////
#define DWORD_PROBLEM TRUE		// TRUE: Problem with DWORD accesses (RatSys?)
/////////////////////////////////////////////////////////////////////////////
// Private variables
static _CMhavebios = FALSE;
extern int pmiInt32(UINT intno, PMIREGS32* uregs);
/////////////////////////////////////////////////////////////////////////////
BOOL
pciFindDevice(PCI_SITE * site, UINT devid, UINT venid, UINT index)
{	// Find PCI device
	// Fill in site information if device found
	static PMIREGS32 regs32;
	if (!_CMhavebios)		return FALSE;	// No BIOS
	regs32.eax = (long)(PCI_FUNCTION_ID | FIND_PCI_DEVICE);
	regs32.edx = (DWORD)venid;
	regs32.ecx = (DWORD)devid;
	regs32.esi = (DWORD)index;
	pmiInt32		 (PCI_BIOS_INT, &regs32);
	if ((regs32.flags & CarryFlag) || (((regs32.eax >> 8) & 0xff) != SUCCESSFUL))
	{	// Something went wrong
		return FALSE;
	}
	site->bus = ((UINT)regs32.ebx >> 8) & 0xff;
	site->dev = (UINT)regs32.ebx & 0xff;
}

/////////////////////////////////////////////////////////////////////////////
// 	End of file
