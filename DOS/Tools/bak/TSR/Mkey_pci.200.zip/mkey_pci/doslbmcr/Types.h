/****************************************************************************
*  Name     : types.h                                                       *
*  Titel    : Typendeklaration                  							              *
*  Version  : T 1.0                                                         *
*                                                                           *
******************************COPYRIGHT (C)**********************************
*     THIS SOFTWARE IS THE PROPERTY OF B&R AUSTRIA: ALL RIGHTS RESERVED.    *
*     NO PART OF THIS SOFTWARE MAY BE USED OR COPIED IN ANY WAY WITHOUT     *
*              THE PRIOR WRITTEN PERMISSION OF B&R AUSTRIA.                 *
*****************************************************************************
*                                                                           *
*  Projekt  : B&R                                                           *
*  Datum    : 10.07.1997                                                    *
*  Author   : Mandl                                                         *
*                                                                           *
*****************************************************************************
*                                                                           *
*  AeNDERUNGEN:                                                             *
*  -----------                                                              *
*                                                                           *
*  Version  Datum       Aenderungsbeschreibung und Markierung               *
*                                                                           *
****************************************************************************/
//#ifndef TYPES_H
//#define TYPES_H

/////////////////////////////////////////////////////////////////////////////
#define TRUE 1
#define FALSE 0

/////////////////////////////////////////////////////////////////////////////
typedef char int8;
typedef int int16;
typedef long int32;
typedef unsigned char u_int8;
typedef unsigned int u_int16;
typedef unsigned long u_int32;

typedef unsigned char 	uchar;
typedef unsigned short 	ushort;
typedef unsigned int 		uint;
typedef unsigned long 	ulong;

// #ifndef _AFX			/* Avoid MS C++ 7.0 Class collision */
#define BYTE 		uchar
#ifndef WORD
	#define WORD 		ushort
#endif
//#ifndef LONG
	#define LONG    ulong
//#endif
#ifndef UINT
	#define UINT 		uint
#endif
#ifndef DWORD
	#define DWORD 	ulong
#endif
#ifndef BOOL
 #define BOOL 	uint
#endif
// #endif

//#endif // TYPES_H

/////////////////////////////////////////////////////////////////////////////
// 	End of file
