/****************************************************************************
*  Name     : pcibios.h                                                     *
*  Titel    : Funktionsdeklaration              							              *
*  Version  : T 1.0                                                         *
*                                                                           *
******************************COPYRIGHT (C)**********************************
*     THIS SOFTWARE IS THE PROPERTY OF B&R AUSTRIA: ALL RIGHTS RESERVED.    *
*     NO PART OF THIS SOFTWARE MAY BE USED OR COPIED IN ANY WAY WITHOUT     *
*              THE PRIOR WRITTEN PERMISSION OF B&R AUSTRIA.                 *
*****************************************************************************
*                                                                           *
*  Projekt  : B&R                                                           *
*  Datum    : 10.07.1997                                                    *
*  Author   : Mandl                                                         *
*                                                                           *
*****************************************************************************
*                                                                           *
*  AeNDERUNGEN:                                                             *
*  -----------                                                              *
*                                                                           *
*  Version  Datum       Aenderungsbeschreibung und Markierung               *
*                                                                           *
****************************************************************************/
#ifndef PCIBIOS_H
#define PCIBIOS_H

/////////////////////////////////////////////////////////////////////////////
#include "types.h"

/////////////////////////////////////////////////////////////////////////////
typedef struct pcibios_id
{	// PCI BIOS identification
	UINT mechanism;
	UINT version;
	UINT lastbus;
} PCIBIOS_ID;

/////////////////////////////////////////////////////////////////////////////
typedef struct pci_site
{	// Site (location) of a PCI device
	UINT bus;
	UINT dev;	      // (Device in upper five bits, function in lower three bits)
#ifdef WIN32
	DWORD devnode;	// WIN32 extension
#endif // WIN32
} PCI_SITE;

/////////////////////////////////////////////////////////////////////////////
// Public functions
extern BOOL 	pciBiosPresent			(PCIBIOS_ID* id);
extern BOOL 	pciFindDevice				(PCI_SITE* site, UINT devid, UINT venid, UINT index);

extern BYTE 	pciReadConfigByte		(PCI_SITE site, UINT reg);
extern WORD 	pciReadConfigWord		(PCI_SITE site, UINT reg);
extern DWORD 	pciReadConfigDword	(PCI_SITE, UINT reg);
extern BOOL		pciWriteConfigByte	(PCI_SITE site, UINT reg, BYTE val);
extern BOOL 	pciWriteConfigWord	(PCI_SITE site, UINT reg, WORD val);
extern BOOL 	pciWriteConfigDword	(PCI_SITE site, UINT reg, DWORD val);

#endif // PCIBIOS_H

/////////////////////////////////////////////////////////////////////////////
// 	End of file
