#ifndef LS251PC_H
#define LS251PC_H
/*
		Anm.:
		-> CAREA_LNG auf 518 Byte's vergroessert (max. Net2000 L2 Framelaenge);
		-> Bitflags (inisr, outisr) auf WORD's geaendert, damit der Zugriff
			 ueber den PCI-Bus erleichtert wird.
		-> Es wurden WORD-Flags realisiert, weil ueber DOS nur ein
			 Wort-Zugriff moeglich ist !
*/

#define     CAREA_LNG           0x206   /* Laenge von TX bzw. RX Bereich */

typedef struct REGS_pc_head_typ
{
		WORD            outisr_rx;          /* OUT IR Statusregister RX 			*/
		WORD            outisr_tx;          /* OUT IR Statusregister TX 			*/
		WORD            outisr_rxr;         /* OUT IR Statusregister RX ready */
		WORD            inisr_rx;           /* IN  IR Statusregister RX 			*/
		WORD            inisr_tx;           /* IN  IR Statusregister TX 			*/
		WORD            inisr_rxr;          /* IN  IR Statusregister RX ready */
		WORD            txdata_lng;         /* TX Datenlaenge 								*/
		WORD            rxdata_lng;         /* RX Datenlaenge 								*/
		LONG            reserve;            /* Reserve 												*/
} REGS_pc_head_typ;

typedef struct REGS_pc_typ
{
		/* PC-Sicht (Eintraege sind vertauscht) */
		REGS_pc_head_typ	txrxheader;		   	/* TXRX Header */
		BYTE            	txarea[CAREA_LNG];  /* TX Bereich */
		BYTE            	rxarea[CAREA_LNG];  /* RX Bereich */
} REGS_pc_typ;

#endif
