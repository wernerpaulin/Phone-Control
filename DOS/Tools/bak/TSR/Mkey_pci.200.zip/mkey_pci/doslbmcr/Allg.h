/*
*$doc$b***********************************************************************
*                                                                            *
*	 COPYRIGHT    BERNECKER + RAINER Industrie-Elektronik Ges.m.b.H          *
*                                                                            *
******************************************************************************
*                                                                            *
*      Projekt :  DSF		                                                 *
*  Teilprojekt :  DEFS	                                                     *
*        Modul :  allg.h													 *
*                                                                            *
*     Revision :  01.00                                                      *
*        Datum :  94/07/04                                                   *
*        Autor :  Thomas Spiessberger / SpT                                  *
*                                                                            *
*----------------------------------------------------------------------------*
*                                                                            *
*     Funktion :  Allgemeine Definitionen fuer das B&R Netzwerk NET2000.	 *
*                                                                            *
*                                                                            *
*                                                                            *
******************************************************************************
*                                                                            *
*  Revision Report :                                                         *
*                                                                            *
*  Rev.   Datum     Name  Kommentar                                          *
*  --------------------------------------------------------------------------*
*                                                                            *
*                                                                            *
***********************************************************************$doc$e*
*/

/**************************** CONSTANTS *************************************/

/* Definition des Memory-Modells */
#define BR_MMODEL

#define TRUE	1
#define FALSE	0

#ifdef INTEL
#define SWAP16(x) (x<<8)+(x>>8)
#define SWAP32(x) (((x>>16)>>8)&0xff) + (((x>>16)<<8)&0xff00) + \
				  (((x<<16)>>8)&0xff0000) + (((x<<16)<<8)&0xff000000)
#endif

/********************** STRUCTURE DEFINITIONS *******************************/

/* Byte und Word Definition, I fuer Intern (da teilwiese schon definiert) */
typedef u_int8 IBYTE;
typedef u_int16 IWORD;
typedef u_int32 ILONG;
typedef IBYTE * PTR;


/*********** VARIABLES ( sequence : extern, global, local ) *****************/


/************************* GLOBAL FUNCTIONS *********************************/
