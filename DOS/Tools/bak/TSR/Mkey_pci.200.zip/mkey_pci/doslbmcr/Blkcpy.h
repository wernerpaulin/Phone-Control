/////////////
// Include BLKCPY.H

//////////////
//	Defines
#define ESC				0x1b
#define INT_OFFS        0xE0008L
#define IRQ4_OFFS       0xE0002L
#define INT_IRQ4_LEN	2L
#define PRINT_VERSION() cprintf("BLOCKCOPY Version 1.00 (Sept 30 1997) (C) B&R 1997 (NW)\n\r")
#define RXAREA_OFFS 	(sizeof(REGS_pc_head_typ)+CAREA_LNG)
#define TXAREA_OFFS 	(sizeof(REGS_pc_head_typ))
#define KEY_M_OFFS		0x0000D082
#define KEY_L_OFFS		0x0000D182
#define LED_M_OFFS		0x0000D102
#define LED_L_OFFS		0x0000D184
#define INC_OFFS		0x0000D080

//**************************************************************
// device specific data LS251
//**************************************************************
typedef struct pci_site
{	// Site (location) of a PCI device
	UINT bus;
	UINT dev;	      // (Device in upper five bits, function in lower three bits)
} PCI_SITE;

typedef struct NET2_LS251_typ {
	PCI_SITE				site;		// PCI site
	BYTE					intnr;		// Interrupt nummer
	BYTE					intline;	// Interrupt line
	unsigned long			pByteBase;	// Zeiger in den Bytebereich
	REGS_pc_head_typ _far*	pHd;		// Zeiger in den Header
	BYTE _far*				pKeyDPR;		// pointer to DPR key matrix
	BYTE _far*				pLedDPR;		// pointer to DPR led matrix
	BYTE _far*				pKeyLevelDPR;	// pointer to DPR key level
	BYTE _far*				pLedLevelDPR;	// pointer to DPR led level
	BYTE _far*				pIncrementDPR;	// pointer to DPR incremental
	BYTE _far*				pTxBase;	// Zeiger in den Tx Buffer
	BYTE _far*				pRxBase;	// Zeiger in den Rx Buffer
	BYTE					RxBuff[CAREA_LNG];
	WORD					RxBuffLen;
	unsigned short			TxBuffStatus;
	int						ErrorCode;
} NET2_LS251_typ ;

///////////////////////////
// Funktionsdeklarationen
int PollHandler(void);

unsigned long LS251_open(void);
void LS251_close (void);
int LS251_write (unsigned char * pBuffer, unsigned int *BufferLen);
int LS251_read (unsigned char * pBuffer, unsigned int *BufferLen);
int LS251_matrix (void);

// LS251 communication error codes
// LS251 communication base code
#define ERR_LS251		4800
#define ERR_MTC			4820

#define ERR_LS251_OUTOF_MEMORY		ERR_LS251 + 1
#define ERR_LS251_NOT_FOUND1		ERR_LS251 + 2
#define ERR_LS251_NOT_FOUND2		ERR_LS251 + 3
#define ERR_LS251_INV_TXLEN			ERR_LS251 + 4
#define ERR_LS251_INV_COMMMEM		ERR_LS251 + 5
#define ERR_LS251_ILL_SETUP			ERR_LS251 + 6
#define ERR_LS251_SEND				ERR_LS251 + 7
#define ERR_LS251_INV_REGMEM		ERR_LS251 + 8
