/////////////
// Includes
#include <stdio.h>
#include <string.h>
#include <dos.h>
#include <stdlib.h>
#include <conio.h>
#include <malloc.h>
//#include <alloc.h>
#include "types.h"
#include "Ls251pc.h"
#include "blkcpy.h"
#include "pcidos.h" 	
#include "plx.h"
#include "types.h"
#include "allg.h"

#define LIBRARY_TYPE 0x00
#define WITH_NEW_FUNCTION
#include "brmtc.h"

/**************************************/
/***	   G L O B A L S			***/
/**************************************/

static NET2_LS251_typ _far* pData = 0;

#undef FP_SEG
#undef FP_OFF

#define FP_SEG(fp) ((unsigned)(((unsigned long)(fp))>>16))
#define FP_OFF(fp) ((unsigned)(fp))
					
// LS251_open()
ILONG LS251_open(void)
{
	static int				op_status; 	// Return value
	static REGS_pc_head_typ op_head;	// Header im COM-Bereich
	static PCI_DEV_typ		op_dev;		// PCI Device Daten
	static DWORD			mtc_status;

	// allocate driver data
	pData = _fmalloc(sizeof(NET2_LS251_typ));
	if (pData == NULL)
	{
		return (ERR_LS251_OUTOF_MEMORY);
	}
	_fmemset(pData,0,sizeof(NET2_LS251_typ));

	op_status = PCI_Search_LS251 (0, &op_dev);
	if (op_status == 0)
	{
		// Valid device is found
		// Initialisierung der ComMemory Verwaltungspointer
		pData->pByteBase = op_dev.pByteBase;					// Zeiger in den Bytebereich
		pData->pHd = (REGS_pc_head_typ _far*)op_dev.pRamBase; 	// Zeiger in den Rambereich
		pData->pTxBase = (BYTE _far*)(op_dev.pRamBase + TXAREA_OFFS);
		pData->pRxBase = (BYTE _far*)(op_dev.pRamBase + RXAREA_OFFS);
		pData->pKeyDPR = (BYTE _far*)(op_dev.pRamBase + KEY_M_OFFS);	// pointer to DPR key matrix
		pData->pLedDPR = (BYTE _far*)(op_dev.pRamBase + LED_M_OFFS);	// pointer to DPR led matrix
		pData->pKeyLevelDPR = (BYTE _far*)(op_dev.pRamBase + KEY_L_OFFS);	// pointer to DPR key level
		pData->pLedLevelDPR = (BYTE _far*)(op_dev.pRamBase + LED_L_OFFS);	// pointer to DPR led level
		pData->pIncrementDPR = (BYTE _far*)(op_dev.pRamBase + INC_OFFS);	// pointer to DPR incremental


		// Check size of RAM memory
		if (op_dev.LenRamBase < sizeof(REGS_pc_typ))
		{
			// Illegal RAM memory size
			op_status = ERR_LS251_ILL_SETUP;
		}
		else
		{
			pData->intnr	  = op_dev.intnr;		// interrupt number
			pData->intline	  = op_dev.intline;	// interrupt line
			pData->site 	  = op_dev.site;
			// Den Combereich initialisieren
			memset(&op_head,0,sizeof(REGS_pc_head_typ));
			op_status=PCI_write(pData->pHd,(void _far*)&op_head,
							 sizeof(REGS_pc_head_typ));
		}
	}
	if (op_status) {
		_ffree (pData);
		pData = NULL;
	}
	if (!op_status)
	{
		mtc_status = IPC5000_init();
		if (mtc_status != NO_ERROR_DETECT)
		{
			// Error offset 4820
			return (ERR_MTC | ((int)mtc_status & 0x00ff));
		}
	}
	return (op_status);
}

void LS251_close (void)
{
	if (pData == NULL)
		return;
	// Free allocated memory
	_ffree (pData);
	// Reset global data pointer
	pData = NULL;
}

//
// LS251_write frame function
//
int LS251_write (unsigned char * pBuffer, unsigned int *BufferLen)
{
	static WORD 			wr_value;
	static int				wr_status;
	static REGS_pc_head_typ	wr_head;   // Header im COM-Bereich
	
	if (*BufferLen > CAREA_LNG)
	{
		// More than 518 bytes can not be copied to the LS251 DPR
		return (ERR_LS251_INV_TXLEN);
	}

	if (pData == 0)
	{
		// No valid poiter to allocated memory
		return (ERR_LS251_INV_COMMMEM);
	}

	// Check if old data has been reveived by LS251 card
	if (!pData->TxBuffStatus)
	{
		// Set TxBuffStatus for new data to send 
		pData->TxBuffStatus = 1;
		// set even length of buffer
		wr_value = ((WORD)*BufferLen + 1) & ~0x01;
		// Write Tx data to DPR
		wr_status = PCI_write(pData->pTxBase,(void _far*)pBuffer,wr_value);
		if (wr_status == 0)
		{
			// write Transmitt buffer length and interrupt flag in DPR
			wr_head.txdata_lng = (int)SWAP16 (*BufferLen);
			// Set RXR interrupt WORD
			wr_head.outisr_rxr = (int)0x0100;
			// copy data to txdata_lng in communication DPR
			wr_status = PCI_write((void _far*)&pData->pHd->txdata_lng,
							   (void _far*)&wr_head.txdata_lng,
							   sizeof(WORD));
			if (wr_status == 0)
			{
				// copy data to outisr_rxr in communication DPR
				wr_status = PCI_write((void _far*)&pData->pHd->outisr_rxr,
								   (void _far*)&wr_head.outisr_rxr,sizeof(WORD));
			}
		}
		if (wr_status == 0)
		{
			// Interrupt aktivieren -> auf der CPU
			// Schreibe den Interrupt -> IRQ ausl�sen
			wr_value = (int)0x0100;
			wr_status=PCI_write((void _far*)(pData->pByteBase+IRQ4_OFFS),
							 (void _far*)&wr_value,sizeof(WORD));
		}
	}
	else
	{
		// The old data is not received by LS251 yet
		wr_status = ERR_LS251_SEND;
	}
	if (wr_status)
	{
		// error on sending data
		// The old data is not received by LS251 yet
		// No data have been sent
		*BufferLen = 0;
		// Clear _EMTxBuffStatus for ignore old data sent
		pData->TxBuffStatus = 0;
	}
	return (wr_status);
}

//
// LS251_read frame function
//
int LS251_read (unsigned char *pBuffer, unsigned int *BufferLen)
{
	static unsigned int Rd_DataLen;

	if (pData == 0)
	{
		// No valid poiter to allocated memory
		return (ERR_LS251_INV_COMMMEM);
	}
	// Read DPR and evaluate interrupt flags
	pData->ErrorCode = PollHandler();

	if (!pData->ErrorCode)
	{
		if (pData->RxBuffLen != 0)
		{
			// set copy data length
			if (*BufferLen >= pData->RxBuffLen)
			{
				Rd_DataLen = pData->RxBuffLen;
			}
			else
			{
				Rd_DataLen = *BufferLen;
			}
			// Copy received data to buffer
			_fmemcpy ((void _far*)pBuffer, (void _far*)&pData->RxBuff[0], Rd_DataLen);
			// clear the receive data length
			pData->RxBuffLen = 0;
			// Set copied data length
			*BufferLen = Rd_DataLen;
		}
		else
		{
			// Set copied data length
			*BufferLen = 0;
		}
	}
	return (pData->ErrorCode);
}
//
// Routine for reading DPR and handling of interrupt flags
//
int PollHandler(void)
{
	static REGS_pc_head_typ	int_head;                   // Header im COM-Bereich
	static WORD				int_value;
	static int				int_status;
	static unsigned int 	int_DataLen;

	int_DataLen = 0;

	// Der Interrupt byte mu� in jedem Fall ausgetragen werden.
	// Read interrupt byte in DPR
	int_status = PCI_read ((void _far*)(pData->pByteBase+INT_OFFS),
					   (void _far*)&int_value,sizeof(WORD));
	if ((int_value & 0xff00) && (int_status == 0))
	{
		/* Interrupt byte is set from the LS251 card */
		/* Clear the interrupt byte */
		int_value = 0;
		int_status = PCI_write((void _far*)(pData->pByteBase+INT_OFFS),
						   (void _far*)&int_value,sizeof(WORD));
	}
	else if (((int_value & 0xff00) == 0) && (int_status == 0))
	{
		/* Interrupt byte is not set from LS251 */
		return (0);
	}

	if (int_status)
	{
		// Es ist ein Fehler beim Write oder Read aufgetreten.
		return (int_status);
	}
	// Den Header der entsprechenden Speicherkarte holen
	int_status = PCI_read(pData->pHd,(void _far*)&int_head,
						  sizeof(REGS_pc_head_typ));
	if (int_status)
	{
		// Es ist ein Fehler beim Write oder Read aufgetreten.
		return (int_status);
	}
	// evaluate interrupt flags
	do
	{
		// while int_head.inisr_rx or 
		//		 int_head.inisr_tx or 
		//		 int_head.inisr_rxr
		if (int_head.inisr_rx)
		{
			// Receive-Segmenttransfer ist beendet
			// Clear RX interrupt WORD
            int_head.inisr_rx 	= 0;           // isr deaktivieren
            int_status = PCI_write((void _far*)&pData->pHd->inisr_rx,
							   (void _far*)&int_head.inisr_rx,sizeof(WORD));
			if (int_status)
			{
				// Es ist ein Fehler beim Write oder Read aufgetreten.
				return (int_status);
			}
		}

		if (int_head.inisr_tx)
		{
			// Transmit-Blocktransfer ist ausgef�hrt
			// Clear TX interrupt WORD
            int_head.inisr_tx 	= 0;           // isr deaktivieren
            int_status = PCI_write((void _far*)&pData->pHd->inisr_tx,
							   (void _far*)&int_head.inisr_tx,sizeof(WORD));
			if (int_status)
			{
				// Es ist ein Fehler beim Write oder Read aufgetreten.
				return (int_status);
			}
			pData->TxBuffStatus = 0;
		}

		if (int_head.inisr_rxr)
		{
			// Transmit-Blocktransfer ist ausgef�hrt
			// Clear RXR interrupt WORD
            int_head.inisr_rxr 	= 0;           // isr deaktivieren
            int_status = PCI_write((void _far*)&pData->pHd->inisr_rxr,
							   (void _far*)&int_head.inisr_rxr,sizeof(WORD));
			if (int_status)
			{
				// Es ist ein Fehler beim Write oder Read aufgetreten.
				return (int_status);
			}
			// Get receive data length		
			int_DataLen = (unsigned int)SWAP16 (int_head.rxdata_lng);

			if (int_DataLen > CAREA_LNG)
			{
				int_DataLen = CAREA_LNG;	// cut length if necessary
			}
			int_value = ((WORD)int_DataLen + 1) & ~0x01;
			// Daten kopieren
            int_status = PCI_read(pData->pRxBase,
								  (void _far*)&pData->RxBuff[0],
								  int_value);
			if (int_status)
			{
				// Es ist ein Fehler beim Write oder Read aufgetreten.
				return (int_status);
			}
			// Set received data length
			pData->RxBuffLen = int_DataLen;
			// acknowledge data received
			// Set TX interrupt WORD
            int_head.outisr_tx = 0x0100;
            int_status = PCI_write((void _far*)&pData->pHd->outisr_tx,
								   (void _far*)&int_head.outisr_tx,
								   sizeof(WORD));
			if (int_status)
			{
				// Es ist ein Fehler beim Write oder Read aufgetreten.
				return (int_status);
			}
			// Interrupt aktivieren -> auf der CPU
			// Schreibe den Interrupt -> IRQ ausl�sen
			int_value = (int)0x0100;
			int_status=PCI_write((void _far*)(pData->pByteBase+IRQ4_OFFS),
								 (void _far*)&int_value,sizeof(WORD));
			if (int_status)
			{
				// Es ist ein Fehler beim Write oder Read aufgetreten.
				return (int_status);
			}
		}
		// Read interrupt flags
		int_status = PCI_read(pData->pHd,
							  (void _far*)&int_head,
							  sizeof(REGS_pc_head_typ));
		if (int_status)
		{
			// Es ist ein Fehler beim Write oder Read aufgetreten.
			return (int_status);
		}
	} while (int_head.inisr_rx || int_head.inisr_tx || 
			 int_head.inisr_rxr);
	return (0);
}

//
// LS251_matrix ()
// Writes KEY matrix to DPR and reads LED matrix from DPR
//
int LS251_matrix (void)
{
	static DWORD	level;
	static WORD		value;
	static DWORD	mtc_matrix [MAX_MKEYS];
	static BYTE		dpr_matrix [MAX_MKEYS];
	static DWORD	status;
	static BYTE		i;		// help loop counter
	static BYTE		j;		// help loop counter
	static BYTE		h;		// help loop counter
	
	// read key level from MTC
	status = IPC5000_get_Level (&level);
	if (status != NO_ERROR_DETECT)
	{
		// Error offset 4820
		return (ERR_MTC | ((int)status & 0x00ff));
	}
	// read key matrix from MTC
	status = IPC5000_get_MKey_matrix (&mtc_matrix[0]);
	if (status != NO_ERROR_DETECT)
	{
		// Error offset 4820
		return (ERR_MTC | ((int)status & 0x00ff));
	}
	// unpack bits to bytes

	h = 0;
	for( i = 0; i < MAX_MKEYMATRIX_SIZE; i++)
	{
		for( j = 0; j < MKEY_REGISTER_SIZE; j++)
		{
			dpr_matrix[h] = (BYTE)(mtc_matrix[i] & 0x00000001);
			mtc_matrix[i] = mtc_matrix[i] >> 1;
			h ++;
		}
	}
	// Write key level to DPR
	value = (unsigned short)level;
	status = (DWORD) PCI_write(pData->pKeyLevelDPR,(void _far*)&value,sizeof(WORD));
	if (status)
		return ((int)status);
	// Write key matrix to DPR
	status = (DWORD) PCI_write(pData->pKeyDPR,(void _far*)&dpr_matrix[0],MAX_MKEYS);
	if (status)
		return ((int)status);
	// Read increment value from DPR
	status = (DWORD) PCI_read(pData->pIncrementDPR,(void _far*)&value,sizeof(WORD));
	if (status)
		return ((int)status);
	// Increment value with 1 and write back to DPR
	value ++;
	status = (DWORD) PCI_write(pData->pIncrementDPR,(void _far*)&value,sizeof(WORD));
	if (status)
		return ((int)status);
	// Read led level from DPR
	status = (DWORD) PCI_read(pData->pLedLevelDPR,(void _far*)&value,sizeof(WORD));
	if (status)
		return ((int)status);
	level = (DWORD)value;
	// Read led matrix from DPR
	status = (DWORD) PCI_read(pData->pLedDPR,(void _far*)&dpr_matrix[0],MAX_MKEYS);
	if (status)
		return ((int)status);
	// pack bytes to bits
	for( i = 0; i < MAX_MKEYS; i++ )
	{
		mtc_matrix[i+3] = (DWORD)dpr_matrix[i];
		i ++;
		mtc_matrix[i+1] = (DWORD)dpr_matrix[i];
		i ++;
		mtc_matrix[i-1] = (DWORD)dpr_matrix[i];
		i ++;
		mtc_matrix[i-3] = (DWORD)dpr_matrix[i];
	}
	// write led level and matrix to MTC
	status = IPC5000_put_Leds_in_Level (level, &mtc_matrix[0]);
	if (status != NO_ERROR_DETECT)
	{
		// Error offset 4820
		return (ERR_MTC | ((int)status & 0x00ff));
	}

	return (0);
}

